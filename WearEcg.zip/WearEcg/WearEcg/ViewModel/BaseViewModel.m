//
//  BQBaseViewModel.m
//  DevelopFramework
//
//  Created by momo on 15/12/5.
//  Copyright © 2015年 teason. All rights reserved.
//

#import "BaseViewModel.h"
#import "Loading.h"

@implementation BaseViewModel

-(id)init : (UIViewController *)owner
{
    self = [super init];
    if (self) {
        self.viewController = owner;
    }
    return self;
}


/**
 *  懒加载存放请求到的数据数组
 */
- (NSMutableArray *)dataArrayList {
    if (_dataArrayList == nil) {
        _dataArrayList = [NSMutableArray array];
    }
    return _dataArrayList;
}

- (void)postDataArrFromServer:(NSString *)url params:(NSDictionary *)params progress:(void(^)(CGFloat))progress
        success:(void (^)(NSArray *))success failure:(void (^)(NSError *))failure
{
//    [HttpNetwork post:url params:params progress:^(CGFloat dataprogress) {
//        if (progress) {
//            progress(dataprogress);
//        }
//    }
//    success:^(NSDictionary *jsonDic) {
//        if (success) {
//            //把jsonDic转成Model 放在 _dataArrayList数组中
//            success(self.dataArrayList);
//        }
//    }
//    failure:^(NSError *error) {
//        failure(error);
//    }];
}


- (void)postModelDataFromServer:(NSString *)url params:(NSDictionary *)params
                      progress:(void(^)(CGFloat dataprogress))progress
                       success:(void (^)(id model))success
                       failure:(void (^)(NSError *error))failure
{
//    [HttpNetwork post:url params:params progress:^(CGFloat dataprogress) {
//        if (progress) {
//            progress(dataprogress);
//        }
//    }
//    success:^(NSDictionary *jsonDic) {
//        if (success) {
//          //把jsonDic转成Model
//          success(nil);
//        }
//    }
//    failure:^(NSError *error) {
//        failure(error);
//    }];
}


- (void)postModelDataFromServerProgress:(void(^)(CGFloat dataprogress))progress
                                success:(void (^)(id model))success
                                failure:(void (^)(NSError *error))failure
{
    
}

- (void)postModelDataFromServer
{
    
}

//显示提示
- (void)showTips:(NSString *)str {
    [Loading showTips:str];
}
//显示等待
- (void)showHud : (NSString *)tipStr {
    [Loading showHud:tipStr];
}
//隐藏等待
- (void)hideHud {
    [Loading hideHud];
}


- (NSString *)description{
    return [NSString stringWithFormat:@"View model:%@ viewController:%@",
            super.description,
            self.viewController.description];
}

@end
