//
//  BQBaseViewModel.h
//  DevelopFramework
//
//  Created by momo on 15/12/5.
//  Copyright © 2015年 teason. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "HttpNetwork.h"


@interface BaseViewModel : NSObject

//指定modelView对应的视图控制器
@property (nonatomic, weak) UIViewController *viewController;

//返回数据model数组
@property (nonatomic, strong) NSMutableArray *dataArrayList;

/**
 *  初始化重写
 *  owner : viewModel指定的控制器
 */
-(id)init : (UIViewController *)owner;

/**
 *  请求数据 从服务器 返回多条数据
 *  url : 服务器地址
 *  params : 接口参数
 *  progress : 数据进度
 *  success : 成功回调
 *  failure : 失败回调
 */
- (void)postDataArrFromServer:(NSString *)url params:(NSDictionary *)params
            progress:(void(^)(CGFloat dataprogress))progress
                  success:(void (^)(NSArray *array))success
                        failure:(void (^)(NSError *error))failure;



/**
 *  请求数据 从服务器 返回单条数据 (post请求)
 *  url : 服务器地址
 *  params : 接口参数
 *  progress : 数据进度
 *  success : 成功回调
 *  failure : 失败回调
 */
- (void)postModelDataFromServer:(NSString *)url params:(NSDictionary *)params
                 progress:(void(^)(CGFloat dataprogress))progress
                  success:(void (^)(id model))success
                  failure:(void (^)(NSError *error))failure;


/**
 *  请求数据 从服务器 返回单条数据 (post请求)
 *  progress : 数据进度
 *  success : 成功回调
 *  failure : 失败回调
 */
- (void)postModelDataFromServerProgress:(void(^)(CGFloat dataprogress))progress
                               success:(void (^)(id model))success
                               failure:(void (^)(NSError *error))failure;


/**
 *  请求数据 从服务器 返回单条数据 (post请求)
 */
- (void)postModelDataFromServer;

/**
 *  显示提示
 *  str : 提示文字
 */
- (void)showTips:(NSString *)str;


/**
 *  显示等待界面
 */
- (void)showHud : (NSString *)tipStr;
/**
 *  删除等待界面
 */
- (void)hideHud;

@end
