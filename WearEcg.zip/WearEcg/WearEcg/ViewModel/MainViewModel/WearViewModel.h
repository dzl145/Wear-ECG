//
//  WearViewModel.h
//  WearEcg
//
//  Created by dzl on 17/1/9.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "BaseViewModel.h"

@interface WearViewModel : BaseViewModel

@property (nonatomic, retain)NSMutableArray *array;

//解析电量
- (void)parsingElectricity:(NSString *)valueString;

//解析心率
- (void)parsingHeartRate:(NSString *)valueString;

//计算波形的点
- (CGPoint)bubbleRefreshPoint:(float)rate isreset:(BOOL)reset;

//计算心率波形的点
- (CGPoint)heartRateRefreshPoint:(float)rate isReset:(BOOL)reset;


@end
