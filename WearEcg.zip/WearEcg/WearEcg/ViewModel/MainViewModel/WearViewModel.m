//
//  WearViewModel.m
//  WearEcg
//
//  Created by dzl on 17/1/9.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "WearViewModel.h"
#import "WearViewController.h"

@implementation WearViewModel


- (NSMutableArray *)array {
    if (_array == nil) {
        _array = [[NSMutableArray alloc]init];
    }
    return _array;
}

//解析电量
- (void)parsingElectricity:(NSString *)valueString {
    __weak __typeof(self)weakSelf = self;
    WearViewController *wear = (WearViewController *)weakSelf.viewController;
    //第0字节 类型 (一个字节 两位16进制)
    NSRange range = [valueString rangeOfString:@"01"];
    NSUInteger valueLength = valueString.length;
    NSUInteger accc = valueLength - range.location;
    if (accc >= 6) {
        //第1字节 导联脱落状态
        NSString *electr = [valueString substringWithRange:NSMakeRange(range.location + 2, 2)];
        //RA  LA 是否脱落状态  80：都不脱落  86：RA、LA脱落
        if ([electr isEqual:@"86"]) {
            [wear.RA_btn setTitleColor:OBTION_COLOR(255, 255, 255) forState:UIControlStateNormal];
            [wear.LA_btn setTitleColor:OBTION_COLOR(255, 255, 255) forState:UIControlStateNormal];
            [wear setbLeadOff:1];
            wear.memoryImage.image = [UIImage imageNamed:@"iconprompt-notice"];
            wear.memoryLabel.text = @"导联脱落";
        }
        else {
            [wear.RA_btn setTitleColor:OBTION_COLOR(104, 197, 200) forState:UIControlStateNormal];
            [wear.LA_btn setTitleColor:OBTION_COLOR(104, 197, 200) forState:UIControlStateNormal];
            [wear setbLeadOff:0];
            wear.memoryImage.image = [UIImage imageNamed:@"icon-notice"];
            wear.memoryLabel.text = @"";
        }
        
        //第2字节 电量
        NSString *electricity = [valueString substringWithRange:NSMakeRange(range.location + 4, 2)];
        //把电量16进制转化2进制
        NSString *stringBinary = [electricity convertHexToBinary];
        //把二进制转化10进制
        NSString *stringDecimal = [stringBinary convertBinaryToDecimal];
        //显示电量百分比
        int intelectricity = [stringDecimal intValue] - 128;
        //电池电量图片
        wear.electric_img.image = [UIImage imageNamed:[weakSelf electricityImageName:intelectricity]];
        wear.electric_lab.text = [NSString stringWithFormat:@"%d%@", intelectricity,@"%"];
        if (intelectricity <= 5) {
            wear.memoryImage.image = [UIImage imageNamed:@"iconprompt-notice"];
            wear.memoryLabel.text = @"设备电量低,请充电后使用";
        }
        [wear.electric_lab sizeToFit];
        
        //第3字节 是否充电 80为非充电，81为充电中
        NSString *chargingState = [valueString substringWithRange:NSMakeRange(range.location + 6, 2)];
        if ([chargingState isEqualToString:@"81"]) {
            wear.electric_img.image = [UIImage imageNamed:@"electricity7.png"];
        }
        if (intelectricity <= 18 && [chargingState isEqualToString:@"80"]) {
//            [self addWarnViewType:WarnStyleType_Power];
        }
        else{
//            [self removeWarnViewForPower];
        }
        
        //心率
        if (valueString.length > 8) {
            
            NSString *heartRatePre = [valueString substringWithRange:NSMakeRange(range.location + 8, 2)];
            NSString *heartRate = [valueString substringWithRange:NSMakeRange(range.location + 10, 2)];
            if (wear.isMeasure == YES) {
                if ([heartRatePre integerValue] == 80) {
                    NSString *str = [heartRate convertHexToDecimal];
                    wear.heartLabel.text = [NSString stringWithFormat:@"%d",[str integerValue] - 128];
                    wear.HeartValueLabel.text = wear.heartLabel.text;
                    
                    [self alarmLabel:wear.heartLabel.text WithController:wear];
                    
                    [wear heartRateDateOrg:[str integerValue] - 128];
                }
                else {
                    NSString *str = [heartRate convertHexToDecimal];
                    wear.heartLabel.text = [NSString stringWithFormat:@"%ld",(long)[str integerValue]];
                    wear.HeartValueLabel.text = wear.heartLabel.text;
                    
                    [self alarmLabel:wear.heartLabel.text WithController:wear];
                    
                    [wear heartRateDateOrg:[str integerValue]];
                }
            }
        }
    }
}

- (void)alarmLabel:(NSString *)heartLabel WithController:(WearViewController *)wear {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults boolForKey:ecgAlarm] == YES) {
        NSString *highAlarm = [defaults objectForKey:@"ceilingAlarm"];
        NSCharacterSet* nonDigits =[[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        int highNumber = [[highAlarm stringByTrimmingCharactersInSet:nonDigits] intValue];
        NSString *lowAlarm = [defaults objectForKey:@"belowAlarm"];
        int lowNumber = [[lowAlarm stringByTrimmingCharactersInSet:nonDigits] intValue];
        if ([heartLabel intValue] > highNumber) {
            wear.memoryImage.image = [UIImage imageNamed:@"iconprompt-notice"];
            wear.memoryLabel.text = @"心率过快";
        }
        else if ([heartLabel intValue] < lowNumber) {
            wear.memoryImage.image = [UIImage imageNamed:@"iconprompt-notice"];
            wear.memoryLabel.text = @"心率过慢";
        }
        else {
            wear.memoryImage.image = [UIImage imageNamed:@"icon-notice"];
            wear.memoryLabel.text = @"";
        }
    }
}

//解析心率
- (void)parsingHeartRate:(NSString *)valueString {
    
    __weak __typeof(self)weakSelf = self;
    WearViewController *wear = (WearViewController *)weakSelf.viewController;
    wear.dataPacket++;
    if (valueString.length < 26) {
        return;
    }
    for (int i = 0; i < 10; i++) {
        NSString *originalStr = [valueString substringWithRange:NSMakeRange(i > 4 ? 4 : 2, 2)];
        NSString *originalBinary = [originalStr convertHexToBinary];
        NSString * inverse = [originalBinary substringWithRange:NSMakeRange(0,1)];
        if (i > 4) {
            inverse = [originalBinary substringWithRange:NSMakeRange(7 + 5 - i,1)];
        }
        else {
            inverse = [originalBinary substringWithRange:NSMakeRange(7 - i,1)];
        }
        NSString * str = [valueString substringWithRange:NSMakeRange(6 + 2 * i, 2)];
        NSString * strBinary = [str convertHexToBinary];
        strBinary = [strBinary stringByReplacingCharactersInRange:NSMakeRange(0, 1) withString:inverse];
        NSInteger intString1t = [[strBinary convertBinaryToDecimal] intValue];
        [self.array addObject:[NSNumber numberWithInteger:intString1t]];
    }
    for (int j = 0; j < 5; j++) {
        NSInteger cad = [[self.array objectAtIndex:2 * j] integerValue] * 256 + [[self.array objectAtIndex:2 * j + 1] integerValue];
        if (cad > 32896) {
            cad = cad - 32896;
        }
        cad = cad - 12000;
        
        [wear setarynDataOrg:cad];
        
    }
    [self.array removeAllObjects];
}

//重置最高位 返回10进制
- (NSInteger)resetHigtOriginaChar:(NSString *)originaBinary higtIndex:(NSInteger)index range:(NSRange)range value:(NSString *)valueStr {
    if (valueStr.length <26) {
        return 0;
    }
    NSString * inverse = [originaBinary substringWithRange:NSMakeRange(index,1)];
    NSString * str = [valueStr substringWithRange:range];
    NSString * strBinary = [str convertHexToBinary];
    strBinary = [strBinary stringByReplacingCharactersInRange:NSMakeRange(0, 1) withString:inverse];
    
    return [[strBinary convertBinaryToDecimal] intValue];
}

- (NSString *)electricityImageName:(int)battery {
    NSString * electricityStr = nil;
    if (battery <= 16) {
        electricityStr = @"electricity0.png";
    }
    else if (battery > 16 && battery <= 32){
        electricityStr = @"electricity1.png";
    }
    else if (battery > 32 && battery <= 48){
        electricityStr = @"electricity2.png";
    }
    else if (battery > 48 && battery <= 64){
        electricityStr = @"electricity3.png";
    }
    else if (battery > 64 && battery <= 80){
        electricityStr = @"electricity5.png";
    }
    else{
        electricityStr = @"electricity5.png";
    }
    return electricityStr;
}


//计算波形的点
- (CGPoint)bubbleRefreshPoint:(float)rate isreset:(BOOL)reset {
    __weak __typeof(self)weakSelf = self;
    WearViewController *wear = (WearViewController *)weakSelf.viewController;
    
    CGFloat heartHeight = CGRectGetHeight(wear.heartview.frame);
    static NSInteger dataSourceCounterIndex = -1;
    dataSourceCounterIndex ++;
    dataSourceCounterIndex %= [wear.dataSource count];
    NSInteger pixelPerPoint = 1;
    
    //每次以 1 递增 相当于2px(两个像素)
    static NSInteger xCoordinateInMoniter = 0;
    if (reset) {
        xCoordinateInMoniter = 0;
    }
    NSInteger sourceValue = [wear.dataSource[dataSourceCounterIndex] integerValue];
    
    NSInteger cadwValues = sourceValue > 0 ? -sourceValue : labs(sourceValue);
//    NSLog(@"***************** cadwValues : %f",(((CGFloat)cadwValues/50 * rate) + (heartHeight/2+25)));
    //根据倍数设置
    CGPoint targetPointToAdd = (CGPoint){xCoordinateInMoniter* 0.5 ,((CGFloat)cadwValues/50 * rate) + (heartHeight/2+25)};//0.4
    xCoordinateInMoniter += pixelPerPoint;
    xCoordinateInMoniter %= (int)(CGRectGetWidth(wear.heartview.frame) * 2);//* 2.5
    return targetPointToAdd;
}

//计算心率波形的点
- (CGPoint)heartRateRefreshPoint:(float)rate isReset:(BOOL)reset {
    __weak __typeof(self)weakSelf = self;
    WearViewController *wear = (WearViewController *)weakSelf.viewController;
    
    CGFloat heartHeight = CGRectGetHeight(wear.heartRate.frame);
    static NSInteger dataSourceCounterIndex = -1;
    dataSourceCounterIndex ++;
    dataSourceCounterIndex %= [wear.heartRateDataSource count];
    CGFloat pixelPerPoint = 2;
    //每次以 1 递增 相当于2px(两个像素)
    float coefficient = (SCREEN_WIDTH - 70) / 92.6;
    static NSInteger xCoordinateInMoniter = 35 / 2.7;
    if (reset) {
        xCoordinateInMoniter = 35 / 2.7;
    }
    NSInteger sourceValue = [wear.heartRateDataSource[dataSourceCounterIndex] integerValue];
    if (sourceValue > 180) {
        sourceValue = 180;
    }
    if (sourceValue < 30) {
        sourceValue = 30;
    }
    NSInteger cadwValues = (sourceValue - 80) > 0 ? -(sourceValue - 80) : labs((sourceValue - 80));
    
    //根据倍数设置
    CGPoint targetPointToAdd = (CGPoint){xCoordinateInMoniter * 2.7,(CGFloat)cadwValues * 1.14 + (heartHeight/2 - 9 + 23)};//0.4
    xCoordinateInMoniter += pixelPerPoint;
    xCoordinateInMoniter %= (int)(CGRectGetWidth(wear.heartRate.frame) * 2);//* 2.5
    NSLog(@"x == %f  y == %f",targetPointToAdd.x,targetPointToAdd.y);
//    if (targetPointToAdd.x >= (SCREEN_WIDTH - 35)) {
//        
//        [wear changeTime];
//        xCoordinateInMoniter = 35 / 2.5;
//        [wear.heartRate clearContext:YES];
//    }
    return targetPointToAdd;
}


//删除电量提示视图
//-(void)removeWarnViewForPower{
//    __weak __typeof(self)weakSelf = self;
//    WearViewController *wear = (WearViewController *)weakSelf.viewController;
//    WarnView * warn = (WarnView *)[wear.view viewWithTag:WarnTipViewTag_Power];
//    if (warn) {
//        [warn removeFromSuperview];
//    }
//}

@end
