//
//  BaseDataModel.h
//  WearEcg
//
//  Created by HeartDoc on 16/9/27.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "BaseModel.h"

@interface BaseDataModel : BaseModel

/***********************增删改查****************************/
/*
 * 查询所有数据 返回model数组
 */
+ (NSArray *)modelWithOperateAll;

/*
 * 操作数据库 返回model数据
 * predicate : 查询条件
 */
+ (NSArray *)modelWithOperateByPredicate : (NSPredicate *)predicate;

/**
 * 条件的查询且排序
 *
 *  @param fmt       多个查询条件
 *  @param sortDescription 排序
 */
+ (NSArray *)modelWithSortDescriptions:(NSArray *)sortDescription withFormat:(NSString *)fmt, ...;

/**
 * 带有多个条件的查询 且 排序 且 分页
 *
 *  @param fmt              多个查询条件
 *  @param sortDescription  排序
 *  @param offset           查询的偏移量(页数)
 *  @param limitNumber       限定查询结果的数量(每页的数量)
 */
+ (NSArray *)modelWithSortDescriptions:(NSArray *)sortDescription fromOffset:(NSUInteger)offset  limitedBy:(NSUInteger)limitNumber withFormat:(NSString *)fmt, ...;

/*
 * 插入 创建数据
 */
+(BOOL) createWithOperate : (NSDictionary *)dict;

-(BOOL) createWithOperate;

/*
 * 删除 数据
 */
+(BOOL) removeWithOperateAll;

/*
 * 删除 数据
 * predicate : 查询条件
 */
+(BOOL) removeWithOperateByPredicate : (NSPredicate *)predicate;

/*
 * 修改 数据
 * predicate : 查询条件
 */
+(BOOL) updateWithOperateByPredicate : (NSPredicate *)predicate withDic  : (NSDictionary *)dict;

-(BOOL) updateWithOperateByPredicate : (NSPredicate *)predicate;

@end
