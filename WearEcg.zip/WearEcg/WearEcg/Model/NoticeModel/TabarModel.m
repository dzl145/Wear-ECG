//
//  NoticeModel.m
//  EcgWear
//
//  Created by HeartDoc on 16/8/5.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "TabarModel.h"

@implementation TabarModel

+ (NSArray *)tabarModelWithArray
{
    NSString *configFile = [[NSBundle mainBundle] pathForResource:@"tabBarList" ofType:@"plist"];
    NSArray *pageConfigs = [NSArray arrayWithContentsOfFile:configFile];
//    NSMutableArray *pages = [[NSMutableArray alloc] init];
    
    if (pageConfigs.count <= 0) {
        NSLog(@"没有配置TabBarConfig.plist");
    }
    
//    for (NSDictionary *dict in pageConfigs) {
//        TabarModel *model = [[TabarModel alloc] init];
//        [model setValuesForKeysWithDictionary:dict];
//        [pages addObject:model];
//    }
    NSArray * tabarArr = [TabarModel modelsWithArray:pageConfigs];
    return tabarArr;
}

@end
