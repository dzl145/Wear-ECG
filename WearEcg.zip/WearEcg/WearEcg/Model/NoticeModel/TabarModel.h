//
//  NoticeModel.h
//  EcgWear
//
//  Created by HeartDoc on 16/8/5.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "BaseModel.h"

@interface TabarModel : BaseModel

//控制器
@property (strong,nonatomic)NSString * controller;

//控制器页签名称
@property (strong,nonatomic)NSString * title;

//控制器导航名称
@property (strong,nonatomic)NSString * navigationtitle;

//默认图标
@property (strong,nonatomic)NSString *image_defult;

//选中图标
@property (strong,nonatomic)NSString *image_select;

//是否加载
@property (assign,nonatomic)BOOL isLoad;

//获取tabar的model数组
+ (NSArray *)tabarModelWithArray;

@end
