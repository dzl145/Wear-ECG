//
//  BaseDataModel.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/27.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "BaseDataModel.h"

@implementation BaseDataModel

+ (NSArray *)modelWithOperateAll{
    return nil;
}

+ (NSArray *)modelWithOperateByPredicate : (NSPredicate *)predicate{
    return nil;
}

+ (NSArray *)modelWithSortDescriptions:(NSArray *)sortDescription withFormat:(NSString *)fmt, ...{
    return nil;
}

+ (NSArray *)modelWithSortDescriptions:(NSArray *)sortDescription fromOffset:(NSUInteger)offset  limitedBy:(NSUInteger)limitNumber withFormat:(NSString *)fmt, ...{
    return nil;
}

+(BOOL) createWithOperate : (NSDictionary *)dict{
    return NO;
}

-(BOOL) createWithOperate{
    return NO;
}

+(BOOL) removeWithOperateAll{
    return NO;
}

+(BOOL) removeWithOperateByPredicate : (NSPredicate *)predicate{
    return NO;
}


+(BOOL) updateWithOperateByPredicate : (NSPredicate *)predicate withDic  : (NSDictionary *)dict{
    return NO;
}

-(BOOL) updateWithOperateByPredicate : (NSPredicate *)predicate{
    return NO;
}

@end
