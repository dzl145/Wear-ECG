//
//  personModel.h
//  WearEcg
//
//  Created by HeartDoc on 16/5/11.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "BaseModel.h"

@interface UserModel : BaseModel

//手机号码(也是登录账号 不是唯一的)
@property(strong,nonatomic)NSString *phone;
//姓名
@property(strong,nonatomic)NSString *name;
//出生日期
@property(strong,nonatomic)NSString *birthdate;
//性别
@property(strong,nonatomic)NSString *sex;
//身高
@property(strong,nonatomic)NSString *height;
//体重
@property(strong,nonatomic)NSString *weight;
//紧急联系人
@property(strong,nonatomic)NSString *emergency_contact;
//紧急联系电话
@property(strong,nonatomic)NSString * emergency_contact_tel;


//编号 是唯一的
@property(strong,nonatomic)NSString *num;
//头像后台地址
@property(strong,nonatomic)NSString *logo;
//密码
@property(strong,nonatomic)NSString *password;
//设备ID
@property(strong,nonatomic)NSString *device_id;
//结束服务时间
@property(strong,nonatomic)NSString *end_time ;
//免登录令牌
@property(strong,nonatomic)NSString *usertoken;


-(void)dictionaryToModel : (NSDictionary *)dic;

//返回注册信息的字典
-(NSMutableDictionary *)getRegistModelToDictionary;

//返回用户的全部信息的字典
//-(NSMutableDictionary *)getAllToDictionary;


-(NSArray *)getUserBaseMessage;

//更改账户
-(BOOL)updateUserPhoneNum : (NSString *)newPhone;


@end
