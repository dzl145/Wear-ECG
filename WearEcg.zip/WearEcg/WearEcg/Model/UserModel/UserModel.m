//
//  personModel.m
//  WearEcg
//
//  Created by HeartDoc on 16/5/11.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

-(void)dictionaryToModel : (NSDictionary *)dic
{
    if (dic[@"phone"] != nil) {
        self.phone = dic[@"phone"];
    }
    if (dic[@"name"] != nil) {
        self.name = dic[@"name"];
    }
    if (dic[@"birthdate"] != nil) {
        self.birthdate = dic[@"birthdate"];
    }
    if (dic[@"sex"] != nil) {
        self.sex = [NSString stringWithFormat:@"%ld",(long)[dic[@"sex"] integerValue]];
    }
    if (dic[@"height"] != nil) {
        self.height = dic[@"height"];
    }
    if (dic[@"weight"] != nil) {
        self.weight = dic[@"weight"];
    }
    if (dic[@"emergency_contact"] != nil) {
        self.emergency_contact = dic[@"emergency_contact"];
    }
    if (dic[@"emergency_contact_tel"] != nil) {
        self.emergency_contact_tel = dic[@"emergency_contact_tel"];
    }
    if (dic[@"num"] != nil) {
        self.num = dic[@"num"];
    }
    if (dic[@"logo"] != nil) {
        self.logo = dic[@"logo"];
    }
    if (dic[@"password"] != nil) {
        self.password = dic[@"password"];
    }
    if (dic[@"device_id"] != nil) {
        self.device_id = dic[@"device_id"];
    }
    if (dic[@"end_time"] != nil) {
        self.end_time = [NSString stringWithFormat:@"%ld",(long)[dic[@"end_time"] integerValue]];
    }
    if (dic[@"usertoken"] != nil) {
        self.usertoken = dic[@"usertoken"];
    }
}

-(NSMutableDictionary *)getRegistModelToDictionary
{
    NSMutableDictionary * modelDic = [[NSMutableDictionary alloc]init];
    
    [modelDic setObject:self.phone forKey:@"phone"];
    [modelDic setObject:self.name forKey:@"name"];
    [modelDic setObject:self.birthdate forKey:@"birthdate"];
    [modelDic setObject:self.sex forKey:@"sex"];

    [modelDic setObject:self.height forKey:@"height"];
    [modelDic setObject:self.weight forKey:@"weight"];
    [modelDic setObject:self.emergency_contact forKey:@"emergency_contact"];
    [modelDic setObject:self.emergency_contact_tel forKey:@"emergency_contact_tel"];
    
    return modelDic;
}


-(BOOL)updateUserPhoneNum : (NSString *)newPhone
{
    if (newPhone != nil && ![newPhone isEqualToString:@""]) {
        self.phone = newPhone;
        return YES;
    }
    return NO;
}


-(NSArray *)getUserBaseMessage
{ 
//    NSString * setStr = @"";
//    if ([self.sex isEqualToString:@"0"]) {
//       setStr = @"女";
//    }
//    else{
//        setStr = @"男";
//    }
//    
//    NSDate * date = [NSDate convertStringToDate:self.birthdate];
//    NSString * brithStr = [NSDate convertDateToString:date Format:@"yyyy年MM月dd日"];
//
//    NSString * heightStr = [NSString stringWithFormat:@"%@ cm",self.height];
//    NSString * weightStr = [NSString stringWithFormat:@"%@ kg",self.weight];
//
//    NSArray * arr = [[NSArray alloc]initWithObjects:self.num,self.name,setStr,brithStr,heightStr,weightStr,nil];
//    return arr;
    return nil;
}



+ (NSArray *)modelWithOperateAll{
//    NSMutableArray * modelArr = [[NSMutableArray alloc]init];
//    NSArray * dictArr = [UserOperate findAll];
//    for (NSDictionary * dict in dictArr) {
//        [modelArr addObject:[self modelWithDict: dict]];
//    }
//    return modelArr;
    
    return nil;
}

@end
