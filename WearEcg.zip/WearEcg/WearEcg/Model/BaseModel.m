//
//  BaseModel.m
//  WearEcg
//
//  Created by HeartDoc on 16/6/7.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "BaseModel.h"
#import <objc/runtime.h>

@implementation BaseModel

- (void)dictionaryToModel:(NSDictionary *)dict
{
    [self setValuesForKeysWithDictionary:dict];
}

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self dictionaryToModel:dict];
    }
    return self;
}

+ (instancetype)modelWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict : dict];
}

+ (NSArray *)modelsWithArray:(NSArray *)array
{
    NSMutableArray * arrayM = [NSMutableArray array];
    
    for (NSDictionary *dict in array) {
        
        [arrayM addObject:[self modelWithDict:dict]];
    }
    return arrayM;
}

- (NSDictionary *)dictWithModel
{
    return [self dictionaryWithValuesForKeys:[self allPropertyNames]];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    [self setValue:value forKey:key];
}

//通过运行时获取当前对象的所有属性的名称，以数组的形式返回
- (NSArray *) allPropertyNames{
    //存储所有的属性名称
    NSMutableArray *allNames = [[NSMutableArray alloc] init];
    //存储属性的个数
    unsigned int propertyCount = 0;
    //通过运行时获取当前类的属性
    objc_property_t *propertys = class_copyPropertyList([self class], &propertyCount);
    
    //把属性放到数组中
    for (int i = 0; i < propertyCount; i ++) {
        //取出第一个属性
        objc_property_t property = propertys[i];
        
        const char * propertyName = property_getName(property);
        
        [allNames addObject:[NSString stringWithUTF8String:propertyName]];
    }
    ///释放
    free(propertys);
    
    return allNames;
}


- (NSString *)description
{
    return [NSString stringWithFormat:@"Model:%@",
            super.description];
}

//重写dictionaryWithValuesForKeys 方法

//-(NSDictionary *)dictionaryWithValuesForKeys : (NSArray *)keyArr
//{
//    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
//
//    for (NSInteger i = 0; i < keyArr.count; i++) {
//
////        SEL selector = NSSelectorFromString(keyArr[i]);
//       NSString * attName = [NSString stringWithString:keyArr[i]];
//       SEL selector = NSSelectorFromString(attName);
//
//        if ([self respondsToSelector:selector]) {
//
//            IMP imp = [self methodForSelector:selector];
//            NSString * (*func)(id, SEL) = (void *)imp;
//            NSString * strCon = func(self ,selector);
//            if (strCon == nil) {
//                strCon = @"";
//            }
//            [mutableDictionary setObject:strCon forKey:attName];
//        }
//    }
//    return mutableDictionary;
//}


@end
