//
//  RecordEntity+CoreDataClass.m
//  WearEcg
//
//  Created by dzl on 17/1/18.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "RecordEntitySingle+CoreDataClass.h"

@implementation RecordEntitySingle

@end
