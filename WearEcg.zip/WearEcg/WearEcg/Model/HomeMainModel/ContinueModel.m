//
//  ContinueModel.m
//  WearEcg
//
//  Created by dzl on 17/1/19.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "ContinueModel.h"

@implementation ContinueModel

@end
