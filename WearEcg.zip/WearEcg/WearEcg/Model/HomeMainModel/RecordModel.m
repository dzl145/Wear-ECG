//
//  RecordModel.m
//  WearEcg
//
//  Created by dzl on 17/1/17.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "RecordModel.h"

@implementation RecordModel

@end
