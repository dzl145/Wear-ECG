//
//  ContinueEntity+CoreDataProperties.m
//  WearEcg
//
//  Created by dzl on 17/1/19.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "ContinueEntity+CoreDataProperties.h"

@implementation ContinueEntity (CoreDataProperties)

+ (NSFetchRequest<ContinueEntity *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"ContinueEntity"];
}

@dynamic starttime;
@dynamic endtime;
@dynamic timelength;
@dynamic filename;
@dynamic filepath;
@dynamic filetype;
@dynamic isupload;
@dynamic continuekey;
@dynamic mdname;
@dynamic progress;
@dynamic symptom;
@dynamic usermark;
@dynamic heartrate;

@end
