//
//  ContinueModel.h
//  WearEcg
//
//  Created by dzl on 17/1/19.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContinueModel : NSObject

@property (nonatomic, strong) NSString *filename;    //文件名称
@property (nonatomic, strong) NSString *mdname;     //md5加密名称
@property (nonatomic, strong) NSString *filepath;    //文件路径

@property (nonatomic, assign) NSInteger filetype;    //文件类型 integer
@property (nonatomic, strong) NSNumber *progress;    //上传的进度 cgfloat
@property (nonatomic, strong) NSNumber *isupload;    //是否上传完成 bool

@property (nonatomic, strong) NSString *heartrate;   //所有心率字符串
@property (nonatomic, strong) NSString *symptom;     //健康状体

@property (nonatomic, strong) NSDate *starttime;     //开始时间
@property (nonatomic, strong) NSDate *endtime;       //结束时间

@property (nonatomic, strong) NSNumber *timelength;  //单次测量时长
@property (nonatomic, strong) NSString *continuekey; //连续测量key

@property (nonatomic, strong) NSString *usermark;    //文件所属文件标示 (用户ID)

@property (nonatomic, strong)NSString *size;

@end
