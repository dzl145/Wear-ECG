//
//  RecordEntity+CoreDataProperties.m
//  WearEcg
//
//  Created by dzl on 17/1/18.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "RecordEntity+CoreDataProperties.h"

@implementation RecordEntitySingle (CoreDataProperties)

+ (NSFetchRequest<RecordEntitySingle *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"RecordEntity"];
}

@dynamic continuekey;
@dynamic endtime;
@dynamic filename;
@dynamic filepath;
@dynamic filetype;
@dynamic isupload;
@dynamic mdname;
@dynamic progress;
@dynamic starttime;
@dynamic symptom;
@dynamic timelength;
@dynamic usermark;

@end
