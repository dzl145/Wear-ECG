//
//  RecordEntity+CoreDataClass.h
//  WearEcg
//
//  Created by dzl on 17/1/18.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class NSObject;

NS_ASSUME_NONNULL_BEGIN

@interface RecordEntitySingle : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "RecordEntity+CoreDataProperties.h"
