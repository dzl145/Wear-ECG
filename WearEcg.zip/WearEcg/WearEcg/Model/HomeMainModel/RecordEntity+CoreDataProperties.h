//
//  RecordEntity+CoreDataProperties.h
//  WearEcg
//
//  Created by dzl on 17/1/18.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "RecordEntitySingle+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface RecordEntitySingle (CoreDataProperties)

+ (NSFetchRequest<RecordEntitySingle *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *continuekey;
@property (nullable, nonatomic, copy) NSDate *endtime;
@property (nullable, nonatomic, copy) NSString *filename;
@property (nullable, nonatomic, copy) NSString *filepath;
@property (nullable, nonatomic, copy) NSNumber *filetype;
@property (nonatomic) BOOL isupload;
@property (nullable, nonatomic, copy) NSString *mdname;
@property (nonatomic) float progress;
@property (nullable, nonatomic, copy) NSDate *starttime;
@property (nullable, nonatomic, copy) NSString *symptom;
@property (nonatomic) float timelength;
@property (nullable, nonatomic, copy) NSString *usermark;

@end

NS_ASSUME_NONNULL_END
