//
//  ContinueEntity+CoreDataClass.m
//  WearEcg
//
//  Created by dzl on 17/1/19.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "ContinueEntity+CoreDataClass.h"

@implementation ContinueEntity

@end
