//
//  BaseModel.h
//  WearEcg
//
//  Created by HeartDoc on 16/6/7.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
//#import "BaseOperate.h"

@interface BaseModel : NSObject

/*
 * 给model对象本身赋值 返回对象本身
 * dict : json数据
 */
- (void)dictionaryToModel:(NSDictionary *)dict;

/*
 * 返回model数据对象 并创新的model对象
 * dict : json数据
 */
+ (instancetype)modelWithDict:(NSDictionary *)dict;

/*
 * 返回model数据对象数组
 * array : json数组数据
 */
+ (NSArray *)modelsWithArray:(NSArray *)array;

/*
 * 返回model所有属性字段转成字典
 */
- (NSDictionary *)dictWithModel;

/*
 * 设置model属性值
 * key : 属性字段
 */
- (void)setValue:(id)value forUndefinedKey:(NSString *)key;

@end
