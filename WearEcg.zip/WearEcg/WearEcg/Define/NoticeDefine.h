//
//  NoticeDefine.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/15.
//  Copyright © 2016年 owen. All rights reserved.
//

#ifndef NoticeDefine_h
#define NoticeDefine_h

//定义注册通知
#define RegisterNotify(_name, _selector)                        \
        [[NSNotificationCenter defaultCenter] addObserver:self  \
        selector:_selector name:_name object:nil];

#define RemoveNofify               \
        [[NSNotificationCenter defaultCenter] removeObserver:self];

#define SendNotify(_name, _object) \
        [[NSNotificationCenter defaultCenter] postNotificationName:_name object:_object];


//通知key

//用户信息通知
#define NofifyUserInfo         @"userInfo"
//菜单状态通知
#define NofifyMenuState        @"menuState"
//信号状态
#define NofifySignalState      @"signalState"
//蓝牙是否选中状态
#define NofifyBlueSelectState  @"blueSelectState"

//上传状态(完成 失败 上传 开始等)
#define NofifyUploadState      @"uploadState"
//wifi状态
#define NofifyWifiState        @"wifiState"

#endif /* NoticeDefine_h */
