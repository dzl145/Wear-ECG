//
//  MenuType.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/15.
//  Copyright © 2016年 owen. All rights reserved.
//

#ifndef MenuType_h
#define MenuType_h

typedef NS_ENUM(NSInteger, MenuNoticeTextType) {
    //纯文本
    MenuNoticeTextType_Text = 1,
    //图片背景
    MenuNoticeTextType_Img
};

typedef NS_ENUM(NSInteger, MenuViewRowIndexType) {
    //数据清理
    MenuViewRowIndexTypeClean = 1,
    //消息通知
    MenuViewRowIndexTypeMessage,
    //数据上传
    MenuViewRowIndexTypeUpload,
    //设备管理
    MenuViewRowIndexTypeWarn,
    //账号安全
    MenuViewRowIndexTypeSafety,
    //关于我们
    MenuViewRowIndexTypeAboutUs,
    //会员中心
    MenuViewRowIndexTypeVip,
};


#endif /* MenuType_h */
