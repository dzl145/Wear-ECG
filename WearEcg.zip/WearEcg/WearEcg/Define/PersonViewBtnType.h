//
//  PersonViewBtnType.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/24.
//  Copyright © 2016年 owen. All rights reserved.
//

#ifndef PersonViewBtnType_h
#define PersonViewBtnType_h

typedef enum {
    /** 姓名 */
    PersonView_Btn_Name = 411,
    /** 性别 */
    PersonView_Btn_Sex,
    /** 生日 */
    PersonView_Btn_Brith,
    /** 身高 */
    PersonView_Btn_Height,
    /** 体重 */
    PersonView_Btn_Weight
    
}  PersonViewBtnTag;

#endif /* PersonViewBtnType_h */
