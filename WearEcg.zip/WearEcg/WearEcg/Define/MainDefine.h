//
//  MainDefine.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/29.
//  Copyright © 2016年 owen. All rights reserved.
//

#ifndef MainDefine_h
#define MainDefine_h

#define startCut     @"start"
#define timerCut     @"timer"
#define markCut      @"mark"
#define exceptionCut @"exception"
#define fiveCut      @"five"
#define sixtyCut     @"sixty"
#define continueCut  @"continue" //用于记录整个连续测量时 记录心率

//命令类型宏定义
#define calibrationtime    @"calibrationtime"
#define startmeasuring     @"startmeasuring"
#define oneMVcalibration   @"oneMVcalibration"
#define disconnectblue     @"disconnectblue"
#define alarmcontrol       @"alarmcontrol"
#define alarmrename        @"alarmrename"

//尺寸
//时间文本字符Fram
#define timetxt_size CGSizeMake(110 , 16)
//时间lable的Fram
#define timelabel_size CGSizeMake(220 , 28)

//主界面 tag
typedef NS_ENUM(NSUInteger, MainViewChildTag) {
    MainViewChildTag_Home = 33330,     //测量主界面
    MainViewChildTag_Menu,             //菜单界面
};

typedef NS_ENUM(NSUInteger, WarnTipViewTag) {
    WarnTipViewTag_Power = 33340,     //电量提示索引
    WarnTipViewTag_Data,              //丢包提示索引
};

//状态类型
typedef NS_ENUM(NSUInteger, MeasurStyle) {
    MeasurStyle_Sixty = 1,         //60s测量
    MeasurStyle_Continue,          //连续测量
    MeasurStyle_Mv,                //校准测量
};

//状态类型
typedef NS_ENUM(NSUInteger, SearchButtonState) {
    SearchState_Search = 1,         //搜索蓝牙
    SearchState_Start,              //开始检测
    SearchState_Stop,               //停止测量
};

//命令类型
typedef NS_ENUM(NSUInteger, BlueCommndType) {
    BlueCommndType_CalibrationTime = 1,      //校准时间
    BlueCommndType_StartMeasuring,           //开始检测
    BlueCommndType_EndMeasuring,             //结束检测
    BlueCommndType_1MVCalibration,           //1mv校准
    BlueCommndType_DisconnectBlue,           //断开连接
    BlueCommndType_AlarmControl,             //警报控制
    BlueCommndType_AlarmRename               //蓝牙重命名
};

//截取类型
typedef NS_ENUM(NSUInteger, BlueDataInterceptType) {
    BlueDataInterceptType_Exception = 0,     //异常截取
    BlueDataInterceptType_Mark,              //Mark截取 前5s-后15s 注意:后期可能放入异常
    BlueDataInterceptType_Starting,          //开始测量截取 20s
    BlueDataInterceptType_Timer,             //定时截取 20s

    BlueDataInterceptType_Sixty,             //60截取
    BlueDataInterceptType_Continue,          //连续截取
};

//异常类型
//mark异常暂时没有加进去
typedef NS_ENUM(NSUInteger, BlueDataExceptionTypes) {
    BlueDataExceptionTypes_SinTachy = 1,     //窦性心动过速
    BlueDataExceptionTypes_SinBrady,         //窦性心动过缓
    BlueDataExceptionTypes_SingleVen,        //单发室早
    BlueDataExceptionTypes_PairVen,          //成对室早
    BlueDataExceptionTypes_VenTachy,         //室速
    BlueDataExceptionTypes_VenBi,            //室早二连律
    
    BlueDataExceptionTypes_Tri,              //室早三连律
    BlueDataExceptionTypes_SingleAtr,        //单发房早
    BlueDataExceptionTypes_PairAtr,          //成对房早
    BlueDataExceptionTypes_ArtTachy,         //房速
    BlueDataExceptionTypes_ApbBi,            //房早二连律
    BlueDataExceptionTypes_ApbTri,           //室早三连律
    
    BlueDataExceptionTypes_Pause,            //漏博
    BlueDataExceptionTypes_Afril,            //房颤
    BlueDataExceptionTypes_Stop              //停博
};

#endif /* MainDefine_h */
