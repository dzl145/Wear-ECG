//
//  CleanType.h
//  WearEcg
//
//  Created by HeartDoc on 16/5/30.
//  Copyright © 2016年 lxl. All rights reserved.
//

#ifndef CleanType_h
#define CleanType_h

//修改密码  重置密码 修改手机 完成类型
typedef NS_ENUM(NSUInteger, RetrievePasswordType) {
    Retrieve_Password_Code = 1,     //重置密码  短信验证码
    Retrieve_Reset_Password,        //修改密码  密码验证
    Retrieve_Reset_PhoneNum,        //重置手机号码
};





#endif /* CleanType_h */
