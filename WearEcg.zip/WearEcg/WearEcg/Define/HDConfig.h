//
//  HDPublicClass.h
//  WearEcg
//
//  Created by lxl on 15/12/1.
//  Copyright © 2015年 医甸园. All rights reserved.
//

#ifndef HDPublicClass_h
#define HDPublicClass_h

#define SingleRecord       @"SingleRecord"
#define ContinueRecord     @"ContinueRecord"

#define SCREEN_WIDTH       [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT      [UIScreen mainScreen].bounds.size.height

//高德的地图key值
#define mapKey             @"7b09ff446039db065231064770eababd"
#define CALCULATE_WAVEFORM 250  //计算心率波形宏定义长度

#define AVERAGE_HEART      240       //得出30秒品均心率
//#define  kMaxContainerCapacity (SCREEN_WIDTH - 16) * 2
#define HDMeasureRecord    @"MeasureRecord.sqlite"

#define DOCUMENTS_FOLDER   [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]

#define OBTION_COLOR(R,G,B) [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:1.0]
#define MAIN_COLOR         [UIColor colorWithRed:62/255.0 green:191/255.0 blue:162/255.0 alpha:1]
#define GREEN_COLOR        [UIColor colorWithRed:1/255.0 green:151/255.0 blue:50/255.0 alpha:1]
#define ORANGE_COLOR       [UIColor colorWithRed:254/255.0 green:114/255.0 blue:35/255.0 alpha:1]
#define RED_COLOR          [UIColor colorWithRed:210/255.0 green:21/255.0 blue:37/255.0 alpha:1]

//自动截取的颜色
#define AUTO_CUT_COLOR [UIColor colorWithRed:1.000 green:0.447 blue:0.000 alpha:1.000];
#define ISIOS8 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define ISIPAD ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

//关键字定义
#define YearLong  100       //年限
#define CurLogigKey         @"loginUserId"
#define CurNewestKey        @"newestVersion"
#define DeviceTipState      @"deviceTipState"
#define NetWorkState        @"netWorkState"
#define NewestUuid          @"NewestUuid"
#define MvCorrect           @"MvCorrect"
#define PacketLoss          @"PacketLoss"
#define MeasurtWay          @"MeasurtWay"

#define HomeMenuList        @"HomeMenuList"


// 友盟统计
#define UMengAppKey     @"567ca894e0f55a95cf00422a"
#define UMengTips       @"版本更新"

/******************* 存储宏定义 **********************/

#define sqlLite             @"ecg.sqlite"
#define momdFile            @"EcgWear"

#define HomePath            NSHomeDirectory()
#define Document            NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0]
#define Library             NSSearchPathForDirectoriesInDomains (NSLibraryDirectory, NSUserDomainMask, YES)[0]

//路径 Library/.EcgWear/用户/分类文件夹.../子分类
//用户头像路径
#define RootName            @"/.EcgWear"
#define RootPath            [Library stringByAppendingPathComponent:RootName]

//分类文件存储路径
#define UserPhoto           @"/UserPhoto"
#define UserFile24h         @"/24h"
#define UserFile60s         @"/60s"
//连续测量截取文件路径(子分类)
#define StartPath           UserFile24h @"/start"
#define TimerPath           UserFile24h @"/timer"
#define MarkPath            UserFile24h @"/mark"
#define ExcepPath           UserFile24h @"/excep"
//连续测量时的所有心率路径
#define heartPath           UserFile24h @"/heart"

/***************  颜色  **************/
#define appThemeColor    0x68c5c8



/***************  服务器地址  **************/

#define BaseHost           @"http://realtime.ddduo.com"
#define BasePort           @""


//服务器地址
#define BaseServer         BaseHost BasePort
//url路径
#define BaseURLPath        @"/realtime/AppServiceController/"
//url地址
#define BaseURL            BaseServer BaseURLPath

//接口信息定义
//注册
#define UserRegister            BaseURL "appRegister"
//个人信息
#define UpdateInfo              BaseURL "appUpdateInfo"
//用户头像地址
#define UserPhotoPic            BaseURL "appLogo"
//验证码
#define phoneVertNum            BaseURL "sendMessageCode"
//登录
#define UserLogin               BaseURL "appLogin"
//查找密码
#define findPasVerify           BaseURL "findPasswordVerification"
//更新密码
#define UpdatePassword          BaseURL "appLoginPassword"
//更新用户手机号码
#define UpdateUserPhone          BaseURL "appLoginNum"
//token验证
#define UserToken               BaseURL "userToken"
//截取文件上传
#define UploadHeartFile         BaseURL "UploadHandleServlet"
//60秒文件上传
#define UploadSixFile           BaseURL "UploadHandleSixtySeconds"
//版本监测
#define AppVersion              BaseURL "monitoringAppEdition"
//反馈意见
#define OpinionFeedback         BaseURL "findOpinionFeedback"
//高级调试
#define DebugPassword         BaseURL "manufactorDebugPassword"


//返回数据接口
#define DataKey          @"data"

//单次测量key
#define ecgIsMeasure     @"ecgIsMeasure"
#define ecgSearch        @"ecgSearch"
#define ecgAlarm         @"ecgAlarm"
#define ecgBinding       @"ecgBinding"
#define SingleCounts     @"singleCount"
#define ContinueCounts   @"continueCount"


#endif /* HDPublicClass_h */
