//
//  CleanType.h
//  WearEcg
//
//  Created by HeartDoc on 16/5/30.
//  Copyright © 2016年 lxl. All rights reserved.
//

#ifndef CleanType_h
#define CleanType_h


typedef NS_ENUM(NSUInteger, CleanFileType) {
    CleanFileType60s = 1,          //60s
    CleanFileTypeCon,              //连续
    CleanFileTypeExp,              //异常
};


#define CleanFile60s  @"CleanFile60s"
#define CleanFileCon  @"CleanFileCon"
#define CleanFileExp  @"CleanFileExp"

#endif /* CleanType_h */
