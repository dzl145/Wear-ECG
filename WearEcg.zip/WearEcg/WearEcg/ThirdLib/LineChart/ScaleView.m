//
//  ScaleView.m
//  WearEcg
//
//  Created by dzl on 17/3/2.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "ScaleView.h"

@implementation ScaleView

-(instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    //画图
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    UIBezierPath* xPath1=[UIBezierPath bezierPath];
    CGPoint xStart1 = CGPointMake(0, self.frame.size.height / 2 + 15);
    CGPoint xEnd1 = CGPointMake(2.5, self.frame.size.height / 2 + 15);
    [xPath1 moveToPoint:xStart1];
    [xPath1 addLineToPoint:xEnd1];
    CGContextAddPath(ctx, xPath1.CGPath);
    [[UIColor redColor] set];
    CGContextSetLineWidth(ctx, 0.5);
    CGContextStrokePath(ctx);
    
    UIBezierPath* xPath2=[UIBezierPath bezierPath];
    CGPoint xStart2 = CGPointMake(2.5, self.frame.size.height / 2 + 15);
    CGPoint xEnd2 = CGPointMake(2.5, (self.frame.size.height / 2 + 15) - 25 * self.coefficient * 2);
    [xPath2 moveToPoint:xStart2];
    [xPath2 addLineToPoint:xEnd2];
    CGContextAddPath(ctx, xPath2.CGPath);
    [[UIColor redColor] set];
    CGContextSetLineWidth(ctx, 0.5);
    CGContextStrokePath(ctx);
    
    UIBezierPath* xPath3=[UIBezierPath bezierPath];
    CGPoint xStart3 = CGPointMake(2.5, (self.frame.size.height / 2 + 15) - 25 * self.coefficient * 2);
    CGPoint xEnd3 = CGPointMake(7.5, (self.frame.size.height / 2 + 15) - 25 * self.coefficient * 2);
    [xPath3 moveToPoint:xStart3];
    [xPath3 addLineToPoint:xEnd3];
    CGContextAddPath(ctx, xPath3.CGPath);
    [[UIColor redColor] set];
    CGContextSetLineWidth(ctx, 0.5);
    CGContextStrokePath(ctx);
    
    UIBezierPath* xPath4=[UIBezierPath bezierPath];
    CGPoint xStart4 = CGPointMake(7.5, (self.frame.size.height / 2 + 15) - 25 * self.coefficient * 2);
    CGPoint xEnd4 = CGPointMake(7.5, self.frame.size.height / 2 + 15);
    [xPath4 moveToPoint:xStart4];
    [xPath4 addLineToPoint:xEnd4];
    CGContextAddPath(ctx, xPath4.CGPath);
    [[UIColor redColor] set];
    CGContextSetLineWidth(ctx, 0.5);
    CGContextStrokePath(ctx);
    
    UIBezierPath* xPath5=[UIBezierPath bezierPath];
    CGPoint xStart5 = CGPointMake(7.5, self.frame.size.height / 2 + 15);
    CGPoint xEnd5 = CGPointMake(10, self.frame.size.height / 2 + 15);
    [xPath5 moveToPoint:xStart5];
    [xPath5 addLineToPoint:xEnd5];
    CGContextAddPath(ctx, xPath5.CGPath);
    [[UIColor redColor] set];
    CGContextSetLineWidth(ctx, 0.5);
    CGContextStrokePath(ctx);
}

@end
