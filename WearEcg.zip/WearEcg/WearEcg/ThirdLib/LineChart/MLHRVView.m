//
//  MLHRVView.m
//  HRV曲线
//
//  Created by maliangliang on 16/9/2.
//  Copyright © 2016年 maliangliang. All rights reserved.
//

#import "MLHRVView.h"
#import "UIView+Extension.h"

@interface MLHRVView()

@property(nonatomic,strong)NSMutableArray *rrnews;


@end
#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
@implementation MLHRVView

- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self=[super initWithFrame:frame]) {
        
        self.clearsContextBeforeDrawing = YES;
        
    }
    
    return self;
}

- (void)test{
    
    
}
- (void)drawRect:(CGRect)rect {
    
    [super drawRect:rect];
    
    /**
     *  这一步主要是屏蔽第一次启动时调用drawRect，将无效的值传入self.rrnews数组
     */
    if (self.isPass==NO) {
        
        return;
    }
    
    int mDrawHeight = rect.size.height;
    int  mDrawWidth = rect.size.width;
    int space = 15;
    int max_rrNew_count = mDrawWidth/space;
    
    [self.rrnews addObject:@(self.rrNew)];
    
    if (self.rrnews.count<2) {
        
        return;
    }

    if (self.rrnews.count>max_rrNew_count+1) {
        
        [self.rrnews removeObjectAtIndex:0];
    }
    
    int maxRR = [[self.rrnews valueForKeyPath:@"@max.intValue"] intValue];
    int minRR = [[self.rrnews valueForKeyPath:@"@min.intValue"] intValue];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetLineWidth(context, 2);
    CGContextSetStrokeColorWithColor(context, [UIColor greenColor].CGColor);
    CGContextSetLineCap(context, kCGLineCapRound);
    CGContextSetLineJoin(context, kCGLineJoinRound);
    
    //阴影
    
    CGContextRef context2=UIGraphicsGetCurrentContext();
    CGContextMoveToPoint(context2, 10, self.frame.size.height-45);
    
    //        int xx=-1;
    for (int i=0; i<self.rrnews.count; i++) {
        int cc=[self.rrnews[i] intValue];
        //            for (int j=0; j<4; j++) {
        //                xx++;
        //                cc+=[array[xx] intValue];
        //            }
        
        NSLog(@"cc:%d",cc);
        //            if (i==0) {
        //                CGContextMoveToPoint(context2, 10, self.frame.size.height-45-  (self.frame.size.height-80)/max*cc);  // 刻度为5000  y=计算后的值
        //            }else{
        CGContextAddLineToPoint(context2, 10+i*space+space, self.frame.size.height-  (self.frame.size.height-80)/5*cc-45);// 同上
        //            }
        
    }
    CGContextAddLineToPoint(context2, 10+self.rrnews.count*space, self.frame.size.height-45);// 阴影是要填充的，最后 一个点 构成不规则矩形。
    //        [[UIColor greenColor]setFill];
    [[UIColor colorWithRed:1 green:1 blue:1 alpha:.5] setFill];
    CGContextFillPath(context2);  //填充路径
    
    int y = 0;
    int oldX = 0;
    int firstValue = [self.rrnews[0] intValue];
    int value = (maxRR != minRR) ? (firstValue - minRR)*mDrawHeight/(maxRR-minRR) : mDrawHeight/2;
    int oldY = value;
    
    for (int i=1; i<self.rrnews.count; i++) {
        
        y =  (maxRR != minRR) ? ([self.rrnews[i] intValue] - minRR)*mDrawHeight/(maxRR-minRR) : mDrawHeight/2;;
        
        if (i==1) {
            
            CGContextMoveToPoint(context, oldX, value);
        }
        //
        //        oldX = i*xStep;
        //
        //        oldY = y;
        //
        //
        //        CGContextAddLineToPoint(context, i*xStep, y);
        /**
         *   cpY时控制点y值
         */
        int cpY = 0;
        if (oldY>y) {
            
            cpY = 0+2;
            //cpY = mDrawHeight-2;
            
        }else{
            //cpY = 0+2;
            
            cpY = mDrawHeight-2;
        }
        
        // CGContextAddQuadCurveToPoint(context, oldX+space/2, cpY, i*space, y);
        CGContextAddCurveToPoint(context, oldX+space/3, cpY, oldX+2*space/3, cpY, i*space, y);
        oldX = i*space;
        
        oldY = y;
        
    }
    
    CGContextStrokePath(context);
    
    
}

- (void)setRrNew:(int)rrNew{
    
    _rrNew = rrNew;
    
    [self setNeedsDisplay];
    
}



- (NSMutableArray *)rrnews{
    
    if (!_rrnews) {
        
        _rrnews = [NSMutableArray array];
    }
    
    return _rrnews;
    
}

@end
