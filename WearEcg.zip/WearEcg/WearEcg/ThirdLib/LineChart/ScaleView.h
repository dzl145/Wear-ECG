//
//  ScaleView.h
//  WearEcg
//
//  Created by dzl on 17/3/2.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScaleView : UIView

@property (nonatomic, assign) CGFloat coefficient;

@end
