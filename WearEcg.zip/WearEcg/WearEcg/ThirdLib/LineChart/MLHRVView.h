//
//  MLHRVView.h
//  HRV曲线
//
//  Created by maliangliang on 16/9/2.
//  Copyright © 2016年 maliangliang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MLHRVView : UIView

/**
 *  传递的值
 */
@property(nonatomic,assign)int rrNew;
/**
 *  开始画图时isPass属性设置为YES
 */
@property(nonatomic,assign)BOOL isPass;


@end
