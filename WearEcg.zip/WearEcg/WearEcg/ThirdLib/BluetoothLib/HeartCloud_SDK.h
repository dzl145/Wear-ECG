//
//  HeartCloud_SDK.h
//  WearEcg
//
//  Created by 丁子龙 on 16/12/8.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "AU_SDK_CONSTANTS.h"


/**
 *  设备连接状态
 */
typedef NS_ENUM(NSInteger, BleManagerState) {
    /**
     * 未连接
     */
    BleManagerStateDisconnect = 0,
    
    /**
     * 已连接
     */
    BleManagerStateConnect,
};



@protocol HeartCloud_SDK_Delegate <NSObject>

@optional


#pragma mark - 回调API一览

/*****************************************************************
 * 回调API一览
 *****************************************************************/
// 回调通知：设备连接状况变化
- (void)device:(NSString *)uuid stateChanged:(AU_BLE_STATE)state userInfo:(NSDictionary *)advertisementData withperipheral:(CBPeripheral *)peripheral withRSSI:(NSNumber *)RSSI;

// 回调通知：APP接收命令结果
- (void)device:(NSString *)uuid didReceiveData:(NSData *)data error:(NSError *)error;

@end


@interface HeartCloud_SDK : NSObject

/**
 * 设备管理 单利
 */
+ (HeartCloud_SDK *)sharedManager;


@property (nonatomic, assign) id <HeartCloud_SDK_Delegate> delegate;

#pragma mark - 命令API一览
/*****************************************************************
 * 命令API一览
 *****************************************************************/

// 进入添加设备模式（开始扫描BLE设备）
// 成功发现设备后，会在回调方法[-device: stateChanged: userInfo:]中给出"AU_BLE_STATE_FOUND_NEW_DEVICE"通知
- (AU_RESULT_START_ADDING_MODE)startAddingMode;

// 退出添加设备模式（停止扫描BLE设备）
- (void)stopAddingMode;

// 连接指定的"新发现的"BLE设备(通过明确的UUID值)
// 成功连接设备后，会在回调方法[-device: stateChanged: userInfo:]中得到"AU_BLE_STATE_CONNECTED"通知
- (void)connectNewFoundDevice:(NSString *)uuid withPeripheral:(CBPeripheral *)withPeripheral;

// 连接指定的"已保存的"BLE设备(通过明确的UUID值)
// 成功连接设备后，会在回调方法[-device: stateChanged: userInfo:]中得到"AU_BLE_STATE_CONNECTED"通知
- (void)reConnectKnownDevice:(NSString *)uuid;

// 查询指定BLE设备的链接状态(通过明确的UUID值)
- (BOOL)isConnected:(NSString *)uuid;

// 断开指定BLE设备(通过明确的UUID值)
// 成功断开连接后，会在回调方法[-device: stateChanged: userInfo:]中得到"AU_BLE_STATE_DISCONNECTED"通知
- (void)disconnectDevice:(NSString *)uuid;

// 向指定已连接BLE设备发送命令(通过明确的UUID值)
- (AU_RESULT_SEND_DATA)sendData:(NSData *)data toDevice:(NSString *)uuid;

// 设置与指定BLE设备的连接间隔(通过明确的UUID值)
// 连接间隔需要在每次建立连接后重新设置，没有设置情况下，每次重新连接后，都会回复默认值(30ms)
// value的有效值域为：0x02〜0x20
- (AU_RESULT_CONFIG_DEVICE)configDevice:(NSString *)uuid connectionInterval:(AU_CONNECTION_INTERVAL)value;

@end
