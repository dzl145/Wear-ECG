typedef NS_ENUM(NSInteger, AU_BLE_STATE) {
    AU_BLE_STATE_UNKNOWN,                           /* 未知状态 */
    AU_BLE_STATE_FOUND_NEW_DEVICE,                  /* 发现新的BLE设备 */
    AU_BLE_STATE_CONNECTED,                         /* BLE设备已连接，准备初始化（注意：此时尚不能正常工作） */
    AU_BLE_STATE_READY,                             /* BLE设备已可以正常工作 */
    AU_BLE_STATE_DISCONNECTED                       /* BLE设备已断开 */
};

typedef NS_ENUM(NSInteger, AU_RESULT_START_ADDING_MODE) {
    AU_RESULT_START_ADDING_MODE_BLE_UNKNOWN,        /* 未知状态 */
    AU_RESULT_START_ADDING_MODE_OK,                 /* 成功进入添加新设备模式 */
    AU_RESULT_START_ADDING_MODE_BLE_OFF,            /* 当前iOS系统的蓝牙开关处于OFF状态，需要用户手动设置为ON */
    AU_RESULT_START_ADDING_MODE_BLE_UNSUPPORTED     /* 当前iOS设备不支持蓝牙4.0 */
};

typedef NS_ENUM(NSInteger, AU_RESULT_SEND_DATA) {
    AU_RESULT_SEND_DATA_UNKNOWN,                    /* 未知状态 */
    AU_RESULT_SEND_DATA_OK,                         /* 数据已发出 (注意：不等于BLE已接收到数据) */
    AU_RESULT_SEND_DATA_BLE_OFF,                    /* 当前iOS系统的蓝牙开关处于OFF状态，需要用户手动设置为ON */
    AU_RESULT_SEND_DATA_DEVICE_DISCONNECTED,        /* 当前目标BLE设备处于未连接状态，发送数据需要在成功连接目标BLE设备后 */
    AU_RESULT_SEND_DATA_VALUE_OUT_OF_RANGE          /* 参数长度出界 (要求0字节以上，最大不超过20字节) */
};

typedef NS_ENUM(NSInteger, AU_RESULT_CONFIG_DEVICE) {
    AU_RESULT_CONFIG_DEVICE_UNKNOWN,                /* 未知状态 */
    AU_RESULT_CONFIG_DEVICE_OK,                     /* 设置命令数据已发出 (注意：不等于BLE已接收到设置数据) */
    AU_RESULT_CONFIG_DEVICE_BLE_OFF,                /* 当前iOS系统的蓝牙开关处于OFF状态，需要用户手动设置为ON */
    AU_RESULT_CONFIG_DEVICE_DEVICE_DISCONNECTED,    /* 当前目标BLE设备处于未连接状态，发送设置数据需要在成功连接目标BLE设备后 */
    AU_RESULT_CONFIG_DEVICE_VALUE_OUT_OF_RANGE      /* 参数出界，只允许使用枚举类型"AU_CONNECTION_INTERVAL"里规定的值 */
};

typedef NS_ENUM(NSInteger, AU_CONNECTION_INTERVAL) {
    AU_CONNECTION_INTERVAL_INFINITY     = 0x00,     /* 间隔无限大(即断开BLE连接) */
    AU_CONNECTION_INTERVAL_20ms         = 0x02,     /* 间隔20ms  */
    AU_CONNECTION_INTERVAL_30ms         = 0x03,     /* 间隔30ms  */
    AU_CONNECTION_INTERVAL_40ms         = 0x04,     /* 间隔40ms  */
    AU_CONNECTION_INTERVAL_50ms         = 0x05,     /* 间隔50ms  */
    AU_CONNECTION_INTERVAL_60ms         = 0x06,     /* 间隔60ms  */
    AU_CONNECTION_INTERVAL_70ms         = 0x07,     /* 间隔70ms  */
    AU_CONNECTION_INTERVAL_80ms         = 0x08,     /* 间隔80ms  */
    AU_CONNECTION_INTERVAL_90ms         = 0x09,     /* 间隔90ms  */
    AU_CONNECTION_INTERVAL_100ms        = 0x0A,     /* 间隔100ms */
    AU_CONNECTION_INTERVAL_110ms        = 0x0B,     /* 间隔110ms */
    AU_CONNECTION_INTERVAL_120ms        = 0x0C,     /* 间隔120ms */
    AU_CONNECTION_INTERVAL_130ms        = 0x0D,     /* 间隔130ms */
    AU_CONNECTION_INTERVAL_140ms        = 0x0E,     /* 间隔140ms */
    AU_CONNECTION_INTERVAL_150ms        = 0x0F,     /* 间隔150ms */
    AU_CONNECTION_INTERVAL_160ms        = 0x10,     /* 间隔160ms */
    AU_CONNECTION_INTERVAL_170ms        = 0x11,     /* 间隔170ms */
    AU_CONNECTION_INTERVAL_180ms        = 0x12,     /* 间隔180ms */
    AU_CONNECTION_INTERVAL_190ms        = 0x13,     /* 间隔190ms */
    AU_CONNECTION_INTERVAL_200ms        = 0x14,     /* 间隔200ms */
    AU_CONNECTION_INTERVAL_210ms        = 0x15,     /* 间隔210ms */
    AU_CONNECTION_INTERVAL_220ms        = 0x16,     /* 间隔220ms */
    AU_CONNECTION_INTERVAL_230ms        = 0x17,     /* 间隔230ms */
    AU_CONNECTION_INTERVAL_240ms        = 0x18,     /* 间隔240ms */
    AU_CONNECTION_INTERVAL_250ms        = 0x19,     /* 间隔250ms */
    AU_CONNECTION_INTERVAL_260ms        = 0x1A,     /* 间隔260ms */
    AU_CONNECTION_INTERVAL_270ms        = 0x1B,     /* 间隔270ms */
    AU_CONNECTION_INTERVAL_280ms        = 0x1C,     /* 间隔280ms */
    AU_CONNECTION_INTERVAL_290ms        = 0x1D,     /* 间隔290ms */
    AU_CONNECTION_INTERVAL_300ms        = 0x1E,     /* 间隔300ms */
    AU_CONNECTION_INTERVAL_310ms        = 0x1F,     /* 间隔310ms */
    AU_CONNECTION_INTERVAL_320ms        = 0x20      /* 间隔320ms */
};