//
//  HeartCloud_SDK.m
//  WearEcg
//
//  Created by 丁子龙 on 16/12/8.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "HeartCloud_SDK.h"

#define UUID_DEVICE_SERVER_0  @"6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define UUID_DEVICE_SERVER_1  @"6E400003-B5A3-F393-E0A9-E50E24DCCA9E"
#define UUID_DEVICE_SERVER_2  @"6E400002-B5A3-F393-E0A9-E50E24DCCA9E"

@interface HeartCloud_SDK ()<CBCentralManagerDelegate, CBPeripheralDelegate>
{
    CBPeripheral *_devicePeripheral;    //设备
    
    CBCharacteristic *_deviceCharacteristic;    //设备服务特征 （用来发送指令）
    
    CBCentralManager *_manager;         //
    BOOL hasSend;
    
}

/**
 * 连接状态
 */
@property (assign, nonatomic) BleManagerState deviceBleState;
@end

@implementation HeartCloud_SDK

#pragma mark - 单例
+ (HeartCloud_SDK *)sharedManager {
    static HeartCloud_SDK *sharedManager = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        sharedManager = [[self alloc] init];
    });
    return sharedManager;
}

- (instancetype)init {
    if (self = [super init]) {
        hasSend = NO;
        [self customInit];
    }
    return self;
}

- (void)customInit {
    
    _deviceBleState = BleManagerStateDisconnect;
    
    //建立中心角色
    _manager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    _manager.delegate = self;
    
}

#pragma mark - 搜索设备
- (void)searchDeviceModule
{
    [_manager scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:@NO}];
}
#pragma mark - 进入添加设备模式
- (AU_RESULT_START_ADDING_MODE)startAddingMode
{
    NSLog(@"开始扫描");
    [self searchDeviceModule];
    AU_RESULT_START_ADDING_MODE result = AU_RESULT_START_ADDING_MODE_OK;
    return result;
}
#pragma mark - 退出添加设备模式
- (void)stopAddingMode
{
    if (_manager) {
        [_manager stopScan];
    }
}
#pragma mark - 连接指定的"新发现的"BLE设备
- (void)connectNewFoundDevice:(NSString *)uuid withPeripheral:(CBPeripheral *)peripheral
{
    if (peripheral) {
        _devicePeripheral = peripheral;
    }
    [_manager connectPeripheral:_devicePeripheral options:nil];
}
#pragma mark - 连接指定的"已保存的"BLE设备
- (void)reConnectKnownDevice:(NSString *)uuid {
    NSLog(@"已保存的设备");
}
#pragma mark - 查询指定BLE设备的链接状态
- (BOOL)isConnected:(NSString *)uuid {
    NSLog(@"蓝牙的连接状态");
    if ([UUID_DEVICE_SERVER_0 isEqual:uuid]) {
        if (_deviceBleState == BleManagerStateConnect) {
            return YES;
        } else {
            return NO;
        }
    }
    return NO;
    
}

#pragma mark - 断开指定BLE设备
- (void)disconnectDevice:(NSString *)uuid {
    [_manager cancelPeripheralConnection:_devicePeripheral];
    
}
#pragma mark - 向指定已连接BLE设备发送命令
- (AU_RESULT_SEND_DATA)sendData:(NSData *)data toDevice:(NSString *)uuid {
    if ([uuid isEqual:UUID_DEVICE_SERVER_0]) {
        
        [_devicePeripheral writeValue:data forCharacteristic:_deviceCharacteristic type:CBCharacteristicWriteWithResponse];
        return AU_RESULT_SEND_DATA_OK;
    }
    else {
        return AU_RESULT_SEND_DATA_UNKNOWN;
    }
}
#pragma mark - 设置与指定BLE设备的连接间隔
- (AU_RESULT_CONFIG_DEVICE)configDevice:(NSString *)uuid connectionInterval:(AU_CONNECTION_INTERVAL)value {
    return AU_RESULT_CONFIG_DEVICE_OK;
}
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    NSString *stateStr;
    switch (central.state) {
        case CBCentralManagerStateUnknown :
            stateStr = @"当前蓝牙状态未知，请重试";
            break;
        case CBCentralManagerStateUnsupported:
            stateStr = @"当前设备不支持蓝牙设备连接";
            break;
        case CBCentralManagerStateUnauthorized:
            stateStr = @"请前往设置开启蓝牙授权并重试";
            break;
        case CBCentralManagerStatePoweredOff:
            stateStr = @"蓝牙关闭，请开启";
            break;
        case CBCentralManagerStateResetting:
            break;
        case CBCentralManagerStatePoweredOn:
        {
            //扫描外设(discover)
            NSLog(@"扫描外设正常");
            [self searchDeviceModule];
        }
            break;
        default:
            stateStr = [NSString stringWithFormat:@"蓝牙异常 %d",(int)central.state];
            break;
    }
}

/**
 #pragma mark - >> 这里开始蓝牙的代理方法
 */
#pragma mark - >> 发现蓝牙设备
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI {
    NSLog(@"发现设备%@",peripheral.name);
    if (!peripheral.name) {
        return;
    }
    if (_devicePeripheral != peripheral) {
        _devicePeripheral = peripheral;
    }
    
    //设备
    if ([self.delegate respondsToSelector:@selector(device:stateChanged:userInfo:withperipheral:withRSSI:)]) {
        [self.delegate device:UUID_DEVICE_SERVER_0 stateChanged:AU_BLE_STATE_FOUND_NEW_DEVICE userInfo:advertisementData withperipheral:peripheral withRSSI:RSSI];
    }
    
}

#pragma mark - >> 连接成功
- (void)centralManager:(CBCentralManager *)central
  didConnectPeripheral:(CBPeripheral *)peripheral {
    _deviceBleState = BleManagerStateConnect;
    NSLog(@"连接成功");
    if (!peripheral.name) {
        return;
    }
    NSDictionary *dic = [NSDictionary dictionaryWithObject:peripheral.name forKey:@"name"];
    peripheral.delegate = self;
    if ([self.delegate respondsToSelector:@selector(device:stateChanged:userInfo:withperipheral:withRSSI:)]) {
        [self.delegate device:UUID_DEVICE_SERVER_0 stateChanged:AU_BLE_STATE_READY userInfo:dic withperipheral:peripheral withRSSI:nil];
    }
    //因为在后面我们要从外设蓝牙那边再获取一些信息，并与之通讯，这些过程会有一些事件可能要处理，所以要给这个外设设置代理
    //找到该设备上的指定服务 调用完该方法后会调用代理CBPeripheralDelegate（现在开始调用另一个代理的方法了）
    [peripheral discoverServices:@[[CBUUID UUIDWithString:UUID_DEVICE_SERVER_0]]];
    [self stopAddingMode];   //停止扫描设备
}

#pragma mark - >> 连接失败
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    
    _deviceBleState = BleManagerStateDisconnect;
    NSLog(@"连接失败:%@", peripheral.name);
}

#pragma mark - >> 断开连接
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"断开连接:%@  断开原因:%@   长度:%ld", peripheral.name,error.userInfo,(long)error.code);
    _deviceBleState = BleManagerStateDisconnect;
    if (!peripheral.name) {
        return;
    }
    if (error.code > 0) {
        if ([self.delegate respondsToSelector:@selector(device:stateChanged:userInfo:withperipheral:withRSSI:)]) {
            [self.delegate device:UUID_DEVICE_SERVER_0 stateChanged:AU_BLE_STATE_DISCONNECTED userInfo:nil withperipheral:nil withRSSI:nil];
        }
    }
    
}

#pragma mark - >> CBPeripheralDelegate
#pragma mark - >> 发现服务
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
    if (error == nil) {
        for (CBService *service in peripheral.services) {
            //设备
            if ([service.UUID isEqual:[CBUUID UUIDWithString:UUID_DEVICE_SERVER_0]]) {
                //查询服务所带的特征值
                for (CBService *service in peripheral.services) {
                    [peripheral discoverCharacteristics:@[[CBUUID UUIDWithString:UUID_DEVICE_SERVER_1], [CBUUID UUIDWithString:UUID_DEVICE_SERVER_2]] forService:service];
                }
            }
        }
    }
}

#pragma mark - >> 发现特征值
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
    NSLog(@"返回值%ld", (long)peripheral.state);
    //在这里给 蓝牙设备写数据， 或者将 peripheral 和 characteristic 拿出去，可以在其他地方，发送命令
    if (error == nil) {
        for (CBCharacteristic *characteristic in service.characteristics) {
            [peripheral readValueForCharacteristic:characteristic];
            [peripheral discoverDescriptorsForCharacteristic:characteristic];
            if (_devicePeripheral == peripheral) {
                if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:UUID_DEVICE_SERVER_1]]) {
                    [peripheral setNotifyValue:YES forCharacteristic:characteristic];
                }
                else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:UUID_DEVICE_SERVER_2]]) {
                    _deviceCharacteristic = characteristic;
                    
                }
            }
        }
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    for (CBDescriptor * descriptor in characteristic.descriptors) {
        [peripheral readValueForDescriptor:descriptor];
    }
}

#pragma mark - >> 读数据
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
//    NSLog(@"读取数据%@", characteristic.value);
    if (error) {
        NSLog(@"error == %@",error);
        return;
    }
    if ([self.delegate respondsToSelector:@selector(device:didReceiveData:error:)]) {
        [self.delegate device:UUID_DEVICE_SERVER_0 didReceiveData:characteristic.value error:error];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    //    NSLog(@"did write value For Characteristic");
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error {
    //打印出DescriptorsUUID 和value
    //这个descriptor都是对于characteristic的描述，一般都是字符串，所以这里我们转换成字符串去解析
    NSLog(@"characteristic uuid:%@  value:%@",[NSString stringWithFormat:@"%@",descriptor.UUID],descriptor.value);
}

@end
