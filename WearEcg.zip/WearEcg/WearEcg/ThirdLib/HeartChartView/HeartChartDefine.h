//
//  HeartChartDefine.h
//  WearEcg
//
//  Created by dzl on 17/2/17.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#ifndef CharDefine_h
#define CharDefine_h


//图表视图的高度 (显示图表内容视图的高为 减去40  Y轴间隔的倍数)
#define CharViewHeight  247
//y轴坐标文字的宽度
#define YLabelWidth     36

//滚动层测最小和最大宽度
#define MinScrollWidth  1200
#define MaxScrollWidth  5000

//像素间隔值
#define XIntervalValue  60
#define YIntervalValue  23

//数据间隔值
#define XDataIntervalValue  1
#define YDataIntervalValue  20

//视图X轴方向 滚动页面展示方式
typedef NS_ENUM(NSUInteger, CharViewXShowStyle) {
    
    CharViewXShowStyle_ValueInterval = 1,      //固定的值间隔(只考虑值的间隔 不考虑滚动区域长度)
    
    CharViewXShowStyle_ScrollWidth,            //固定的滚动区域(根据内容的多少，分段固定长度  根据长度计算值间隔)
    
    CharViewXShowStyle_Auto,                   //自动分配间隔，设置滚动长度最小值和最大值
};

//视图X轴方向 显示值的样式
typedef NS_ENUM(NSUInteger, CharViewXValueStyle) {
    
    CharViewXValueStyle_Number = 1,            //数字
    
    CharViewXValueStyle_Date,                  //时间 (间隔用秒 计算)
};


#endif /* CharDefine_h */
