//
//  HeartChartYView.m
//  WearEcg
//
//  Created by dzl on 17/2/17.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "HeartChartYView.h"

@implementation HeartChartYView

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _yInterval = 0;
        _yValueInterval = 0;
        valueNum = 0;
    }
    return self;
}

- (NSArray *)colorArray {
    if (_colorArray == nil) {
        _colorArray = [[NSArray alloc]init];
    }
    return _colorArray;
}


-(void)setValueForInterval:(CGFloat)yInterval value:(CGFloat)yValueInterval colorArray:(NSArray *)array{
    
    self.colorArray = array;
    _yInterval = yInterval;
    _yValueInterval = yValueInterval;
    //计算Y轴坐标个数
    valueNum = self.frame.size.height/_yInterval;
    [self setNeedsDisplay];
}


//绘画Y坐标轴 和 显示背景颜色
-(void)drawRect:(CGRect)rect {
    if (valueNum <= 0) {
        return;
    }
    NSArray *arrColor = self.colorArray;
    for(float value = 1; value <= valueNum; value ++) {
        //背景颜色
        if (value == 1 || value <= 2) {
            [self drawBackColor:value color:[arrColor objectAtIndex:0]];
        }
        else if (value == 3) {
            [self drawBackColor:value color:[arrColor objectAtIndex:1]];
        }
        else if (value == 4 || value == 5) {
            [self drawBackColor:value color:[arrColor objectAtIndex:2]];
        }
        else if (value == 6) {
            [self drawBackColor:value color:[arrColor objectAtIndex:3]];
        }
        else if (value >= 7) {
            [self drawBackColor:value color:[arrColor objectAtIndex:4]];
        }
    }
    
    //    NSArray * arrColor = [NSArray arrayWithObjects:
    //                          [UIColor colorWithRed:0.008 green:0.545 blue:0.792 alpha:0.200],
    //                          [UIColor colorWithRed:0.129 green:0.816 blue:0.776 alpha:0.200],
    //                          [UIColor colorWithRed:0.427 green:0.741 blue:0.094 alpha:0.200],
    //                          [UIColor colorWithRed:0.898 green:0.514 blue:0.031 alpha:0.200],
    //                          [UIColor colorWithRed:0.839 green:0.125 blue:0.008 alpha:0.200], nil];
    
    
    for(float value = 1; value <= valueNum; value ++) {
        
        if (value < valueNum) {
            CGPoint point = [self pointForValue:value atPos:YES];
            //画虚线
            UIBezierPath *bezier = [[UIBezierPath alloc] init];
            [bezier moveToPoint:point];
            [bezier addLineToPoint:[self pointForValue:value atPos:NO]];
            [bezier setLineWidth:1.f];
            [bezier setLineCapStyle:kCGLineCapSquare];
            CGFloat dashPattern[2] = {6., 3.};
            [bezier setLineDash:dashPattern count:2 phase:0];
            [[UIColor colorWithRed:178/255. green:178/255. blue:178/255. alpha:.7f] set];
            [bezier stroke];
            
            //画坐标轴数字
            [self drawYAxisLabel:value];
        }
        
        
    }
}

-(void)drawBackColor:(NSInteger)index color:(UIColor *)color {
    CGPoint point = [self pointForValue:index atPos:YES];
    CGFloat width = self.frame.size.width;
    //    UIBezierPath *p = [UIBezierPath bezierPath];
    //    if (_yValueInterval == 20) {
    //        if (index == 3) {
    //            p = [UIBezierPath bezierPathWithRect:CGRectMake(0,point.y + self.yInterval / 2,width,self.yInterval / 2)];
    //        }
    //        else if (index == 4) {
    //            p = [UIBezierPath bezierPathWithRect:CGRectMake(0,point.y,width,self.yInterval  + self.yInterval / 2)];
    //        }
    //        else {
    //            p = [UIBezierPath bezierPathWithRect:CGRectMake(0,point.y,width,self.yInterval)];
    //        }
    //    }
    //    else {
    //        if (index == 3) {
    //            p = [UIBezierPath bezierPathWithRect:CGRectMake(0,point.y,width,self.yInterval)];
    //        }
    //        else {
    //            p = [UIBezierPath bezierPathWithRect:CGRectMake(0,point.y,width,self.yInterval)];
    //        }
    //    }
    UIBezierPath* p = [UIBezierPath bezierPathWithRect:CGRectMake(2,point.y,width,self.yInterval)];
    
    [color setFill];
    [p fill];
}

//添加Y坐标点
- (void)drawYAxisLabel:(NSInteger)index{
    CGPoint point = [self pointForValue:index atPos:YES];
    
    CGRect strFrame = CGRectMake(12, point.y-7, YLabelWidth, 12);
    NSDictionary * dayDict = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"HelveticaNeue-Bold" size:11.0],NSFontAttributeName,[UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1],NSForegroundColorAttributeName, nil];
    [[UIColor redColor] set];
    NSString * strY = [NSString stringWithFormat:@"%d",(int)(index * _yValueInterval)];
    [strY drawInRect:strFrame withAttributes:dayDict];
}


#pragma mark --- Value to point convertion
//转换坐标  isStart 是否为开始点  否则为结束点
- (CGPoint)pointForValue:(NSInteger)index atPos : (BOOL)isStart{
    float x = 0;
    if (isStart) {
        x = YLabelWidth;
    }
    else{
        x = self.frame.size.width;
    }
    float y = self.frame.size.height - self.yInterval * index;
    return CGPointMake(x, y);
}

@end
