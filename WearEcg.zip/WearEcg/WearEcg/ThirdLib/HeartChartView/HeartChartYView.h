//
//  HeartChartYView.h
//  WearEcg
//
//  Created by dzl on 17/2/17.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartChartDefine.h"

@interface HeartChartYView : UIView

{
    //Y轴的坐标个数
    NSInteger valueNum;
}

//Y坐标间隔宽度
@property (assign,nonatomic,readonly) CGFloat yInterval;

//Y坐标数值的间隔
@property (assign,nonatomic,readonly) CGFloat yValueInterval;

@property (nonatomic, retain)NSArray *colorArray;

//赋值 重新画图
-(void)setValueForInterval:(CGFloat)yInterval value:(CGFloat)yValueInterval colorArray:(NSArray *)array;

@end
