//
//  HeartChartView.h
//  WearEcg
//
//  Created by dzl on 17/2/17.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartChartYView.h"
#import "HeartChartScrollView.h"

@interface HeartChartView : UIView<UIScrollViewDelegate>

{
    //记录开始时间
    NSDate *startDate;
    //记录开始数据
    CGFloat startNumber;
    //X轴显示数据的展示方式
    CharViewXShowStyle _showStyle;
    //X轴左边点 样式(数值还是时间？)
    CharViewXValueStyle _valueStyle;
    //两个数据间的像素间隔
    CGFloat _pxInterval;
    //X坐标间隔宽度
    CGFloat _xInterval;
    //X坐标数值的间隔
    CGFloat _xValueInterval;
    //X轴 固定总宽度（CharViewXShowStyle_ScrollWidth 才有用）
    CGFloat _xtotalWidth;
    
}


//显示提示数据视图
@property(strong,nonatomic,readonly) UIView * tipView;

//文本
@property(strong,nonatomic,readonly) UILabel * tipLabel;

//数据数组
@property (strong,nonatomic,readonly) NSArray * arrayData;

//图表滚动视图
@property(strong,nonatomic) UIScrollView * scrollview;

//内容子视图
@property(strong,nonatomic)HeartChartScrollView * contentView;


/*
 * 初始化X轴为时间数据 (CharViewXValueStyle_Date 类型)
 *
 */
- (id)initWithFrame:(CGRect)frame objectsArray:(NSArray *)theObjectsArray startDate:(NSDate *)theStartDate showStyle:(CharViewXShowStyle)showStyle colorArray:(NSArray *)array YDataValue:(int)yDataValue XDataValue:(int)xDataValue;


/*
 * 初始化X轴为数字数据 (CharViewXValueStyle_Number 类型)
 *
 */
- (id)initWithFrame:(CGRect)frame objectsArray:(NSArray *)theObjectsArray startNumber:(CGFloat)theStartNumber showStyle : (CharViewXShowStyle)showStyle;


/*
 * 设置滚动区域的宽度 (当X显示方式为 CharViewXShowStyle_ScrollWidth 类型时)调用此方法 其它无效
 *
 */
- (void)setScrollWidthForXshow : (CGFloat)width;

@end
