//
//  CoreData.m
//  WearEcg
//
//  Created by dzl on 17/1/17.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "CoreData.h"
#import "RecordModel.h"

@implementation CoreData
@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;

- (void)saveContext {
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            //这个实现替换为适当的代码来处理错误
            //abort()会导致应用程序生成一个崩溃日志和终止,你不应该使用这个函数在船舶应用中,虽然他可能是有用的在开发过程中
            NSLog(@"Unresolved error %@, %@",error,[error userInfo]);
            abort();
        }
    }
}

#pragma mark - Core Data stack
//返回应用程序的管理对象上下文,如果不存在,就创建并绑定到应用程序的持久性存储协调员
//托管对象上下文类似于应用程序和数据存储之间的一块缓冲区,这块缓冲区包含所有未被写入数据存储的托管对象,你可以添加 、删除、更改缓冲区的托管对象,在很多时候,当你需要读、插入、删除对象时,你将会调用托管对象上下文的方法.
- (NSManagedObjectContext *)managedObjectContext {
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        _managedObjectContext = [[NSManagedObjectContext alloc]init];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return _managedObjectContext;
}

//返回应用程序的托管对象模型,如果模型不存在,它从应用程序的创建模型
- (NSManagedObjectModel *)managedObjectModel {
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Model" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc]initWithContentsOfURL:modelURL];
    _managedObjectModel = [NSManagedObjectModel mergedModelFromBundles:nil];
    return _managedObjectModel;
//    if (!_managedObjectModel) {
//        _managedObjectModel = [NSManagedObjectModel mergedModelFromBundles:nil];
//    }
//    return _managedObjectModel;
}

//返回应用程序的持久存储协调员,如果协调不存在,这是创建和应用程序的商店添加到它
- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"Model.sqlite"];
    NSError *error = nil;
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc]initWithManagedObjectModel:[self managedObjectModel]];
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
//        NSLog(@"Unresolved error %@, %@",error, [error userInfo]);
//        abort();
        [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"syncVersion"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error];
    }
    return _persistentStoreCoordinator;
}

#pragma mark - Application Documents directory
//将URL返回给应用程序的文档目录
- (NSURL *)applicationDocumentsDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

//插入数据
- (void)insertCoreData:(NSMutableArray *)dataArray {
    NSManagedObjectContext *context = [self managedObjectContext];
    for (RecordModel *info in dataArray) {
        RecordEntity *recordInfo = [NSEntityDescription insertNewObjectForEntityForName:TableName inManagedObjectContext:context];
        recordInfo.starttime = info.starttime;
        recordInfo.endtime = info.endtime;
        recordInfo.heartrate = info.heartrate;
//        recordInfo.filename = info.filename;
//        recordInfo.filepath = info.filepath;
//        recordInfo.filetype = info.filetype;
        
        NSError *error;
        if(![context save:&error]) {
            NSLog(@"不能保存：%@",[error localizedDescription]);
        }
    }
}

//查询
- (NSMutableArray *)selectData:(int)pageSize andOffset:(int)currentPage
{
    NSManagedObjectContext *context = [self managedObjectContext];
    
    // 限定查询结果的数量
    //setFetchLimit
    // 查询的偏移量
    //setFetchOffset
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
//    [fetchRequest setFetchLimit:pageSize];
//    [fetchRequest setFetchOffset:currentPage];
    
    NSEntityDescription *entity = [NSEntityDescription entityForName:TableName inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    NSError *error;
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    NSMutableArray *resultArray = [NSMutableArray array];
    
    for (RecordEntity *info in fetchedObjects) {
//        NSLog(@"id:%@", info.newsid);
//        NSLog(@"title:%@", info.title);
        [resultArray addObject:info];
    }
    return resultArray;
}

//删除
-(void)deleteData
{
    NSManagedObjectContext *context = [self managedObjectContext];
    NSEntityDescription *entity = [NSEntityDescription entityForName:TableName inManagedObjectContext:context];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setIncludesPropertyValues:NO];
    [request setEntity:entity];
    NSError *error = nil;
    NSArray *datas = [context executeFetchRequest:request error:&error];
    if (!error && datas && [datas count])
    {
        for (NSManagedObject *obj in datas)
        {
            [context deleteObject:obj];
        }
        if (![context save:&error])
        {
            NSLog(@"error:%@",error);
        }
    }
}

//更新
- (void)updateData:(NSString*)newsId  withIsLook:(NSString*)islook
{
    NSManagedObjectContext *context = [self managedObjectContext];
    
    NSPredicate *predicate = [NSPredicate
                              predicateWithFormat:@"newsid like[cd] %@",newsId];
    
    //首先你需要建立一个request
    NSFetchRequest * request = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:TableName inManagedObjectContext:context]];
    [request setPredicate:predicate];//这里相当于sqlite中的查询条件，具体格式参考苹果文档
    
    //https://developer.apple.com/library/mac/#documentation/Cocoa/Conceptual/Predicates/Articles/pCreating.html
    NSError *error = nil;
    NSArray *result = [context executeFetchRequest:request error:&error];//这里获取到的是一个数组，你需要取出你要更新的那个obj
//    for (RecordEntitySingle *info in result) {
//        info.islook = islook;
//    }
    
    //保存
    if ([context save:&error]) {
        //更新成功
        NSLog(@"更新成功");
    }
}


@end
