//
//  TCircleView+BaseConfiguration.h
//  2015-06-29-圆形进度条
//
//  Created by 冷求慧 on 7/1/15.
//  Copyright (c) 2015 gdd. All rights reserved.
//

#import "TCircleView.h"

@interface TCircleView (BaseConfiguration)

// 起始颜色
+ (UIColor *)startColor;

// 第二种颜色颜色
+ (UIColor *)centerColor;

//第三种颜色
+ (UIColor *)threeColor;

// 结束颜色
+ (UIColor *)endColor;

// 背景色
+ (UIColor *)backgroundColor;

// 线宽
+ (CGFloat)lineWidth;

// 起始角度（根据顺时针计算，逆时针则是结束角度）
+ (CGFloat)startAngle;

// 结束角度（根据顺时针计算，逆时针则是起始角度）
+ (CGFloat)endAngle;

// 进度条起始方向（YES为顺时针，NO为逆时针）
+ (TCircleViewClockWiseType)clockWiseType;

@end
