//
//  TCircleView+BaseConfiguration.m
//  2015-06-29-圆形进度条
//
//  Created by 冷求慧 on 7/1/15.
//  Copyright (c) 2015 gdd. All rights reserved.
//

#import "TCircleView+BaseConfiguration.h"
//#import <TKit.h>

#define DEGREES_TO_RADOANS(x) (M_PI * (x) / 180.0) // 将角度转为弧度

@implementation TCircleView (BaseConfiguration)

+ (UIColor *)startColor {
    
    return [UIColor colorWithHex:0x36c7bf];
}

+ (UIColor *)centerColor {
    
    return [UIColor colorWithHex:0x6dbd18];
}

+ (UIColor *)threeColor {
    return [UIColor colorWithHex:0xfde665];
}

+ (UIColor *)endColor {
    
    return [UIColor colorWithHex:0xff7f02];
}

+ (UIColor *)backgroundColor {
    
    return [UIColor grayColor];
}

+ (CGFloat)lineWidth {
    
    return 15;
}

+ (CGFloat)startAngle {
    
    return DEGREES_TO_RADOANS(-225.0);
}

+ (CGFloat)endAngle {
    
    return DEGREES_TO_RADOANS(45.0);
}

+ (TCircleViewClockWiseType)clockWiseType {
    return YES;
}

@end
