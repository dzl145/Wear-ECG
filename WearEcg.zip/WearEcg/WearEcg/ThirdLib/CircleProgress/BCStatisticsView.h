//
//  BCStatisticsView.h
//  Custom tool
//
//  Created by Billy on 16/1/21.
//  Copyright © 2016年 zzjr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BCStatisticsView : UIView

//所有颜色数组
@property (nonatomic, strong) NSArray *array_colors;

//每个颜色所占的比率数组，count数量和array_colors数量一样，如果不指定，每个颜色 会平均占比率
@property(nonatomic, strong) NSArray *array_rateOfEachColor;

//中间描述文字属性
@property(nonatomic, copy) NSString *str_title;
@property (nonatomic, strong) UIColor *color_title;
@property (nonatomic, strong) UIFont *font_title;

/**
    money description,including color && font
 */
@property(nonatomic, copy) NSString *str_amountShown;
@property (nonatomic, strong) UIColor *color_amountShown;
@property (nonatomic, strong) UIFont *font_amountShown;

// 圆形宽度 默认2.0
@property (nonatomic, assign) CGFloat lineWidth;

//是否需要动画 默认为NO
@property (nonatomic, assign) BOOL isAnimated;

//是否要有间隙 默认没有  有默认0.003
@property (nonatomic, assign) BOOL isSpace;

//初始化方法
- (instancetype) initWithFrame:(CGRect)frame detailsData:(NSArray *) colorArr;

@end
