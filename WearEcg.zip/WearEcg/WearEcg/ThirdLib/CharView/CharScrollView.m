//
//  CharScrollView.m
//  EcgWear
//
//  Created by HeartDoc on 16/8/23.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "CharScrollView.h"

@implementation CharScrollView


-(instancetype)initWithFrame:(CGRect)frame array:(NSArray *)objectArr valueStyle:(CharViewXValueStyle)valueStyle value:(CGFloat)xValueInterval {
    self = [super initWithFrame:frame];
    if (self) {
        _valueStyle = valueStyle;
        _xInterval = 0;
        _xValueInterval = 0;
        _arrayData = objectArr;
        _startDate = nil;
        _startNum = 0;
        CGRect rect = frame;
        rect.size.height = frame.size.height -20;
    }
    return self;
}

-(void)setValueForInterval:(CGFloat)xInterval value:(CGFloat)xValueInterval pxInterval:(CGFloat)pxInterval startDate:(NSDate *)date {
    _xValueInterval = xValueInterval;
    _pxInterval = pxInterval;
    _xInterval = xInterval;
    _startDate = date;
    valueNum = (self.frame.size.width - 20)/XIntervalValue;
    [self setNeedsDisplay];
}

-(void)setValueForInterval:(CGFloat)xInterval value:(CGFloat)xValueInterval pxInterval:(CGFloat)pxInterval startNum:(CGFloat)number {
    _xValueInterval = xValueInterval;
    _pxInterval = pxInterval;
    _xInterval = xInterval;
    _startNum = number;
    valueNum = (self.frame.size.width - 20)/XIntervalValue;
    [self setNeedsDisplay];
}

-(void)drawRect:(CGRect)rect{
    if (_xValueInterval == 0 || _xInterval == 0) {
        return;
    }
    
    //画线
    [self drawLine];
    
    //画坐标
    [self drawXAxis];
    
}

-(void)drawLine{
    if (self.arrayData.count <= 0) {
        return;
    }
    
    [[UIColor colorWithHex:0xE75A78] set];
    
    UIBezierPath *bezier = [[UIBezierPath alloc] init];
    [bezier setLineWidth:0.8f];
    [bezier setLineCapStyle:kCGLineCapRound];
    
    CGPoint startPoint = [self pointForLineIndex:0];
    [bezier moveToPoint:startPoint];
    
    for (NSInteger i = 1; i < self.arrayData.count; i++) {
        CGPoint endPoint = [self pointForLineIndex : i];
        [bezier addLineToPoint:endPoint];
    }
    [bezier stroke];
}

-(void)drawXAxis
{
    //X坐标
    for (int i = 0; i <= valueNum; i++) {
        [[UIColor colorWithHex:0xBBBBBB] set];
        
        UIBezierPath *bezier = [[UIBezierPath alloc] init];
        CGPoint startPoint = [self pointForXAxis:YES atIndex:i];
        [bezier moveToPoint:startPoint];
        
        CGPoint endPoint = [self pointForXAxis:NO atIndex:i];
        [bezier addLineToPoint:endPoint];
        
        [bezier setLineWidth:1.f];
        [bezier setLineCapStyle:kCGLineCapSquare];
        
        [bezier stroke];
        [self drawText:i];
    }
    //X线
    [[UIColor colorWithHex:0xBBBBBB] set];
    CGPoint point = CGPointMake(0, self.frame.size.height  - 40);
    UIBezierPath *bezier = [[UIBezierPath alloc] init];
    [bezier moveToPoint:point];
    [bezier addLineToPoint:CGPointMake(self.frame.size.width, self.frame.size.height  - 40)];
    [bezier setLineWidth:1.f];
    [bezier setLineCapStyle:kCGLineCapSquare];
    [bezier stroke];
}

-(void)drawText:(NSInteger)index{
    if (index < 0 || index >= self.arrayData.count) {
        return;
    }
    NSString * strText = nil;
    if (self.valueStyle == CharViewXValueStyle_Date && self.startDate != nil) {
        strText = [[self.startDate dateByAddingTimeInterval:index * self.xValueInterval] convertDateToStringFormat:@"HH:mm:ss"];
    }
    else if (self.valueStyle == CharViewXValueStyle_Number && self.startNum >= 0){
        strText = [NSString stringWithFormat:@"%lf",index * self.xValueInterval];
    }
    else{
        return;
    }
    NSMutableParagraphStyle * style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    float x = index * self.xInterval;
    CGRect dayStringFrame = CGRectMake(x, self.frame.size.height - 38, 40, 12);
    dayStringFrame.origin.x = x - 20;
    style.alignment = NSTextAlignmentCenter;
    
    if (index == 0){
        dayStringFrame.origin.x = 0;
        style.alignment = NSTextAlignmentLeft;
    }
    NSDictionary * dayDict = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Helvetica-Bold" size:9],NSFontAttributeName,[UIColor colorWithHex:0x999999],NSForegroundColorAttributeName, style, NSParagraphStyleAttributeName,nil];
    [strText drawInRect:dayStringFrame withAttributes:dayDict];
}

//X轴坐标转换 竖线是从上向下划 first 代表上边一个
- (CGPoint)pointForXAxis:(BOOL)first atIndex:(CGFloat)index{
    float x = _xInterval * index;
    if (x > self.frame.size.width) {
        x = self.frame.size.width;
    }
    float y = 0;
    if (first) {
        y = self.frame.size.height - 44;
    }
    else {
        y = self.frame.size.height - 40;
    }
    if (x == 0) {
        x = 1;
    }
    return CGPointMake(x, y);
}

//数据点的坐标转换
- (CGPoint)pointForLineIndex:(NSInteger)index{
    float x = self.pxInterval * index;
    //1个数值占用多少像素点
    float onePx = (float)YIntervalValue/YDataIntervalValue;
    float y = (self.frame.size.height - [self.arrayData[index] floatValue] * onePx) - 40;
    
    return CGPointMake(x, y);
}


-(void)dealloc{
    _arrayData = nil;
    _startDate = nil;
}
@end
