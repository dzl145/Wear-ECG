//
//  CharYview.h
//  EcgWear
//
//  Created by HeartDoc on 16/8/22.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CharDefine.h"

//Y轴层视图
@interface CharYview : UIView
{
    //Y轴的坐标个数
    NSInteger valueNum;
}

//Y坐标间隔宽度
@property (assign,nonatomic,readonly) CGFloat yInterval;

//Y坐标数值的间隔
@property (assign,nonatomic,readonly) CGFloat yValueInterval;

@property (nonatomic, retain)NSArray *colorArray;

//赋值 重新画图
-(void)setValueForInterval:(CGFloat)yInterval value:(CGFloat)yValueInterval colorArray:(NSArray *)array;

@end
