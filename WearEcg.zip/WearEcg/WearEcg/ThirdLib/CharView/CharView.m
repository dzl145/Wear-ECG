//
//  CharView.m
//  EcgWear
//
//  Created by 宋敬佩 on 16/7/29.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "CharView.h"

@implementation CharView

- (id)initWithFrame:(CGRect)frame objectsArray:(NSArray *)theObjectsArray startDate:(NSDate *)theStartDate showStyle:(CharViewXShowStyle)showStyle colorArray:(NSArray *)array YDataValue:(int)yDataValue XDataValue:(int)xDataValue{
    
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:[UIColor clearColor]];
        //赋值默认值
        _valueStyle = CharViewXValueStyle_Date;
        startDate = theStartDate;
        _arrayData = theObjectsArray;
        _showStyle = showStyle;
        _xInterval = XIntervalValue;
        _xValueInterval = XDataIntervalValue;
        _pxInterval = XIntervalValue;
        
        //创建底层视图
        CGRect rect = CGRectMake(0, 0, SCREEN_WIDTH, CharViewHeight - 40);
        CharYview * yview = [[CharYview alloc]initWithFrame:rect];
        [yview setValueForInterval:YIntervalValue value:yDataValue colorArray:array];
        [yview setBackgroundColor:[UIColor whiteColor]];
        [self addSubview:yview];
        
        //创建滚动层视图
        _contentView = [[CharScrollView alloc]initWithFrame:CGRectMake(0, 0, self.scrollview.frame.size.width, self.scrollview.frame.size.height) array:theObjectsArray valueStyle:CharViewXValueStyle_Date value:_xValueInterval];
        [_contentView setBackgroundColor:[UIColor clearColor]];
        if (showStyle == CharViewXShowStyle_ValueInterval) {
            CGFloat scrollWith = (theObjectsArray.count -1)* XIntervalValue + 20;
            CGRect scrollRect = CGRectMake(0, 0, scrollWith, CharViewHeight);
            _contentView.frame = scrollRect;
            [_contentView setValueForInterval:_xInterval value:_xValueInterval pxInterval:XIntervalValue startDate:theStartDate];
            self.scrollview.contentSize = CGSizeMake(scrollWith , 0);
        }
        [self.scrollview addSubview:_contentView];
        [self addSubview:self.scrollview];
        //添加滚动轴视图
        [self addGraphScrollView];
        
        //根据展示样式
        if (showStyle == CharViewXShowStyle_Auto) {
            if ((self.arrayData.count-1)*XIntervalValue < MinScrollWidth) {
                [self setScrollWidthForXshow:MinScrollWidth];
            }
            else if ((self.arrayData.count-1)*XIntervalValue > MaxScrollWidth) {
                [self setScrollWidthForXshow:MaxScrollWidth];
            }
            else {
                [self setScrollWidthForXshow:(self.arrayData.count-1)*XIntervalValue];
            }
        }
    }

    return self;
}

- (id)initWithFrame:(CGRect)frame objectsArray:(NSArray *)theObjectsArray startNumber:(CGFloat)theStartNumber showStyle : (CharViewXShowStyle)showStyle{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

- (void)addGraphScrollView{

    //加载滑动效果
    _tipView = [[UIView alloc]initWithFrame:CGRectMake(6, 0, 60, CharViewHeight)];
    [_tipView setUserInteractionEnabled:NO];
    [self addSubview:_tipView];
    
    //提示框
    UIImageView * imageFrame = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 60, 25)];
    imageFrame.image = [UIImage imageNamed:@"graphFrame"];
    [_tipView addSubview:imageFrame];
    
//    //滑动线
//    UIImageView * imageLine = [[UIImageView alloc]initWithFrame:CGRectMake(30, 25, 1 , CharViewHeight-45)];
//    imageLine.image = [UIImage imageNamed:@"graphLine"];
//    [_tipView addSubview:imageLine];
//    
//    _tipLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 60, 20)];
//    _tipLabel.textAlignment = NSTextAlignmentCenter;
//    _tipLabel.textColor = [UIColor whiteColor];
//    if (_arrayData != nil && _arrayData.count > 0) {
//        _tipLabel.text = [NSString stringWithFormat:@"%d",(int)[_arrayData[0] intValue]];
//    }
//    [imageFrame addSubview:_tipLabel];
}


//懒加载滚动层
-(UIScrollView *)scrollview{
    if (_scrollview == nil) {
        CGRect scrollRect = CGRectMake(YLabelWidth-1, 0, SCREEN_WIDTH - YLabelWidth+1, CharViewHeight);
        _scrollview = [[UIScrollView alloc]initWithFrame:scrollRect];
        _scrollview.delegate = self;
        [_scrollview setBounces:NO];
        [_scrollview setShowsHorizontalScrollIndicator:NO];
        [_scrollview setBackgroundColor:[UIColor clearColor]];
    }
    return _scrollview;
}

//滚动事件
- (void)scrollViewDidScroll:( UIScrollView *)scrollView {
    //算出滚动层宽度的倍数
    CGFloat multiple = (scrollView.contentSize.width-scrollView.frame.size.width)/(SCREEN_WIDTH-YLabelWidth-20);
    //算出偏移量走的像素
    CGFloat offest = scrollView.contentOffset.x;
    CGFloat widthPx = offest/multiple + 6;
    CGRect rect = _tipView.frame;
    rect.origin.x = widthPx;
    _tipView.frame = rect;
    //根据偏移量算出 走到的数据位置 (每偏移multiple个像素 滚动轴就会相对方向移动1px)
    CGFloat pxlength = offest + offest/multiple + 1;
    //过半就显示下一个数据点
    NSInteger pos = (NSInteger)(pxlength + _pxInterval/2)/_pxInterval;
    if (pos < _arrayData.count) {
        _tipLabel.text = [NSString stringWithFormat:@"%d",(int)[_arrayData[pos] intValue]];
    }
}

#pragma mark--- 设置滚动的宽度
- (void)setScrollWidthForXshow:(CGFloat)width {
    //固定了滚动宽度时 计算出X轴数据间隔值(展示样式是固定间隔 CharViewXShowStyle_ValueInterval 则不用计算)
    if (_showStyle != CharViewXShowStyle_ValueInterval) {
        //计算出每个点的占用多少像素
        _pxInterval = width/self.arrayData.count;
        //计算出每个坐标点之间的数据文本间隔
        _xValueInterval = XIntervalValue/_pxInterval;
        
        _xtotalWidth = width + 20;
        CGRect scrollRect = CGRectMake(0, 0, _xtotalWidth - 60, CharViewHeight);
        _contentView.frame = scrollRect;
        self.scrollview.contentSize = CGSizeMake(scrollRect.size.width , 0);
        if (_valueStyle == CharViewXValueStyle_Date) {
            [_contentView setValueForInterval:_xInterval value:_xValueInterval pxInterval:_pxInterval startDate:startDate];
        }
        else{
            [_contentView setValueForInterval:_xInterval value:_xValueInterval pxInterval:_pxInterval startNum:startNumber];
        }
    }
}

-(void)dealloc{
    startDate = nil;
    [_scrollview removeFromSuperview];
    _scrollview = nil;
    [_contentView removeFromSuperview];
    _contentView = nil;
    _tipView = nil;
    _tipLabel = nil;
}

@end
