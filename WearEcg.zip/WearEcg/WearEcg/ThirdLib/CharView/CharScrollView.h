//
//  CharScrollView.h
//  EcgWear
//
//  Created by HeartDoc on 16/8/23.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CharDefine.h"
//X轴显示视图
@interface CharScrollView : UIView
{
    //X轴的坐标个数
    NSInteger valueNum;
}

//X显示值的样式
@property (assign,nonatomic) CharViewXValueStyle valueStyle;

//数据数组
@property (strong,nonatomic) NSArray * arrayData;

//两个数据间的像素间隔
@property (assign,nonatomic) CGFloat pxInterval;

//X坐标点像素间隔宽度
@property (assign,nonatomic) CGFloat xInterval;

//X坐标点数值文本显示的间隔
@property (assign,nonatomic) CGFloat xValueInterval;

//开始日期
@property (strong,nonatomic) NSDate * startDate;

//开始数字
@property (assign,nonatomic) CGFloat startNum;

//初始化
-(instancetype)initWithFrame:(CGRect)frame array : (NSArray *)objectArr valueStyle : (CharViewXValueStyle)valueStyle value:(CGFloat)xValueInterval;

//日期格式 赋值重新画图
-(void)setValueForInterval:(CGFloat)xInterval value:(CGFloat)xValueInterval pxInterval:(CGFloat)pxInterval startDate:(NSDate *)date;
//数字格式 赋值重新画图
-(void)setValueForInterval:(CGFloat)xInterval value:(CGFloat)xValueInterval pxInterval:(CGFloat)pxInterval startNum:(CGFloat)number;
@end
