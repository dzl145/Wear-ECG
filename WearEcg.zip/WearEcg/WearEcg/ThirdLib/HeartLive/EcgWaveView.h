//
//  ResultView.h
//  WearEcg
//
//  Created by 翟英鹏 on 15/11/6.
//  Copyright (c) 2015年 医甸园. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, XTimeShaftType) {
    //第一张视图
    XTimeShaftType_First = 1,
    //最后一张
    XTimeShaftType_End,
    //其它
    XTimeShaftType_Other
};

@interface EcgWaveView : UIView

//时间坐标轴的第几张视图
@property (nonatomic, assign) XTimeShaftType xtype;

//波形视图总数
@property (nonatomic, assign) NSInteger total;

//坐标开始时间
@property (nonatomic, strong) NSDate *startDate;

//坐标结束时间
@property (nonatomic, strong) NSDate *endDate;

//数据数组
@property (nonatomic, strong) NSArray *dataSource;

//X坐标个数
@property (nonatomic, assign) NSInteger numberOfSeconds;

//时间间隔
@property (nonatomic, unsafe_unretained) float secInterval;

//开始绘画
- (void)rafireDrawingWithPoints:(NSArray *)dataArr showIndex:(NSInteger)index;

@end
