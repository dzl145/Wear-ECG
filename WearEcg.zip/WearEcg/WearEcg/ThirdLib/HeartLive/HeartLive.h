//
//  HeartLive.h
//  HeartRateCurve
//
//  Created by IOS－001 on 14-4-23.
//  Copyright (c) 2014年 N/A. All rights reserved.
//

#import <UIKit/UIKit.h>

//心率绘画的样式
typedef NS_ENUM(NSInteger, HeartDrawStyle) {
    //格子
    HeartDrawStyle_Grid = 1,
    //波形
    HeartDrawStyle_Wave,
    //两个都画
    XTimeShaftType_All
};

@interface PointContainer : NSObject
//刷新方式 点数据的索引
@property (nonatomic , readonly) NSInteger numberOfRefreshElements;
//平滑方式 点数据的索引
@property (nonatomic , readonly) NSInteger numberOfTranslationElements;
//刷新方式 点数组
@property (nonatomic , strong) NSMutableArray *refreshPointContainer;
//平滑方式 点数组
@property (nonatomic , strong) NSMutableArray *translationPointContainer;

//单例
+ (PointContainer *)sharedContainer;

//清除数据
-(void)clearData;

//刷新变换
- (void)addPointAsRefreshChangeform:(CGPoint)point;

//平移变换
- (void)addPointAsTranslationChangeform:(CGPoint)point;

@end



@interface HeartLive : UIView

@property (nonatomic, strong) NSDate *startDate;

@property (nonatomic, assign) BOOL firstDraw;

//画的样式
@property (nonatomic, assign) HeartDrawStyle drawStyle;

//重新设置显示最大的点数 multiple 显示的倍数/系数
- (void)setMaxContainerCapacity : (NSInteger)multiple andScreenWidth : (CGFloat)width;

//清空画布   isClearline: 是否清理划线
- (void)clearContext : (BOOL)isClearline;

//开始划线
- (void)fireDrawingWithPoints:(NSArray *)points pointsCount:(NSInteger)count;

@end

