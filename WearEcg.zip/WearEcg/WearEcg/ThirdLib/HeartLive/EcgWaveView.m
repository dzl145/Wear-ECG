//
//  ResultView.m
//  WearEcg
//
//  Created by 翟英鹏 on 15/11/6.
//  Copyright (c) 2015年 医甸园. All rights reserved.
//


#import "EcgWaveView.h"
#define timeinterval  125  //两个时间点之间的间距为250像素

@interface EcgWaveView ()

@property (nonatomic , assign) NSInteger currentPointsCount;

@property (nonatomic , assign) NSInteger index;

@end

@implementation EcgWaveView

- (void)setDataSource:(NSArray *)dataSource
{
    _dataSource = dataSource;
//    [self setNeedsDisplay];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.clearsContextBeforeDrawing = YES;
        self.currentPointsCount = 0;
        self.index = 0;
    }
    return self;
}

- (void)rafireDrawingWithPoints:(NSArray *)dataArr showIndex:(NSInteger)index
{
    self.index = index;
    
    self.currentPointsCount = dataArr.count;
    
    self.dataSource = dataArr;
}

- (void)drawRect:(CGRect)rect
{
    [self drawLineX];
    [self drawCurve];
}

//  竖线是从上向下划 first 代表上边一个点
- (CGPoint)pointForVerticalLine:(BOOL)first atDayNumber:(CGFloat)index{
    
    float x = timeinterval * index;
    if (x > self.frame.size.width) {
        x = self.frame.size.width;
    }
    float y = 0;
    if (first) {
        y = self.frame.size.height - 24;
    }
    else{
        y = self.frame.size.height - 20;
    }
    return CGPointMake(x, y);
}

- (void)drawCurve
{
    if (self.currentPointsCount == 0) {
        return;
    }
    
    [[UIColor blackColor] set];
    
    UIBezierPath *bezier = [[UIBezierPath alloc] init];
    [bezier setLineWidth:0.8f];
    [bezier setLineCapStyle:kCGLineCapSquare];
    
    NSValue *tmpValue = self.dataSource[0];
    CGPoint tmpPoint = [tmpValue CGPointValue];
    CGPoint startPoint = CGPointMake(tmpPoint.x - (_index * 2500), tmpPoint.y);
    [bezier moveToPoint:startPoint];
    
    for (int i = 1; i < self.currentPointsCount; i++) {
        NSValue *curvalue = self.dataSource[i];
        CGPoint curpoint = [curvalue CGPointValue];
        CGPoint endPoint = CGPointMake(curpoint.x - (_index * 2500), curpoint.y);
        [bezier addLineToPoint:endPoint];
    }
    [bezier stroke];
}

-(void)drawLineX{

    
    self.numberOfSeconds = [self getTimeInterval:self.startDate end:self.endDate]; //self.frame.size.width/timeinterval + 1;
    //X坐标
    for (int i = 0; i <= self.numberOfSeconds; i++) {
        [[UIColor redColor] set];
        
        UIBezierPath *bezier = [[UIBezierPath alloc] init];
        CGPoint startPoint = [self pointForVerticalLine:YES atDayNumber:i];
        [bezier moveToPoint:startPoint];

        CGPoint endPoint = [self pointForVerticalLine:NO atDayNumber:i];
        [bezier addLineToPoint:endPoint];
        
        [bezier setLineWidth:1.f];
        [bezier setLineCapStyle:kCGLineCapSquare];
        
        [bezier stroke];
        [self drawDateForDayNumber:i];
    }
    
    //X线
    [[UIColor redColor] set];
    CGPoint point = CGPointMake(0, self.frame.size.height  - 20);
    UIBezierPath *bezier = [[UIBezierPath alloc] init];
    [bezier moveToPoint:point];
    [bezier addLineToPoint:CGPointMake(self.frame.size.width, self.frame.size.height  - 20)];
    [bezier setLineWidth:1.f];
    [bezier setLineCapStyle:kCGLineCapSquare];
 
    [bezier stroke];
}


#pragma mark Draw
- (CGFloat)xCoordinateForDayNumber:(NSInteger)index{
    
    return timeinterval * index ;
}

- (void)drawDateForDayNumber:(NSInteger)index{
    //画出文字
    NSInteger interval = [self getTimeInterval:self.startDate end:self.endDate];
    if (index > interval) {
        return;
    }
    NSString *timeStr = [[self.startDate dateByAddingTimeInterval:index] convertDateToStringFormat:@"MM/dd HH:mm:ss"];
    
    NSMutableParagraphStyle * style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    float x = [self xCoordinateForDayNumber: index];
    CGRect dayStringFrame = CGRectMake(x, self.frame.size.height - 17, 84, 14);
    dayStringFrame.origin.x = x - 42;
    style.alignment = NSTextAlignmentCenter;
    
    if (index >= interval && self.xtype == XTimeShaftType_End){
        dayStringFrame.origin.x = x - 86;
        style.alignment = NSTextAlignmentRight;
    }
    else{
        if (index == 0 && (self.xtype == XTimeShaftType_First || (_total == 1 && self.xtype == XTimeShaftType_End))) {
            dayStringFrame.origin.x = 2;
            style.alignment = NSTextAlignmentLeft;//对齐方式
        }
    }
    NSDictionary * dayDict = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"Helvetica-Bold" size:9],NSFontAttributeName,[UIColor darkGrayColor],NSForegroundColorAttributeName, style, NSParagraphStyleAttributeName,nil];
    [timeStr drawInRect:dayStringFrame withAttributes:dayDict];
}

-(NSInteger)getTimeInterval:(NSDate *)startDate end:(NSDate *)endDate {
    NSInteger end = (long)[endDate timeIntervalSince1970];
    NSInteger start = (long)[startDate timeIntervalSince1970];
    return labs(end - start);
}

- (void)remove{

}

@end
