//
//  BaseView.m
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/25.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "BaseView.h"

@implementation BaseView

//显示提示
- (void)showTips:(NSString *)str {
    [Loading showTips:str];
}
//显示等待
- (void)showHud : (NSString *)tipStr {
    [Loading showHud : tipStr];
}

- (void)showHud : (NSString *)tipStr showtime : (CGFloat)time{
    [Loading showHud:tipStr showtime:time];
}
//隐藏等待
- (void)hideHud{
    [Loading hideHud];
}

@end
