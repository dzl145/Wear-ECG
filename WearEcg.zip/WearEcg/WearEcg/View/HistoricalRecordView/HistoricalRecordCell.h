//
//  HistoricalRecordCell.h
//  WearEcg
//
//  Created by apple on 16/12/16.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HistoricalRecordCell;
typedef void(^swipeBlock) ();
typedef void(^deleteBlock) ();
typedef void(^cancleBlock) ();

@interface HistoricalRecordCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *numberLabel;

@property (nonatomic, assign) BOOL isOpen;

//开始时间
@property (weak, nonatomic) IBOutlet UILabel *startTimeLabel;

@property (weak, nonatomic) IBOutlet UILabel *heart;
@property (weak, nonatomic) IBOutlet UILabel *breathe;

//心率
@property (weak, nonatomic) IBOutlet UILabel *heartLabel;
//呼吸率
@property (weak, nonatomic) IBOutlet UILabel *breatheLabel;
//心率是否正常
@property (weak, nonatomic) IBOutlet UILabel *heartNormalLabel;
//呼吸率是否正常
@property (weak, nonatomic) IBOutlet UILabel *breatheNormalLabel;
//是否健康图片
@property (weak, nonatomic) IBOutlet UIImageView *healthImage;
//是否健康
@property (weak, nonatomic) IBOutlet UILabel *healthLabel;


@property (weak, nonatomic) IBOutlet UIView *moveView;

@property (nonatomic, copy)swipeBlock mySwipeBlock;
@property (nonatomic, copy)deleteBlock myDeleteBlock;
-(void)closeMenu;

@end
