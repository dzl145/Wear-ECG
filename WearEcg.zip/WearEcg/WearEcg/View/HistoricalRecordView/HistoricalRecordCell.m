//
//  HistoricalRecordCell.m
//  WearEcg
//
//  Created by apple on 16/12/16.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "HistoricalRecordCell.h"

@implementation HistoricalRecordCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.moveView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 44);
    //添加左滑手势
    UISwipeGestureRecognizer *swipLeft=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swip:)];
    swipLeft.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.moveView addGestureRecognizer:swipLeft];
    //添加右滑手势
    UISwipeGestureRecognizer *swipRight=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swip:)];
    swipRight.direction=UISwipeGestureRecognizerDirectionRight;
    [self.moveView addGestureRecognizer:swipRight];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setFrame:(CGRect)frame {
    if (SCREEN_WIDTH == 414) {
        CGRect rect = self.numberLabel.frame;
        rect.origin.x = 20;
        self.numberLabel.frame = rect;
        
        float x = 20 + 60;
        CGRect start = self.startTimeLabel.frame;
        start.origin.x = x;
        self.startTimeLabel.frame = start;
        
        CGRect heart = self.heart.frame;
        heart.origin.x = x;
        self.heart.frame = heart;
        
        CGRect breathe = self.breathe.frame;
        breathe.origin.x = x;
        self.breathe.frame = breathe;
        
        float sp = SCREEN_WIDTH / 106;
        CGRect heartLab = self.heartLabel.frame;
        heartLab.origin.x = self.heart.frame.size.width + x + sp;
        self.heartLabel.frame = heartLab;
        
        CGRect breatheLab = self.breatheLabel.frame;
        breatheLab.origin.x = self.breathe.frame.size.width + x + sp;
        self.breatheLabel.frame = breatheLab;
        
        CGRect heartNor = self.heartNormalLabel.frame;
        heartNor.origin.x = self.heart.frame.size.width + x + sp * 2 + self.heartLabel.frame.size.width;
        self.heartNormalLabel.frame = heartNor;
        
        CGRect breatheNor = self.breatheNormalLabel.frame;
        breatheNor.origin.x = self.breathe.frame.size.width + x + sp * 2 + self.breatheLabel.frame.size.width;
        self.breatheNormalLabel.frame = breatheNor;
        
    }
}

- (void)swip:(UISwipeGestureRecognizer *)swipe{
    
    if (swipe.direction == UISwipeGestureRecognizerDirectionLeft) {
        // 打开
        [self openMenu];
        
        // 将其他已打开的关闭
        if( self.mySwipeBlock ){
            self.mySwipeBlock();
        }
    }else if (swipe.direction == UISwipeGestureRecognizerDirectionRight){
        // 关闭
        [self closeMenu];
    }
}

- (IBAction)deleteAction:(UIButton *)sender {
//    NSLog(@"删除");
    self.myDeleteBlock();
//    // 删除
//    if(self.myDeleteBlock) {
//        NSLog(@"删除");
//        
//    }
}

- (void)openMenu{
    if (self.isOpen) {
        return;
    }
    [UIView animateWithDuration:0.5 animations:^{
        self.moveView.center = CGPointMake(self.moveView.center.x - 50, self.moveView.center.y);
    }completion:^(BOOL finished) {
        if(finished){
            self.isOpen = YES;
        }
    }];
}

/**关闭左滑菜单*/
-(void)closeMenu
{
    if(!_isOpen)
        return;
    
    [UIView animateWithDuration:0.5 animations:^{
        self.moveView.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, self.moveView.center.y);
    }completion:^(BOOL finished) {
        if (finished) {
            self.isOpen = NO;
        }
    }];
    
}


@end
