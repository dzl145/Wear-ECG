//
//  HistoricalContinuousCell.m
//  WearEcg
//
//  Created by apple on 16/12/20.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "HistoricalContinuousCell.h"

@implementation HistoricalContinuousCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.cellView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 44);
    //添加左滑手势
    UISwipeGestureRecognizer *swipLeft=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swip:)];
    swipLeft.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.cellView addGestureRecognizer:swipLeft];
    //添加右滑手势
    UISwipeGestureRecognizer *swipRight=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swip:)];
    swipRight.direction=UISwipeGestureRecognizerDirectionRight;
    [self.cellView addGestureRecognizer:swipRight];
    
    
}

- (void)setFrame:(CGRect)frame {
    if (SCREEN_WIDTH == 414) {
        CGRect rect = self.dateLabel.frame;
        rect.origin.x = 20;
        self.dateLabel.frame = rect;
        
        float x = 20 + 60;
        CGRect start = self.startTime.frame;
        start.origin.x = x;
        self.startTime.frame = start;
        
        CGRect continu = self.continuousTime.frame;
        continu.origin.x = x;
        self.continuousTime.frame = continu;
        
        CGRect heart = self.heart.frame;
        heart.origin.x = x;
        self.heart.frame = heart;
        
        CGRect breathe = self.breathe.frame;
        breathe.origin.x = x;
        self.breathe.frame = breathe;
        
        float sp = SCREEN_WIDTH / 106;
        CGRect heartLab = self.heartLabel.frame;
        heartLab.origin.x = self.heart.frame.size.width + x + sp;
        self.heartLabel.frame = heartLab;
        
        CGRect breatheLab = self.breatheLabel.frame;
        breatheLab.origin.x = self.breathe.frame.size.width + x + sp;
        self.breatheLabel.frame = breatheLab;
        
        CGRect heartNor = self.heartNormal.frame;
        heartNor.origin.x = self.heart.frame.size.width + x + sp * 2 + self.heartLabel.frame.size.width;
        self.heartNormal.frame = heartNor;
        
        CGRect breatheNor = self.breatheNormal.frame;
        breatheNor.origin.x = self.breathe.frame.size.width + x + sp * 2 + self.breatheLabel.frame.size.width;
        self.breatheNormal.frame = breatheNor;
        
    }
    
    
    [super setFrame:frame];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)swip:(UISwipeGestureRecognizer *)swipe{
    
    if (swipe.direction == UISwipeGestureRecognizerDirectionLeft) {
        // 打开
        [self openMenu];
        
        // 将其他已打开的关闭
        if( self.mySwipeBlock ){
            self.mySwipeBlock();
        }
    }else if (swipe.direction == UISwipeGestureRecognizerDirectionRight){
        // 关闭
        [self closeMenu];
    }
}

- (IBAction)deleteAction:(UIButton *)sender {
    //    NSLog(@"删除");
    self.myDeleteBlock();
    //    // 删除
    //    if(self.myDeleteBlock) {
    //        NSLog(@"删除");
    //
    //    }
}

- (void)openMenu{
    if (self.isOpen) {
        return;
    }
    [UIView animateWithDuration:0.5 animations:^{
        self.cellView.center = CGPointMake(self.cellView.center.x - 50, self.cellView.center.y);
    }completion:^(BOOL finished) {
        if(finished){
            self.isOpen = YES;
        }
    }];
}

/**关闭左滑菜单*/
-(void)closeMenu
{
    if(!_isOpen)
        return;
    
    [UIView animateWithDuration:0.5 animations:^{
        self.cellView.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, self.cellView.center.y);
    }completion:^(BOOL finished) {
        if (finished) {
            self.isOpen = NO;
        }
    }];
    
}



@end
