//
//  AbnormalCell.m
//  WearEcg
//
//  Created by apple on 16/12/20.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "AbnormalCell.h"

@implementation AbnormalCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
