//
//  GainView.m
//  WearEcg
//
//  Created by lxl on 15/12/26.
//  Copyright © 2015年 医甸园. All rights reserved.
//

#import "GainView.h"

@implementation GainView

- (IBAction)gainClick:(id)sender {
    UIButton * btn = (UIButton *)sender;
    float rate = 1.0;
    switch (btn.tag) {
        case 201:{
            rate = 0.25;
            break;
        }
        case 202:{
            rate = 0.5;
            break;
        }
        case 203:{
            rate = 1.0;
            break;
        }
        case 204:{
            rate = 2.0;
            break;
        }
        default:
            break;
    }
    [self.delegate ECGGainViewDelegate:rate];
    [self removeFromSuperview];
}

- (IBAction)pressBtnClick:(UIButton*)sender{
    [self setOtherSelectColor : sender.tag];
}

-(void)setOtherSelectColor : (NSInteger)tag{
    for (NSInteger i = 201; i < 205; i++) {
        UIButton * btn = [self viewWithTag:i];
        if (i == tag) {
            [btn setTitleColor:[UIColor colorWithHex:0xFF9000] forState:UIControlStateNormal];
        }
        else {
            [btn setTitleColor:[UIColor colorWithHex:0x808080] forState:UIControlStateNormal];
        }
    }
}

-(void)setScaleViewPostion : (CGPoint)point{
    self.height.constant = point.y;
    self.left.constant = point.x;
}

-(void)setScaleGain : (CGFloat)scale
{
    UIButton * btn = nil;
    if (scale == 0.25) {
        btn = [self viewWithTag:201];
    }
    else if (scale == 0.5){
        btn = [self viewWithTag:202];
    }
    else if (scale == 1.0){
        btn = [self viewWithTag:203];
    }
    else if (scale == 2.0){
        btn = [self viewWithTag:204];
    }
    if (btn) {
        [btn setTitleColor:[UIColor colorWithHex:0xFF9000] forState:UIControlStateNormal];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    self.delegate = nil;
    [self removeFromSuperview];
}


@end
