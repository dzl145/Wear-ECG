//
//  AbnormalCell.h
//  WearEcg
//
//  Created by apple on 16/12/20.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AbnormalCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *numberLabel;

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;


@property (weak, nonatomic) IBOutlet UILabel *typeLabel;

@end
