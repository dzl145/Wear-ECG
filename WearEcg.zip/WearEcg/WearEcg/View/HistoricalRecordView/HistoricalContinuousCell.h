//
//  HistoricalContinuousCell.h
//  WearEcg
//
//  Created by apple on 16/12/20.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HistoricalContinuousCell;
typedef void(^swipeBlock) ();
typedef void(^deleteBlock) ();
typedef void(^cancleBlock) ();

@interface HistoricalContinuousCell : UITableViewCell

@property (nonatomic, assign) BOOL isOpen;

@property (weak, nonatomic) IBOutlet UIView *cellView;

@property (weak, nonatomic) IBOutlet UILabel *dateLabel;

@property (weak, nonatomic) IBOutlet UILabel *startTime;

@property (weak, nonatomic) IBOutlet UILabel *continuousTime;

@property (weak, nonatomic) IBOutlet UILabel *heart;

@property (weak, nonatomic) IBOutlet UILabel *breathe;


@property (weak, nonatomic) IBOutlet UILabel *heartLabel;


@property (weak, nonatomic) IBOutlet UILabel *breatheLabel;

@property (weak, nonatomic) IBOutlet UILabel *heartNormal;

@property (weak, nonatomic) IBOutlet UILabel *breatheNormal;


@property (weak, nonatomic) IBOutlet UIImageView *stateImage;

@property (weak, nonatomic) IBOutlet UILabel *stateLabel;

@property (nonatomic, copy)swipeBlock mySwipeBlock;
@property (nonatomic, copy)deleteBlock myDeleteBlock;
-(void)closeMenu;

@end
