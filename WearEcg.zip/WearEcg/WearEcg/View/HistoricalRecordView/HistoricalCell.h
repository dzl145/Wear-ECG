//
//  HistoricalCell.h
//  WearEcg
//
//  Created by apple on 16/12/16.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoricalCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *measuringLabel;


@property (weak, nonatomic) IBOutlet UIImageView *measuringImage;

@end
