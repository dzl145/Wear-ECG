//
//  GainView.h
//  WearEcg
//
//  Created by lxl on 15/12/26.
//  Copyright © 2015年 医甸园. All rights reserved.
//

#import "BaseView.h"

//放大代理
@protocol GainViewDelegate <NSObject>

- (void)ECGGainViewDelegate:(float)rate;

@end


//放大心电按钮视图
@interface GainView : BaseView

@property (nonatomic, weak) id<GainViewDelegate>delegate;

//高
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *height;

//左
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *left;

//设置放大状态
-(void)setScaleGain : (CGFloat)scale;

//设置放大状态
-(void)setScaleViewPostion : (CGPoint)point;

@end
