//
//  FxBaseCell.m
//  NewsReader
//
//  Created by hejinbo on 15/7/7.
//  Copyright (c) 2015年 MyCos. All rights reserved.
//

#import "BaseCell.h"

@implementation BaseCell

- (void)awakeFromNib {
    [super awakeFromNib];
}


- (void)dealloc
{
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
}


-(void)setDataForCell : (BaseModel *)model{
    if (model == nil) {
        return;
    }
}

-(void)setDataForCell : (BaseModel *)model index : (NSIndexPath *)indexpath{
    if (model == nil || indexpath == nil) {
        return;
    }
}

@end
