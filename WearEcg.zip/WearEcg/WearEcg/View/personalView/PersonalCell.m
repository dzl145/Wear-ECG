//
//  PersonalCell.m
//  WearEcg
//
//  Created by dzl on 17/2/28.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "PersonalCell.h"

@implementation PersonalCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.orderLabel.textColor = OBTION_COLOR(153, 153, 153);

    self.personalLabel.textColor = OBTION_COLOR(51, 51, 51);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
