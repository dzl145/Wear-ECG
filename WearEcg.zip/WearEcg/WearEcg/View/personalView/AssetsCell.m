//
//  AssetsCell.m
//  WearEcg
//
//  Created by dzl on 17/3/1.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "AssetsCell.h"

@implementation AssetsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
