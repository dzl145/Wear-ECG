//
//  PersonalCell.h
//  WearEcg
//
//  Created by dzl on 17/2/28.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UIImageView *toolImg;

@property (weak, nonatomic) IBOutlet UILabel *personalLabel;

@property (weak, nonatomic) IBOutlet UILabel *orderLabel;

@property (weak, nonatomic) IBOutlet UIView *segView;


@end
