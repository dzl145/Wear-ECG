//
//  AssetsCell.h
//  WearEcg
//
//  Created by dzl on 17/3/1.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssetsCell : UITableViewCell

@end
