//
//  SearchCell.h
//  WearEcg
//
//  Created by apple on 16/12/13.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *label;

@property (weak, nonatomic) IBOutlet UILabel *equipmentLabel;


@end
