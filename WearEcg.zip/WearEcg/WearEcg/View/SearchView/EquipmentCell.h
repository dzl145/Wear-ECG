//
//  EquipmentCell.h
//  WearEcg
//
//  Created by apple on 16/12/21.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EquipmentCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *equipmentLabel;


@property (weak, nonatomic) IBOutlet UIImageView *bluetoothImage;


@end
