//
//  AlarmTimeCell.m
//  WearEcg
//
//  Created by dzl on 17/2/20.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "AlarmTimeCell.h"

@implementation AlarmTimeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end
