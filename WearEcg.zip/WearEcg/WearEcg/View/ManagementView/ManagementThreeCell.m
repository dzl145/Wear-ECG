//
//  ManagementThreeCell.m
//  WearEcg
//
//  Created by dzl on 17/2/14.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "ManagementThreeCell.h"

@implementation ManagementThreeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
