//
//  ManagementCell.m
//  WearEcg
//
//  Created by apple on 16/12/13.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ManagementCell.h"

@implementation ManagementCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
