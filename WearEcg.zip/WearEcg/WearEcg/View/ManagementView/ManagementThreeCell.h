//
//  ManagementThreeCell.h
//  WearEcg
//
//  Created by dzl on 17/2/14.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManagementThreeCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UILabel *valueLabel;

@end
