//
//  BaseView.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/25.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Loading.h"

@interface BaseView : UIView

//提示样式
- (void)showTips:(NSString *)str;

//显示等待
- (void)showHud : (NSString *)tipStr;

//显示等待 等待time后自动消失
- (void)showHud : (NSString *)tipStr showtime : (CGFloat)time;

//隐藏等待
- (void)hideHud;

@end
