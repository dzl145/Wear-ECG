//
//  StorageView.m
//  WearEcg
//
//  Created by apple on 16/12/14.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "StorageView.h"

@implementation StorageView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = OBTION_COLOR(239, 239, 244);
    }
    return self;
}



- (void)drawRect:(CGRect)rect {
    
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask , YES)objectAtIndex:0];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSDictionary *fileSysAttributes = [fileManager attributesOfFileSystemForPath:path error:nil];
    NSNumber *freeSpace = [fileSysAttributes objectForKey:NSFileSystemFreeSize];
    NSNumber *totalSpace = [fileSysAttributes objectForKey:NSFileSystemSize];
    
    NSString *total = [NSString stringWithFormat:@"总空间为:%0.1fG",([totalSpace doubleValue])/1024.0/1024.0/1024.0];
    NSString *free = [NSString stringWithFormat:@"剩余:%0.1fG",([freeSpace doubleValue])/1024.0/1024.0/1024.0];
    NSString *use = [NSString stringWithFormat:@"已用:%0.1fG",([totalSpace doubleValue]-[freeSpace doubleValue])/1024.0/1024.0/1024.0];
    NSLog(@"total : %@, free : %@, use : %@",total,free,use);
    NSString *str = @"108926868687";
    NSInteger integer = ([str doubleValue] / [freeSpace doubleValue]) *100;
    NSString *freeStr = [NSString stringWithFormat:@"%ld",(long)integer];
    
    UILabel *label = [[UILabel alloc]init];
    label.bounds = CGRectMake(0, 0, 100, 30);
    label.center = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2);
    label.text = @"25%";
    label.textColor = OBTION_COLOR(51, 51, 51);
    label.textAlignment = NSTextAlignmentCenter;
    [self addSubview:label];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextSetRGBStrokeColor(context,1,1,1,1.0);//画笔线的颜色
//    CGContextSetLineWidth(context, 1.0);//线的宽度
//    //void CGContextAddArc(CGContextRef c,CGFloat x, CGFloat y,CGFloat radius,CGFloat startAngle,CGFloat endAngle, int clockwise)1弧度＝180°/π （≈57.3°） 度＝弧度×180°/π 360°＝360×π/180 ＝2π 弧度
//    // x,y为圆点坐标，radius半径，startAngle为开始的弧度，endAngle为 结束的弧度，clockwise 0为顺时针，1为逆时针。
//    CGContextAddArc(context, self.frame.size.width/2, self.frame.size.height/2, 100, 0, 2*M_PI, 0); //添加一个圆
//    CGContextDrawPath(context, kCGPathStroke); //绘制路径
    CGContextSetRGBStrokeColor(context,1,1,1,1.0);//画笔线的颜色
    UIColor*aColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:1];
    CGContextSetFillColorWithColor(context, aColor.CGColor);//填充颜色
    CGContextSetLineWidth(context, 1.0);//线的宽度
    CGContextAddArc(context, self.frame.size.width/2, self.frame.size.height/2, 100, 0, 2*M_PI, 0); //添加一个圆
    //kCGPathFill填充非零绕数规则,kCGPathEOFill表示用奇偶规则,kCGPathStroke路径,kCGPathFillStroke路径填充,kCGPathEOFillStroke表示描线，不是填充
    CGContextDrawPath(context, kCGPathFillStroke); //绘制路径加填充
    
    
    aColor = [UIColor colorWithRed:108/255.0 green:197/255.0 blue:199/255.0 alpha:1];
    CGContextSetFillColorWithColor(context, aColor.CGColor);//填充颜色
    //以10为半径围绕圆心画指定角度扇形
    CGContextMoveToPoint(context, self.frame.size.width/2, self.frame.size.height/2);
    CGContextAddArc(context, self.frame.size.width/2, self.frame.size.height/2, 100,  0 * M_PI / 180, 90 * M_PI / 180, 0);
    CGContextClosePath(context);
    CGContextDrawPath(context, kCGPathFillStroke); //绘制路径
}

@end
