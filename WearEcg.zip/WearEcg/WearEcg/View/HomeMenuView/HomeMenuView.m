//
//  HomeMenuView.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/30.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "HomeMenuView.h"

@implementation HomeMenuView

-(NSMutableArray *)menuArr{
    if (_menuArr == nil) {
        self.menuArr = [NSMutableArray arrayWithArray: [UserSetting getHomeMenuList]];
    }
    return _menuArr;
}


-(instancetype)init{
    self = [super init];
    if (self) {
        CGFloat menuW = (SCREEN_WIDTH-3)/4;
        CGFloat framW = menuW * self.menuArr.count + (self.menuArr.count - 1);
        self.backgroundColor = [UIColor whiteColor];
        self.frame = CGRectMake(0, 0, framW, 44);
        [self createMenu];
        
    }
    return self;
}

-(void)createMenu {
    CGFloat menuW = (SCREEN_WIDTH-3)/4;
    for (NSInteger i = 0; i < self.menuArr.count; i++) {
        UIButton * btn = [[UIButton alloc]init];
        NSDictionary * dic = self.menuArr[i];
        if (!dic) {
            continue;
        }
        [btn setImage:[UIImage imageNamed:[dic objectForKey:@"logoDefult"]] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:[dic objectForKey:@"logoSelect"]] forState:UIControlStateSelected];
        [btn setTitle:[dic objectForKey:@"title"] forState:UIControlStateNormal];
        btn.tag = i + 100;
        btn.titleLabel.font = [UIFont systemFontOfSize:15];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithHex:appThemeColor] forState:UIControlStateSelected];
        btn.frame = CGRectMake(menuW * i + i, 0, menuW, 44);
        [btn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        btn.userInteractionEnabled = YES;
        [self addSubview:btn];
        if (i == 0) {
            [btn setSelected:YES];
            continue;
        }
        UIView * lineView = [[UIView alloc]initWithFrame:CGRectMake(menuW * i + (i-1), 11, 1, 22)];
        [lineView setBackgroundColor:[UIColor colorWithHex:appThemeColor]];
        [self addSubview:lineView];
    }
}

-(void)buttonAction:(UIButton *)btn {
    [btn setSelected:YES];
    NSLog(@"%ld",(long)btn.tag);
    if ([self.delegate respondsToSelector:@selector(btnTag:)]) {
        [self.delegate btnTag:btn.tag];
    }
    NSArray * childs = [self subviews];
    for (UIView * view in childs) {
        if ([view isMemberOfClass:[UIButton class]]) {
            UIButton * botton = (UIButton *)view;
            if (![btn isEqual:botton]) {
                [botton setSelected:NO];
            }
        }
    }
}

- (void)dealloc
{
    [_menuArr removeAllObjects];
    _menuArr = nil;
}

@end
