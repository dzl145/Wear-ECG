//
//  stopMeasureView.m
//  WearEcg
//
//  Created by apple on 16/12/29.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "stopMeasureView.h"

@implementation stopMeasureView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        UIView *blackView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        blackView.backgroundColor = [UIColor blackColor];
        blackView.alpha = 0.3;
        [self addSubview:blackView];
        
        
    }
    return self;
}

- (void)initWithTitle:(NSString *)title determineButtonTitle:(NSString *)sureTitle cancleButtonTitle:(NSString *)cancleTitle {
    
    UIView *backView = [[UIView alloc]init];
    backView.bounds = CGRectMake(0, 0, 251, 130);
    backView.center = CGPointMake(self.frame.size.width / 2, 300);
//    backView.alpha = 0.9;
    backView.backgroundColor = [UIColor whiteColor];
    backView.layer.cornerRadius = 15;
    backView.layer.masksToBounds = YES;
    [self addSubview:backView];
    
    
    UIView *lineView1 = [[UIView alloc]initWithFrame:CGRectMake(0, 79, backView.frame.size.width, 1)];
    lineView1.backgroundColor = [UIColor lightGrayColor];
    [backView addSubview:lineView1];
    
    UIView *lineView2 = [[UIView alloc]initWithFrame:CGRectMake(125, 80, 1, 50)];
    lineView2.backgroundColor = [UIColor lightGrayColor];
    [backView addSubview:lineView2];
    
    UIButton *determine = [[UIButton alloc]initWithFrame:CGRectMake(0, 80, 125, 50)];
    [determine setTitle:sureTitle forState:UIControlStateNormal];
    [determine setTitleColor:OBTION_COLOR(0, 0, 0) forState:UIControlStateNormal];
    [determine addTarget:self action:@selector(stopMeasure) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:determine];
    
    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(126, 80, 125, 50)];
    [cancel setTitle:cancleTitle forState:UIControlStateNormal];
    [cancel setTitleColor:OBTION_COLOR(0, 0, 0) forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(cancelClick) forControlEvents:UIControlEventTouchUpInside];
    [backView addSubview:cancel];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, backView.frame.size.width, 79)];
    label.text = title;
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.textColor = OBTION_COLOR(0, 0, 0);
    [backView addSubview:label];
    
}

- (void)stopMeasure {
    if ([self.delegate respondsToSelector:@selector(stopMeasure)]) {
        [self.delegate stopMeasure];
    }
    [self removeFromSuperview];
}

- (void)cancelClick {
    [self removeFromSuperview];
}

@end
