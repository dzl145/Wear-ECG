//
//  MeasureView.m
//  WearEcg
//
//  Created by lxl on 15/12/16.
//  Copyright © 2015年 lxl. All rights reserved.
//

#import "MeasureView.h"

@implementation MeasureView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        UIView *blackView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        blackView.backgroundColor = [UIColor blackColor];
        blackView.alpha = 0.3;
        [self addSubview:blackView];
        
        UIView *backView = [[UIView alloc]init];
        backView.bounds = CGRectMake(0, 0, 251, 130);
        backView.center = CGPointMake(blackView.frame.size.width / 2, 300);
        backView.alpha = 0.9;
        backView.backgroundColor = [UIColor whiteColor];
        backView.layer.cornerRadius = 15;
        backView.layer.masksToBounds = YES;
        [self addSubview:backView];
        
        UIView *lineView1 = [[UIView alloc]initWithFrame:CGRectMake(0, 80, backView.frame.size.width, 1)];
        lineView1.backgroundColor = [UIColor lightGrayColor];
        [backView addSubview:lineView1];
        
        UIView *lineView2 = [[UIView alloc]initWithFrame:CGRectMake(125, 0, 1, 80)];
        lineView2.backgroundColor = [UIColor lightGrayColor];
        [backView addSubview:lineView2];
        
        UIButton *single = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 125, 80)];
        [single setTitle:@"单次测量" forState:UIControlStateNormal];
        [single setTitleColor:OBTION_COLOR(0, 0, 0) forState:UIControlStateNormal];
        [single addTarget:self action:@selector(singleMeasure) forControlEvents:UIControlEventTouchUpInside];
        [backView addSubview:single];
        
        UIButton *continueBtn = [[UIButton alloc]initWithFrame:CGRectMake(126, 0, 125, 80)];
        [continueBtn setTitle:@"连续测量" forState:UIControlStateNormal];
        [continueBtn setTitleColor:OBTION_COLOR(0, 0, 0) forState:UIControlStateNormal];
        [continueBtn addTarget:self action:@selector(continueMeasure) forControlEvents:UIControlEventTouchUpInside];
        [backView addSubview:continueBtn];
        
        UIButton *cancleBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 81, backView.frame.size.width, backView.frame.size.height - 81)];
        [cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
        [cancleBtn setTitleColor:OBTION_COLOR(0, 0, 0) forState:UIControlStateNormal];
        [cancleBtn addTarget:self action:@selector(cancleSelect) forControlEvents:UIControlEventTouchUpInside];
        [backView addSubview:cancleBtn];
    }
    return self;
}

//单次
- (void)singleMeasure {
    if ([self.delegate respondsToSelector:@selector(ECGMeasureDelegate:)]) {
        [self.delegate ECGMeasureDelegate:YES];
    }
    [self removeFromSuperview];
}

//连续
- (void)continueMeasure {
    if ([self.delegate respondsToSelector:@selector(ECGMeasureDelegate:)]) {
        [self.delegate ECGMeasureDelegate:NO];
    }
    [self removeFromSuperview];
}

//取消
- (void)cancleSelect {
    [self removeFromSuperview];
}




@end
