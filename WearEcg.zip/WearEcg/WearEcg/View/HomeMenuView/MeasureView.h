//
//  MeasureView.h
//  WearEcg
//
//  Created by lxl on 15/12/16.
//  Copyright © 2015年 lxl. All rights reserved.
//

#import "BaseView.h"

@protocol MeasureDelegate <NSObject>

- (void)ECGMeasureDelegate:(BOOL)is60s;

@end

@interface MeasureView : BaseView

@property (nonatomic, assign)BOOL isSingle;

@property (weak, nonatomic) id<MeasureDelegate>delegate;

@end
