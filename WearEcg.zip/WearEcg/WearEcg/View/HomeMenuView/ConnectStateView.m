//
//  ConnectStateView.m
//  WearEcg
//
//  Created by apple on 16/12/29.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ConnectStateView.h"

@implementation ConnectStateView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        UIView *blackView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        blackView.backgroundColor = [UIColor blackColor];
        blackView.alpha = 0.3;
        [self addSubview:blackView];
        
        
    }
    return self;
}

- (void)initWithTitle:(NSString *)title {
    _title = title;
    UIView *backView = [[UIView alloc]init];
    backView.bounds = CGRectMake(0, 0, 251, 100);
    backView.center = CGPointMake(self.frame.size.width / 2, 300);
    backView.alpha = 0.9;
    backView.backgroundColor = [UIColor whiteColor];
    backView.layer.cornerRadius = 15;
    backView.layer.masksToBounds = YES;
    [self addSubview:backView];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, backView.frame.size.width, backView.frame.size.height)];
    label.text = _title;
    label.textAlignment = NSTextAlignmentCenter;
    [backView addSubview:label];
}



@end
