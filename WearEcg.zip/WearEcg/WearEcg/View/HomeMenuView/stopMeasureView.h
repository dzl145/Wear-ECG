//
//  stopMeasureView.h
//  WearEcg
//
//  Created by apple on 16/12/29.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "BaseView.h"

@protocol stopMeasureViewDelegate <NSObject>

- (void)stopMeasure;

@end

@interface stopMeasureView : BaseView

@property (weak, nonatomic) id<stopMeasureViewDelegate> delegate;


- (void)initWithTitle:(NSString *)title determineButtonTitle:(NSString *)sureTitle cancleButtonTitle:(NSString *)cancleTitle;

@end
