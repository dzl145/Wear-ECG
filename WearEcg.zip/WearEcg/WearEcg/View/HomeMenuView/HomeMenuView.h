//
//  HomeMenuView.h
//  WearEcg
//
//  Created by HeartDoc on 16/9/30.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "BaseView.h"

@protocol HomeMenuViewDelegate <NSObject>

- (void)btnTag:(NSInteger)btnTag;

@end

@interface HomeMenuView : BaseView

@property (nonatomic, retain)id<HomeMenuViewDelegate> delegate;
//menu数据
@property (strong,nonatomic)NSMutableArray * menuArr;

-(void)createMenu;

@property (nonatomic, assign)NSInteger btnTag;

@end


