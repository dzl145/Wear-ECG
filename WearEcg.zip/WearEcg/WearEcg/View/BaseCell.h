//
//  FxBaseCell.h
//  NewsReader
//
//  Created by hejinbo on 15/7/7.
//  Copyright (c) 2015年 MyCos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseModel.h"


@interface BaseCell : UITableViewCell
//加载时
- (void)awakeFromNib;

//销毁时
- (void)dealloc;

//选择时
- (void)setSelected:(BOOL)selected animated:(BOOL)animated;

//赋值
-(void)setDataForCell : (BaseModel *)model;
-(void)setDataForCell : (BaseModel *)model index : (NSIndexPath *)indexpath;

@end
