//
//  TabarViewController.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/27.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "TabarViewController.h"
#import "NavigationControllerBase.h"
#import "ViewControllerBase.h"
#import "TabarModel.h"

@implementation TabarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBar.alpha = 0.9;
    [self setViewControllers:[self controllersWithModel]];
    [[UITabBar appearance] setShadowImage:[[UIImage alloc]init]];
    [[UITabBar appearance] setBackgroundImage:[[UIImage alloc]init]];
    [self.tabBar insertSubview:[self drawTabbarBgImageView] atIndex:0];
    self.selectedIndex = 2;
}


- (NSArray *)controllersWithModel
{
    NSMutableArray * tabarArr = [[NSMutableArray alloc] init];
    NSArray * modelArr = [TabarModel tabarModelWithArray];
    for (TabarModel *model in modelArr) {
        if (!model.isLoad || !model.controller || [model.controller isEqual:@""]) {
            continue;
        }
       
        Class myClass = NSClassFromString(model.controller);
        if (!myClass) {
            continue;
        }
        ViewControllerBase *controller = [[myClass alloc] init];
        controller.navigationItem.title = model.navigationtitle;
        
        if (model.image_defult && ![model.image_defult isEqual:@""]) {
            controller.tabBarItem.image = [[UIImage imageNamed:model.image_defult] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        if (model.image_select && ![model.image_select isEqual:@""]){
            controller.tabBarItem.selectedImage = [[UIImage imageNamed:model.image_select] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        }
        controller.view.backgroundColor = [UIColor whiteColor];
        self.view.backgroundColor = [UIColor colorWithHex:appThemeColor];
        if ([model.title isEqualToString:@""]) {
            controller.tabBarItem.title = @"";
            controller.tabBarItem.imageInsets = UIEdgeInsetsMake(-5, 0, 5, 0);
        }
        else{
            controller.tabBarItem.title = model.title;
        }
        //字体颜色
        NSDictionary * attributes = @{NSForegroundColorAttributeName:[UIColor colorWithHex:appThemeColor]};
        [controller.tabBarItem setTitleTextAttributes:attributes forState:UIControlStateSelected];
        NavigationControllerBase * navigation = [[NavigationControllerBase alloc] initWithRootViewController:controller];
        navigation.navigationBar.barTintColor = [UIColor colorWithHex:appThemeColor];
        [tabarArr addObject:navigation];
    }
    return tabarArr;
}

//画圆弧
- (UIImageView *)drawTabbarBgImageView
{
    CGFloat tabBarHeight = 49;   //设备tabBar高度 一般49
    CGFloat standOutHeight = 15; //突出高度 12
    CGFloat radius = 28;         // 圆半径
    CGFloat allFloat= (pow(radius, 2)-pow((radius-standOutHeight), 2));//
    CGFloat ww = sqrtf(allFloat);
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, -standOutHeight, SCREEN_WIDTH, tabBarHeight +standOutHeight)];
    //imageView.backgroundColor = [UIColor yellowColor];
    CGSize size = imageView.frame.size;
    CAShapeLayer *layer = [CAShapeLayer layer];
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(size.width/2 - ww, standOutHeight)];
    CGFloat angleH = 0.5*((radius-standOutHeight)/radius);
    CGFloat startAngle = (1+angleH)*((float)M_PI); // 开始弧度
    CGFloat endAngle = (2-angleH)*((float)M_PI);   //结束弧度
    // 开始画弧：CGPointMake：弧的圆心  radius：弧半径 startAngle：开始弧度 endAngle：介绍弧度 clockwise：YES为顺时针，No为逆时针
    [path addArcWithCenter:CGPointMake((size.width)/2, radius) radius:radius startAngle:startAngle endAngle:endAngle clockwise:YES];
    // 开始画弧以外的部分
    [path addLineToPoint:CGPointMake(size.width/2+ww, standOutHeight)];
    [path addLineToPoint:CGPointMake(size.width, standOutHeight)];
    [path addLineToPoint:CGPointMake(size.width,size.height)];
    [path addLineToPoint:CGPointMake(0,size.height)];
    [path addLineToPoint:CGPointMake(0,standOutHeight)];
    [path addLineToPoint:CGPointMake(size.width/2-ww, standOutHeight)];
    layer.path = path.CGPath;
    layer.fillColor = [UIColor whiteColor].CGColor;// 整个背景的颜色
    layer.strokeColor = [UIColor colorWithWhite:0.765 alpha:1.000].CGColor;//边框线条的颜色
    layer.lineWidth = 0.5;//边框线条的宽
    // 在要画背景的view上 addSublayer:
    [imageView.layer addSublayer:layer];
    return imageView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
