//
//  TabarViewController.h
//  WearEcg
//
//  Created by HeartDoc on 16/9/27.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabarViewController : UITabBarController


@end
