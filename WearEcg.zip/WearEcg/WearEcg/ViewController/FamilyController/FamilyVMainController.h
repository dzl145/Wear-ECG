//
//  FamilyVMainController.h
//  WearEcg
//
//  Created by HeartDoc on 16/9/28.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ViewControllerBase.h"

@interface FamilyVMainController : ViewControllerBase

@end
