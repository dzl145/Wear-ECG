//
//  MyDeviceController.m
//  WearEcg
//
//  Created by dzl on 17/3/1.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "MyDeviceController.h"
#import "ManagementTwoCell.h"
#import "SearchViewController.h"

@interface MyDeviceController ()<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *deviceTable;
}
@end

@implementation MyDeviceController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = OBTION_COLOR(239, 239, 244);
    
    [self loadingNavigationView];
    
    [self creatTableViewAndRegister];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    self.tabBarController.tabBar.hidden = YES;
}

- (void)loadingNavigationView {
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"我的设备";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
}

- (void)creatTableViewAndRegister {
    deviceTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    deviceTable.delegate = self;
    deviceTable.dataSource = self;
    [self.view addSubview:deviceTable];
    
    [deviceTable registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementTwoCell class]) bundle:nil] forCellReuseIdentifier:@"manage2"];
}

- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 11;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 2;
    }
    else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ManagementTwoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"manage2"];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.label.text = @"我的设备";
        }
        else {
            cell.label.text = @"设备连接记录";
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [deviceTable deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            SearchViewController *searchVC = [[SearchViewController alloc]init];
            [self.navigationController pushViewController:searchVC animated:YES];
        }
    }
}

@end
