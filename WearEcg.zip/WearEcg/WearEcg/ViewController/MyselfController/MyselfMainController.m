//
//  MyselfMainController.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/28.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "MyselfMainController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import "UIButton+ImageTitleSpacing.h"
#import "PersonalCell.h"
#import "MyDeviceController.h"

@interface MyselfMainController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UIImageView *_personalImage;
    UIView *_familyView;
    UIView *_toolView;
    UITableView *setTableView;
}
@end

@implementation MyselfMainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self creatScrollViewAndView];
    
    //切圆角
    [self cutTheRounded];
    
    _personalImage.userInteractionEnabled = YES;
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(alterHeadPortrait:)];
    [_personalImage addGestureRecognizer:singleTap];
    
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    self.tabBarController.tabBar.hidden = NO;
    
    self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 220 + 66 + 264 + 180 + 44);
}

//创建视图
- (void)creatScrollViewAndView {
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, -20, SCREEN_WIDTH, 220)];
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 220)];
    image.image = [UIImage imageNamed:@"123455"];
    [view addSubview:image];
    UIView *yinView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 220)];
    yinView.backgroundColor = [UIColor blackColor];
    yinView.alpha = 0.56;
    [view addSubview:yinView];
    [self.mainScrollView addSubview:view];
    
    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, -20, SCREEN_WIDTH, self.mainScrollView.frame.size.height)];
    _personalImage = [[UIImageView alloc]initWithFrame:CGRectMake(18, 56, 61, 61)];
//    _personalImage.image = [UIImage imageNamed:@"CurrentPicture"];
    _personalImage.image = [UIImage imageNamed:@"987655"];
    _personalImage.layer.cornerRadius = _personalImage.frame.size.width / 2;
    _personalImage.layer.masksToBounds = YES;
    [view2 addSubview:_personalImage];
    
    UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(87, 68, 80, 20)];
    nameLabel.text = @"爱丽丝儿";
    nameLabel.font = [UIFont systemFontOfSize:15];
    nameLabel.textColor = OBTION_COLOR(255, 255, 255);
    [view2 addSubview:nameLabel];
    
    UILabel *idLabel = [[UILabel alloc]initWithFrame:CGRectMake(87, 90, 80, 20)];
    idLabel.text = @"ID:666666";
    idLabel.font = [UIFont systemFontOfSize:14];
    idLabel.textColor = OBTION_COLOR(210, 210, 210);
    [view2 addSubview:idLabel];
    
    UIImageView *genderImage = [[UIImageView alloc]initWithFrame:CGRectMake(167, 68, 22, 22)];
    genderImage.image = [UIImage imageNamed:@"Female"];
    [view2 addSubview:genderImage];
    
    UIButton *personalSetting = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 15 - 22, 32, 22, 22)];
    [personalSetting setImage:[UIImage imageNamed:@"message"] forState:UIControlStateNormal];
    [personalSetting addTarget:self action:@selector(personalSettingView) forControlEvents:UIControlEventTouchUpInside];
    [view2 addSubview:personalSetting];
    
    _familyView = [[UIView alloc]initWithFrame:CGRectMake(15, 154, SCREEN_WIDTH - 30, 66)];
    _familyView.backgroundColor = [UIColor blackColor];
    _familyView.alpha = 0.3;
    //添加边框
    CALayer *layer1 = [_toolView layer];
    [layer1 setMasksToBounds:YES];//设置边框可见
    layer1.borderColor = [OBTION_COLOR(96, 96, 86) CGColor];
    [layer1 setBorderWidth:1];
    layer1.shadowOffset = CGSizeMake(0, 3);
    layer1.shadowRadius = 5.0;
    layer1.shadowColor = OBTION_COLOR(231, 235, 235).CGColor;
    layer1.shadowOpacity = 0.8;
    //添加四个边阴影
//    _familyView.layer.shadowColor = [UIColor blackColor].CGColor;
//    _familyView.layer.shadowOffset = CGSizeMake(10, 0);
//    _familyView.layer.shadowOpacity = 0.5;
//    _familyView.layer.shadowRadius = 1.0;
//    //添加两个边阴影
//    _familyView.layer.shadowColor = [UIColor blackColor].CGColor;
//    _familyView.layer.shadowOffset = CGSizeMake(4, 4);
//    _familyView.layer.shadowOpacity = 0.5;
//    _familyView.layer.shadowRadius = 2.0;
    [view2 addSubview:_familyView];
    
    //画虚线
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(15, 220, SCREEN_WIDTH - 30, 1)];
    [self drawDashLine:lineView lineLength:10 lineSpacing:1 lineColor:[UIColor colorWithHex:0x999999]];
    [view2 addSubview:lineView];
    
    _toolView = [[UIView alloc]initWithFrame:CGRectMake(15, 221, SCREEN_WIDTH - 30, 66)];
    
    //添加边框
    CALayer *layer = [_toolView layer];
    [layer setMasksToBounds:YES];//设置边框可见
    layer.borderColor = [OBTION_COLOR(231, 235, 235) CGColor];
    [layer setBorderWidth:1];
    layer.shadowOffset = CGSizeMake(0, 3);
    layer.shadowRadius = 5.0;
    layer.shadowColor = OBTION_COLOR(231, 235, 235).CGColor;
    layer.shadowOpacity = 0.8;
    //添加四个边阴影
//    _toolView.layer.borderWidth = 1;
//    _toolView.layer.borderColor = [UIColor lightGrayColor].CGColor;
//    _toolView.layer.shadowColor = [UIColor whiteColor].CGColor;
//    _toolView.layer.shadowOffset = CGSizeMake(10, 0);
//    _toolView.layer.shadowOpacity = 0.5;
//    _toolView.layer.shadowRadius = 1.0;
//    //添加两个边阴影
//    _toolView.layer.shadowColor = [UIColor blackColor].CGColor;
//    _toolView.layer.shadowOffset = CGSizeMake(4, 4);
//    _toolView.layer.shadowOpacity = 0.5;
//    _toolView.layer.shadowRadius = 2.0;
    
    //创建付款
    int space = (SCREEN_WIDTH - 30 - 4) / 5;
    NSArray *imgArr = [NSArray arrayWithObjects:@"Payment",@"Delivery",@"Goods",@"Comments",@"AfterSale", nil];
    NSArray *nameArr = [NSArray arrayWithObjects:@"待付款",@"待发货",@"待收货",@"待评价",@"退换/售后", nil];
    for (int i = 0; i < 5; i++) {
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(0 + i * space, 11, space, 44)];
        [button setImage:[UIImage imageNamed:[imgArr objectAtIndex:i]] forState:UIControlStateNormal];
        [button setTitle:[nameArr objectAtIndex:i] forState:UIControlStateNormal];
        [button setTitleColor:OBTION_COLOR(102, 102, 102) forState:UIControlStateNormal];
        button.tag = 20 + i;
        button.titleLabel.font = [UIFont systemFontOfSize:11];
        [button layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleTop
                                        imageTitleSpace:5];
        [button addTarget:self action:@selector(toolButton:) forControlEvents:UIControlEventTouchUpInside];
        [_toolView addSubview:button];
        
        if (i < 4) {
            UIView *everyView = [[UIView alloc]initWithFrame:CGRectMake(space + i * space, 16, 1, 34)];
            everyView.backgroundColor = [UIColor colorWithHex:0x999999];
            [_toolView addSubview:everyView];
        }
    }
    
    [view2 addSubview:_toolView];
    
    //创建表
    setTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 287, SCREEN_WIDTH, 264 + 180 + 44)];
    setTableView.delegate = self;
    setTableView.dataSource = self;
    setTableView.scrollEnabled = NO;
//    setTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [view2 addSubview:setTableView];
    
    [setTableView registerNib:[UINib nibWithNibName:NSStringFromClass([PersonalCell class]) bundle:nil] forCellReuseIdentifier:@"personal"];
    
    [self.mainScrollView addSubview:view2];
}

- (void)toolButton:(UIButton *)sender {
    
}

- (void)cutTheRounded {
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, SCREEN_WIDTH - 30, 66) byRoundingCorners: (UIRectCornerTopLeft | UIRectCornerTopRight) cornerRadii:CGSizeMake(10, 10)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = CGRectMake(0, 0, SCREEN_WIDTH - 30, 66);
    maskLayer.path = maskPath.CGPath;
    _familyView.layer.mask = maskLayer;
    
    UIBezierPath *maskPath1 = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, SCREEN_WIDTH - 30, 66) byRoundingCorners: (UIRectCornerBottomLeft | UIRectCornerBottomRight) cornerRadii:CGSizeMake(10, 10)];
    CAShapeLayer *maskLayer1 = [[CAShapeLayer alloc] init];
    maskLayer1.frame = CGRectMake(0, 0, SCREEN_WIDTH - 30, 66);
    maskLayer1.path = maskPath1.CGPath;
    _toolView.layer.mask = maskLayer1;
}

-(void)alterHeadPortrait:(UITapGestureRecognizer *)gesture {
    /**
     *  弹出提示框
     */
    //初始化提示框
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    //按钮：从相册选择，类型：UIAlertActionStyleDefault
    [alert addAction:[UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //初始化UIImagePickerController
        UIImagePickerController *PickerImage = [[UIImagePickerController alloc]init];
        //获取方式1：通过相册（呈现全部相册），UIImagePickerControllerSourceTypePhotoLibrary
        //获取方式2，通过相机，UIImagePickerControllerSourceTypeCamera
        //获取方法3，通过相册（呈现全部图片），UIImagePickerControllerSourceTypeSavedPhotosAlbum
        PickerImage.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        //允许编辑，即放大裁剪
        PickerImage.allowsEditing = YES;
        //自代理
        PickerImage.delegate = self;
        //页面跳转
        [self presentViewController:PickerImage animated:YES completion:nil];
    }]];
    //按钮：拍照，类型：UIAlertActionStyleDefault
    [alert addAction:[UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        /**
         其实和从相册选择一样，只是获取方式不同，前面是通过相册，而现在，我们要通过相机的方式
         */
        UIImagePickerController *PickerImage = [[UIImagePickerController alloc]init];
        //获取方式:通过相机
        PickerImage.sourceType = UIImagePickerControllerSourceTypeCamera;
        PickerImage.allowsEditing = YES;
        PickerImage.delegate = self;
        [self presentViewController:PickerImage animated:YES completion:nil];
    }]];
    //按钮：取消，类型：UIAlertActionStyleCancel
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //定义一个newPhoto，用来存放我们选择的图片。
    UIImage *newPhoto = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    //把newPhono设置成头像
    _personalImage.image = newPhoto;
    //关闭当前界面，即回到主界面去
    [self dismissViewControllerAnimated:YES completion:nil];
}

//个人设置
- (void)personalSettingView {
    
}

- (void)drawDashLine:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor
{
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    [shapeLayer setBounds:lineView.bounds];
    [shapeLayer setPosition:CGPointMake(CGRectGetWidth(lineView.frame) / 2, CGRectGetHeight(lineView.frame))];
    [shapeLayer setFillColor:[UIColor clearColor].CGColor];
    //  设置虚线颜色为blackColor
    [shapeLayer setStrokeColor:lineColor.CGColor];
    //  设置虚线宽度
    [shapeLayer setLineWidth:CGRectGetHeight(lineView.frame)];
    [shapeLayer setLineJoin:kCALineJoinRound];
    //  设置线宽，线间距
    [shapeLayer setLineDashPattern:[NSArray arrayWithObjects:[NSNumber numberWithInt:lineLength], [NSNumber numberWithInt:lineSpacing], nil]];
    //  设置路径
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 0, 0);
    CGPathAddLineToPoint(path, NULL,CGRectGetWidth(lineView.frame), 0);
    [shapeLayer setPath:path];
    CGPathRelease(path);
    //  把绘制好的虚线添加上来
    [lineView.layer addSublayer:shapeLayer];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0 || section == 1 || section == 3) {
        return 2;
    }
    else if (section == 2) {
        return 3;
    }
    else {
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            return 48;
        }
        else {
            return 44;
        }
    }
    else if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            return 33;
        }
        else {
            return 55;
        }
    }
    else {
        return 44;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    }
    else {
        return 11;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    PersonalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"personal"];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.toolImg.image = [UIImage imageNamed:@"MyOrder"];
            cell.personalLabel.text = @"我的订单";
            cell.orderLabel.text = @"查看全部订单";
        }
        else {
            cell.toolImg.image = [UIImage imageNamed:@"MyCollection"];
            cell.personalLabel.text = @"我的收藏";
        }
    }
    else if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            cell.toolImg.image = [UIImage imageNamed:@"AllAssets"];
            cell.personalLabel.text = @"全部资产";
        }
        else {
            UITableViewCell *cell1 = [[UITableViewCell alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 55)];
            cell1.selectionStyle = UITableViewCellSelectionStyleNone;
            int space = (SCREEN_WIDTH - 3) / 4;
            NSArray *numArr = [NSArray arrayWithObjects:@"0张",@"666",@"6.66",@"6666.66", nil];
            NSArray *namArr = [NSArray arrayWithObjects:@"优惠券",@"云朵币",@"云朵钱包",@"云朵金融", nil];
            for (int i = 0; i < 4; i++) {
                UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(space * i + i, 10, space, 15)];
                label1.text = [numArr objectAtIndex:i];
                label1.textAlignment = NSTextAlignmentCenter;
                label1.font = [UIFont systemFontOfSize:11];
                label1.textColor = OBTION_COLOR(153, 153, 153);
                [cell1 addSubview:label1];
                
                UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(space * i + i, 28, space, 15)];
                label2.text = [namArr objectAtIndex:i];
                label2.textAlignment = NSTextAlignmentCenter;
                label2.font = [UIFont systemFontOfSize:11];
                label2.textColor = OBTION_COLOR(102, 102, 102);
                [cell1 addSubview:label2];
                
                if (i < 3) {
                    UIView *segView = [[UIView alloc]initWithFrame:CGRectMake(space * (i + 1) + i, 16, 1, 23)];
                    segView.backgroundColor = OBTION_COLOR(153, 153, 153);
                    [cell1 addSubview:segView];
                }
            }
            return cell1;
        }
    }
    else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            cell.toolImg.image = [UIImage imageNamed:@"MyDevice"];
            cell.personalLabel.text = @"我的设备";
        }
        else if (indexPath.row == 1) {
            cell.toolImg.image = [UIImage imageNamed:@"FamilyDoctor"];
            cell.personalLabel.text = @"家庭医生";
        }
        else {
            cell.toolImg.image = [UIImage imageNamed:@"MedicalRecords"];
            cell.personalLabel.text = @"病历档案";
        }
    }
    else if (indexPath.section == 3) {
        if (indexPath.row == 0) {
            cell.toolImg.image = [UIImage imageNamed:@"AccountSecurity"];
            cell.personalLabel.text = @"账号安全";
        }
        else {
            cell.toolImg.image = [UIImage imageNamed:@"ServiceCenter"];
            cell.personalLabel.text = @"客服中心";
        }
    }
    else {
        cell.toolImg.image = [UIImage imageNamed:@"SetUp"];
        cell.personalLabel.text = @"设置";
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [setTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            MyDeviceController *mdVC = [[MyDeviceController alloc]init];
            [self.navigationController pushViewController:mdVC animated:YES];
        }
    }
}

@end
