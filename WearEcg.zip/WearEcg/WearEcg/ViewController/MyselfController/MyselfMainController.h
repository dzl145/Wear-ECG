//
//  MyselfMainController.h
//  WearEcg
//
//  Created by HeartDoc on 16/9/28.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ViewControllerBase.h"

@interface MyselfMainController : ViewControllerBase

@property (weak, nonatomic) IBOutlet UIScrollView *mainScrollView;





@end
