//
//  HomeMainController.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/28.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "HomeMainController.h"
#import "WearViewController.h"
#import "HomeMenuView.h"
#import "BodyTemperatureController.h"
#import "ManagementViewController.h"
#import "TabarViewController.h"

@interface HomeMainController ()<HomeMenuViewDelegate,WearViewControllerDelegate>
{
    WearViewController *_wear;
    BodyTemperatureController *_body;
    UIImageView *image;
}
@property (nonatomic, retain)HomeMenuView *menuView;


@end

@implementation HomeMainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _wear = [[WearViewController alloc] init];
    _body = [[BodyTemperatureController alloc] init];
    
    [self initNavigationItemView];
    
    [self addTopView];
    
    [self addFunctionView];
}


-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = NO;
    self.tabBarController.tabBar.hidden = NO;
//    self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 705);
}

-(void)viewDidAppear:(BOOL)animated{
    
    self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 705);
}

#pragma mark - 加载navigationItem
- (void)initNavigationItemView {
    
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"我的健康管理";
    titleLabel.font = [UIFont systemFontOfSize:17];
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-head portrait"] forState:UIControlStateNormal];
//    [leftBtn setImage:[UIImage imageNamed:@"1234567"] forState:UIControlStateNormal];
//    image = [[UIImageView alloc]initWithFrame:CGRectMake(3, 3, 31, 31)];
//    image.image = [UIImage imageNamed:@"icon-head portrait"];
//    image.layer.cornerRadius = image.frame.size.width / 2;
//    image.layer.masksToBounds = YES;
//    [leftBtn addSubview:image];
//    leftBtn.backgroundColor = [UIColor whiteColor];
    leftBtn.frame = CGRectMake(0, 0, 37, 37);
    leftBtn.layer.cornerRadius = leftBtn.frame.size.width / 2;
    leftBtn.layer.masksToBounds = YES;
    [leftBtn addTarget:self action:@selector(chooseHeadPortrait:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setImage:[UIImage imageNamed:@"icon-Customer service"] forState:UIControlStateNormal];
    rightBtn.frame = CGRectMake(0, 0, 37, 37);
    [rightBtn addTarget:self action:@selector(customerService:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightBarItem;
}

#pragma mark - 加载顶部试图
- (void)addTopView {
    _menuView = [[HomeMenuView alloc]init];
    _menuView.delegate = self;
    _menuView.frame = CGRectMake(0, 0, self.view.frame.size.width, 43);
    [self.mainScrollView addSubview:_menuView];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 43, SCREEN_WIDTH, 1)];
    view.backgroundColor = [UIColor colorWithHex:appThemeColor];
    [self.mainScrollView addSubview:view];
}

#pragma mark - 加载主视图
- (void)addFunctionView {
    
    _wear.view.frame = CGRectMake(0, 44, self.view.frame.size.width, 661);
    _wear.delegate = self;
    [self.mainScrollView addSubview:_wear.view];
    [self addChildViewController:_wear];
}

//选择人群
- (void)chooseHeadPortrait:(UIButton *)btn {
    
}

//客服
- (void)customerService:(UIButton *)btn {
    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",@"18632173095"];
    UIWebView * callWebview = [[UIWebView alloc] init];
    [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
    [self.view addSubview:callWebview];
}



#pragma mark - HomeMenuViewDelegate 加载主视图
- (void)btnTag:(NSInteger)btnTag {
    if (btnTag == 100) {
        [self addFunctionView];
        self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 705);
    }
    else if (btnTag == 101) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 44, SCREEN_HEIGHT, 705)];
        view.backgroundColor = OBTION_COLOR(239, 239, 244);
        [self.mainScrollView addSubview:view];
        
        _body.view.frame = CGRectMake(0, 44, SCREEN_WIDTH, 568 - 44);
        self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 568);
        [self.mainScrollView addSubview:_body.view];
        [self addChildViewController:_body];
    }
    else if (btnTag == 102) {
        
    }
    else {
        
    }
}

- (void)setHiddenHomemenuView:(BOOL)isScreen {
    if (isScreen == YES) {
        [_menuView setHidden:YES];
        self.mainScrollView.contentSize = CGSizeMake(SCREEN_HEIGHT, SCREEN_WIDTH);
    }
    else {
        [_menuView setHidden:NO];
    }
}

- (void)setHiddenBodyTemperatureConreoller:(BOOL)isHidden {
    if (isHidden == YES) {
        [_body.view setHidden:YES];
    }
    else {
        [_body.view setHidden:NO];
    }
}

- (void)setHiddenWearConreoller:(BOOL)isHidden {
    if (isHidden == YES) {
        [_wear.view setHidden:YES];
    }
}

- (void)setSlidScroller:(BOOL)isSlid {
    if (isSlid == NO) {
        self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 705);
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
