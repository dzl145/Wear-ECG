//
//  AbnormalRecordsController.m
//  WearEcg
//
//  Created by apple on 16/12/16.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "AbnormalRecordsController.h"
#import "AbnormalCell.h"

@interface AbnormalRecordsController ()
{
    UITableView *_abnormalTable;
}

@end

@implementation AbnormalRecordsController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadHeartView:self.gridview];
    
    [self loadingNavigationView];
    
    [self addAbnormalTableView];
    
    _gainRate = 1.0;
}

- (void)addAbnormalTableView {
    
    [self.gainBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, -30, 0, 0)];
    [self.gainBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 40, 0, 0)];
    
    _abnormalTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 44 + 237 + 44 + 3, SCREEN_WIDTH, 300)];
    _abnormalTable.delegate = self;
    _abnormalTable.dataSource = self;
    [self.view addSubview:_abnormalTable];
    
    [_abnormalTable registerNib:[UINib nibWithNibName:NSStringFromClass([AbnormalCell class]) bundle:nil] forCellReuseIdentifier:@"abnormal"];
    _abnormalTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    
}

- (void)loadingNavigationView {
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"异常记录";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    float size = SCREEN_WIDTH / 25;
    self.timeLabel.font = [UIFont systemFontOfSize:size];
}


- (IBAction)gainBtn:(UIButton *)sender {
    CGPoint point = [sender convertPoint:sender.bounds.origin toView:self.view];
    point.x = (point.x + sender.frame.size.width/2) - 235;
    point.y = point.y + sender.frame.size.height + 30;
    
    GainView * gainView = [[self.view superview] viewWithTag:1001];
    if(gainView != nil) {
        return;
    }
    
    gainView = [[[NSBundle mainBundle] loadNibNamed:@"GainView" owner:self options:nil] objectAtIndex:0];
    gainView.frame = CGRectMake(0,  0, self.view.frame.size.width, self.view.frame.size.height);
    [gainView setScaleGain:_gainRate];
    gainView.delegate = self;
    [gainView setScaleViewPostion:point];
    gainView.tag = 1001;
    [[self.view superview] addSubview:gainView];
    [[self.view superview] bringSubviewToFront:gainView];
}


#pragma mark --GainViewDelegate
- (void)ECGGainViewDelegate:(float)rate{
    _gainRate = rate;
    if (rate == 0.25)
    {
        _gainLabel.text = @"2.5 MM/mv  25.0 MM/s";
    }
    else if (rate == 0.5)
    {
        _gainLabel.text = @"5.0 MM/mv  25.0 MM/s";
    }
    else if (rate == 1.0)
    {
        _gainLabel.text = @"10.0 MM/mv  25.0 MM/s";
    }
    else if (rate == 2.0)
    {
        _gainLabel.text = @"20.0 MM/mv  25.0 MM/s";
    }
    if (rate < 0.5) {
        [self.gainBtn setTitle:[NSString stringWithFormat:@"x%.2f",rate] forState:UIControlStateNormal];
    }
    else{
        [self.gainBtn setTitle:[NSString stringWithFormat:@"x%.1f",rate] forState:UIControlStateNormal];
    }
//    ECGContinueView * ecg = [self.ecgView viewWithTag:1330];
//    if (ecg) {
//        [ecg removeFromSuperview];
//        [self addECG];
//    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    AbnormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"abnormal"];
    cell.numberLabel.text = [NSString stringWithFormat:@"%d",indexPath.row + 1];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    [_abnormalTable deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)loadHeartView:(HeartLive *)viewStyle {
    if (viewStyle == nil) return;
    [self.heartView addSubview:viewStyle];
    [self.gridview setMaxContainerCapacity:2 andScreenWidth:SCREEN_WIDTH];
    viewStyle.translatesAutoresizingMaskIntoConstraints = NO;
    [self.heartView addConstraints:[self getHeartViewLayout:viewStyle]];
}


#pragma mark ---------- 波形图相关 -----------
//显示心电图视图
- (HeartLive *)heartview
{
    if (!_heartview) {
        _heartview = [[HeartLive alloc]init];
        _heartview.drawStyle = HeartDrawStyle_Wave;
        _heartview.backgroundColor = [UIColor clearColor];
    }
    return _heartview;
}
- (HeartLive *)gridview
{
    if (!_gridview) {
        _gridview = [[HeartLive alloc]init];
        _gridview.drawStyle = HeartDrawStyle_Grid;
        _gridview.backgroundColor = [UIColor whiteColor];
    }
    return _gridview;
}

#pragma mark ------ 约束条件
-(NSArray *)getHeartViewLayout:(UIView *)childView {
    NSLayoutConstraint *top = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:_heartView attribute:NSLayoutAttributeTop multiplier:1 constant:0];
    NSLayoutConstraint *bottom = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:_heartView attribute:NSLayoutAttributeBottom multiplier:1 constant:0];
    NSLayoutConstraint *left = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:_heartView attribute:NSLayoutAttributeLeft multiplier:1 constant:0];
    NSLayoutConstraint *right = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:_heartView attribute:NSLayoutAttributeRight multiplier:1 constant:0];
    
    return [NSArray arrayWithObjects:top,bottom,left,right, nil];
}

@end
