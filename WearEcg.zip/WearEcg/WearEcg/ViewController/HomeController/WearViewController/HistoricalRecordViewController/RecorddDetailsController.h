//
//  RecorddDetailsController.h
//  WearEcg
//
//  Created by apple on 16/12/16.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecordEntity+CoreDataProperties.h"

@interface RecorddDetailsController : UIViewController


//心率视图
@property (weak, nonatomic) IBOutlet UIView *heartView;

//呼吸率视图
@property (weak, nonatomic) IBOutlet UIView *breatheView;

@property (nonatomic, assign)BOOL isContinuous;

//时间
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;



//平均心率
@property (weak, nonatomic) IBOutlet UILabel *averageHeartLabel;

//最快心率
@property (weak, nonatomic) IBOutlet UILabel *fastHeartLabel;

//最慢心率
@property (weak, nonatomic) IBOutlet UILabel *slowHeartLabel;

//心率比例图
@property (weak, nonatomic) IBOutlet UIView *heartScaleView;

//呼吸率比例图
@property (weak, nonatomic) IBOutlet UIView *breatheScaleView;

//平均呼吸率
@property (weak, nonatomic) IBOutlet UILabel *averageBreatheLabel;

//最快呼吸率
@property (weak, nonatomic) IBOutlet UILabel *fastBreatheLabel;

//最慢呼吸率
@property (weak, nonatomic) IBOutlet UILabel *slowBreatheLabel;

//数据
@property (nonatomic, retain)NSMutableArray *dataArray;


@property (weak, nonatomic) IBOutlet UIView *intervalView;


@property (weak, nonatomic) IBOutlet UIButton *onePoints;

@property (weak, nonatomic) IBOutlet UIButton *tenPoints;

@property (weak, nonatomic) IBOutlet UIButton *sixtyPoints;



@end
