//
//  HistoricalRecordController.h
//  WearEcg
//
//  Created by apple on 16/12/15.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "JTCalendar.h"
//#import "TUCalendarView.h"

@interface HistoricalRecordController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *belowNavigationView;

@property (weak, nonatomic) IBOutlet UIView *navigationView;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (nonatomic,assign)BOOL isContinuous;

@property (nonatomic,retain)NSMutableArray *continuousArray;

@property (nonatomic,retain)NSMutableArray *singleArray;


@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;

@property (nonatomic, assign)BOOL isMeasure;


@end
