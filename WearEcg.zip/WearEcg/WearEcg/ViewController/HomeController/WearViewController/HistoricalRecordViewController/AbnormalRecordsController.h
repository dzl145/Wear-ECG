//
//  AbnormalRecordsController.h
//  WearEcg
//
//  Created by apple on 16/12/16.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GainView.h"
#import "HeartLive.h"

@interface AbnormalRecordsController : UIViewController<GainViewDelegate,UITableViewDelegate,UITableViewDataSource>


//心电图 波形视图
@property (nonatomic , strong) HeartLive *heartview;

//心电图 格子视图
@property (nonatomic , strong) HeartLive *gridview;


@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property (weak, nonatomic) IBOutlet UIView *heartView;

@property (weak, nonatomic) IBOutlet UILabel *gainLabel;

@property (weak, nonatomic) IBOutlet UIButton *gainBtn;

//波形倍数
@property (nonatomic, assign) CGFloat gainRate;



@end
