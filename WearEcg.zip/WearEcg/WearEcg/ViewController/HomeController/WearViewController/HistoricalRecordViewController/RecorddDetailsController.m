//
//  RecorddDetailsController.m
//  WearEcg
//
//  Created by apple on 16/12/16.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "RecorddDetailsController.h"
#import "AbnormalRecordsController.h"
#import "HeartChartView.h"

@interface RecorddDetailsController ()
{
    int count;
}
@end

@implementation RecorddDetailsController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden = NO;
    
    
    [self loadingNavigationView];
    
    [self loadingTimeTitleView];
    
    [self addGraphView];
    
    [self addBreatheRateView];
    
    [self addHeartRate];
}

- (NSMutableArray *)dataArray {
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}

//显示心率
- (void)addGraphView {
    
    if (self.heartView.subviews) {
        [self.heartView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    
    NSArray * arrColor = [NSArray arrayWithObjects:
                          [UIColor colorWithHex:0xb0daf9],
                          [UIColor colorWithHex:0xd3f6fb],
                          [UIColor colorWithHex:0xe8f4dc],
                          [UIColor colorWithHex:0xfae6d5],
                          [UIColor colorWithHex:0xf7d8d7], nil];
    
    if (!self.dataArray) {
        return;
    }
    NSDate *startDate = [self.dataArray objectAtIndex:0];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm:ss"];
    NSArray *heartArr = [[self.dataArray objectAtIndex:2] componentsSeparatedByString:@","];
    
    CGRect rect = CGRectMake(0, 0, SCREEN_WIDTH, CharViewHeight);
    HeartChartView * charview = [[HeartChartView alloc]initWithFrame:rect objectsArray:heartArr startDate:startDate showStyle:CharViewXShowStyle_ValueInterval colorArray:arrColor YDataValue:20 XDataValue:count];
    [self.heartView insertSubview:charview atIndex:0];
    
    
}

//显示呼吸率
- (void)addBreatheRateView {
    NSArray * arrColor = [NSArray arrayWithObjects:
                          OBTION_COLOR(246, 216, 215),
                          OBTION_COLOR(246, 216, 215),
                          OBTION_COLOR(232, 243, 221),
                          OBTION_COLOR(232, 243, 221),
                          OBTION_COLOR(249, 230, 214), nil];
    CGRect rect = CGRectMake(0, 0, SCREEN_WIDTH, CharViewHeight);
    HeartChartView * charview = [[HeartChartView alloc]initWithFrame:rect objectsArray:nil startDate:nil showStyle:CharViewXShowStyle_Auto colorArray:arrColor YDataValue:4 XDataValue:3];
    [self.breatheView insertSubview:charview atIndex:0];
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.breatheScaleView.frame.size.width, self.breatheScaleView.frame.size.height)];
    image.image = [UIImage imageNamed:@"data-breathing2x"];
    [self.breatheScaleView addSubview:image];
}

- (void)loadingNavigationView {
    
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"记录详情";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    if (self.isContinuous == YES) {
        UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [rightBtn setTitle:[NSString stringWithFormat:@"异常记录"] forState:UIControlStateNormal];
        rightBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        rightBtn.frame = CGRectMake(0, 0, 50, 25);
        [rightBtn addTarget:self action:@selector(abnormalRecords) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
        self.navigationItem.rightBarButtonItem = rightBarItem;
    }
    else {
        [self.intervalView removeFromSuperview];
    }
    float size = SCREEN_WIDTH / 23;
    self.timeLabel.font = [UIFont systemFontOfSize:size];
    
    
}

- (void)loadingTimeTitleView {
    NSString *startTime = [[self.dataArray objectAtIndex:0] convertDateToStringFormat:@"yyyy/MM/dd HH:mm:ss"];
    NSString *endTime = [[self.dataArray objectAtIndex:1] convertDateToStringFormat:@"yyyy/MM/dd HH:mm:ss"];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *startDate = [dateFormatter dateFromString:startTime];
    NSDate *endDate = [dateFormatter dateFromString:endTime];
    NSTimeInterval time=[endDate timeIntervalSinceDate:startDate];
    if ((int)time < 30 * 60) {
        count = 60;
        [self.onePoints setImage:[UIImage imageNamed:@"rollingBall"] forState:UIControlStateNormal];
    }
    else if ((int)time >= 30 * 60 && (int)time <= 180 * 60) {
        count = 60 * 10;
        [self.tenPoints setImage:[UIImage imageNamed:@"rollingBall"] forState:UIControlStateNormal];
    }
    else {
        count = 60 * 60;
        [self.sixtyPoints setImage:[UIImage imageNamed:@"rollingBall"] forState:UIControlStateNormal];
    }
    
    self.timeLabel.text = [NSString stringWithFormat:@"%@~%@",startTime,endTime];
}

//添加心率动态颜色显示
- (void)addHeartRate {
    NSArray * colorArr = @[OBTION_COLOR(49, 207, 197),
                           OBTION_COLOR(112, 187, 43),
                           OBTION_COLOR(253, 127, 36),];
    NSArray * scaleArr = [self getHeartScale];
    BCStatisticsView *view_test = [[BCStatisticsView alloc] initWithFrame:CGRectMake(10, 0, 80, 80) detailsData:colorArr];
    [view_test setLineWidth:5.0];
    [view_test setBackgroundColor:[UIColor whiteColor]];
    
    [view_test setArray_rateOfEachColor:scaleArr];
    [view_test setIsSpace:YES];
    CGFloat normalScale = [scaleArr[1] floatValue] * 100;
    
    [view_test setStr_title:[NSString stringWithFormat:@"%ld%%\r\n正常",(long)normalScale]];
    [view_test setIsAnimated:YES];
    [self.heartScaleView addSubview:view_test];
    
    [self showHeartDestion];
}

//显示心率详细数据
- (void)showHeartDestion {
    NSArray *heartArray = [[self.dataArray objectAtIndex:2] componentsSeparatedByString:@","];
    CGFloat mid_value = [[heartArray valueForKeyPath:@"@avg.floatValue"] intValue];
    NSString *midStr = [NSString stringWithFormat:@"%f",mid_value];
    self.averageHeartLabel.text = [NSString stringWithFormat:@"%@次/分",@(midStr.floatValue)];
    
    CGFloat max_value = [[heartArray valueForKeyPath:@"@max.floatValue"] intValue];
    NSString *maxStr = [NSString stringWithFormat:@"%f",max_value];
    self.fastHeartLabel.text = [NSString stringWithFormat:@"%@次/分",@(maxStr.floatValue)];
    
    CGFloat min_value = [[heartArray valueForKeyPath:@"@min.floatValue"] intValue];
    NSString *minStr = [NSString stringWithFormat:@"%f",min_value];
    self.slowHeartLabel.text = [NSString stringWithFormat:@"%@次/分",@(minStr.floatValue)];
}

//获取心率比例
-(NSArray *)getHeartScale {
    
    NSString *heartStr = [self.dataArray objectAtIndex:2];
    NSArray *heartArr = [NSArray arrayWithArray:[heartStr componentsSeparatedByString:@","]];
    NSMutableArray * sacleArr = [[NSMutableArray alloc]init];
    NSMutableArray * avgArray = [[NSMutableArray alloc]init];
    NSMutableArray * maxArray = [[NSMutableArray alloc]init];
    NSMutableArray * slowArray = [[NSMutableArray alloc]init];
    for (int i = 0; i < heartArr.count; i++) {
        NSInteger heart = [[heartArr objectAtIndex:i] integerValue];
        if (heart < 60) {
            [slowArray addObject:[NSString stringWithFormat:@"%d",heart]];
        }
        else if (heart >= 60 && heart <= 100) {
            [avgArray addObject:[NSString stringWithFormat:@"%d",heart]];
        }
        else {
            [maxArray addObject:[NSString stringWithFormat:@"%d",heart]];
        }
    }
    [sacleArr addObject:[NSString stringWithFormat:@"%f",(float)slowArray.count/heartArr.count]];
    [sacleArr addObject:[NSString stringWithFormat:@"%f",(float)avgArray.count/heartArr.count]];
    [sacleArr addObject:[NSString stringWithFormat:@"%f",(float)maxArray.count/heartArr.count]];
    
    return sacleArr;
}

- (IBAction)clickButtonToChangeWidth:(UIButton *)sender {
    
    if (sender.tag == 20) {
        [self.onePoints setImage:[UIImage imageNamed:@"rollingBall"] forState:UIControlStateNormal];
        [self.tenPoints setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [self.sixtyPoints setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        count = 60;
    }
    else if (sender.tag == 21) {
        [self.onePoints setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [self.tenPoints setImage:[UIImage imageNamed:@"rollingBall"] forState:UIControlStateNormal];
        [self.sixtyPoints setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        count = 60 * 10;
    }
    else if (sender.tag == 22) {
        [self.onePoints setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [self.tenPoints setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [self.sixtyPoints setImage:[UIImage imageNamed:@"rollingBall"] forState:UIControlStateNormal];
        count = 60 * 60;
    }
    [self addGraphView];
}




- (void)popTheLastView {
    [self.dataArray removeAllObjects];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)abnormalRecords {
    AbnormalRecordsController *abnormal = [[AbnormalRecordsController alloc]init];
    [self.navigationController pushViewController:abnormal animated:YES];
}

@end
