//
//  HistoricalRecordController.m
//  WearEcg
//
//  Created by apple on 16/12/15.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "HistoricalRecordController.h"
#import "FDCalendar.h"
#import "HistoricalCell.h"
#import "HistoricalRecordCell.h"
#import "RecorddDetailsController.h"
#import "HistoricalContinuousCell.h"
#import "WearViewController.h"

@interface HistoricalRecordController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate,FDCalendarDelegate>
{
    NSMutableDictionary *eventsByDate;
    UIView *_monthView;
    UITableView *_abnormalListTable;
    NSTimer *_timer;
    UILabel *_timeLabel;
    NSUserDefaults *defaults;
}

@end

@implementation HistoricalRecordController

- (void)viewDidLoad {
    [super viewDidLoad];
    defaults = [NSUserDefaults standardUserDefaults];
    
    [self readDataFromCoreDate:[[NSDate date] convertDateToStringFormat:@"yyyy-MM-dd"]];
    [self readContinueDataFromCoreDate:[[NSDate date] convertDateToStringFormat:@"yyyy-MM-dd"]];
    
    
    self.isContinuous = YES;
    
    self.isMeasure = [defaults boolForKey:ecgIsMeasure];
    [defaults setBool:self.isContinuous forKey:@"chixu"];
    [defaults synchronize];
    
    [self creatMonthViewAndTableView];
    
    self.tabBarController.tabBar.hidden = YES;
    
    _navigationView.backgroundColor = OBTION_COLOR(108, 197, 199);
    
    [self loadingCalendar];
    
    [self registeCell];
    
    [self loadingScrollView];
    
    [self addGestures];
    
    
}

- (NSMutableArray *)continuousArray {
    if (_continuousArray == nil) {
        _continuousArray = [[NSMutableArray alloc]init];
    }
    return _continuousArray;
}
- (NSMutableArray *)singleArray {
    if (_singleArray == nil) {
        _singleArray = [[NSMutableArray alloc]init];
    }
    return _singleArray;
}

- (void)viewWillAppear:(BOOL)animated {
    if (self.isMeasure == YES && [defaults boolForKey:@"single"]) {
        [self addTimer];
    }
    if (self.isMeasure == YES && [defaults boolForKey:@"continue"]) {
        [self addTimer];
    }
    
    self.navigationController.navigationBarHidden = YES;
}

//读取数据
- (void)readDataFromCoreDate:(NSString *)dateString {
    
    NSInteger count = [[defaults objectForKey:SingleCounts] integerValue];
    for (int i = count - 1; i >= 0; i--) {
        NSMutableArray *sinArr = [defaults valueForKey:[NSString stringWithFormat:@"%d",i]];
        NSString *dateStr = [[sinArr objectAtIndex:0] convertDateToStringFormat:@"yyyy-MM-dd"];
        if ([dateStr isEqualToString:dateString]) {
            [self.singleArray addObject:sinArr];
            
        }
    }
    [_abnormalListTable reloadData];
    _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.singleArray.count * 90 + 44 + 49);
    [self loadingScrollView];
}

- (void)readContinueDataFromCoreDate:(NSString *)dateString {
    NSInteger count = [[defaults objectForKey:ContinueCounts] integerValue];
    for (int i = count - 1; i >= 10000; i--) {
        NSMutableArray *continueArr = [defaults valueForKey:[NSString stringWithFormat:@"%d",i]];
        NSString *dateStr = [[continueArr objectAtIndex:0] convertDateToStringFormat:@"yyyy-MM-dd"];
        if ([dateStr isEqualToString:dateString]) {
            [self.continuousArray addObject:continueArr];
        }
    }
    [_abnormalListTable reloadData];
    _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.continuousArray.count * 110 + 44 + 49);
    [self loadingScrollView];
}

//定时器
- (void)addTimer {
    if (_timer == nil) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(changeCurrentTime) userInfo:nil repeats:YES];
    }
}

//定时器方法
- (void)changeCurrentTime {
    NSDate *currentDate = [NSDate date];//获取当前时间，日期
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY/MM/dd hh:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:currentDate];
    _timeLabel.text = dateString;
}

//双击手势
- (void)addGestures {
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doubleTap)];
    [doubleTap setNumberOfTapsRequired:2];
    [self.navigationView addGestureRecognizer:doubleTap];
}

//回到最上方方法
- (void)doubleTap {
    [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

//scrollview大小
- (void)loadingScrollView {
    self.scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, _monthView.frame.size.height + _abnormalListTable.frame.size.height + 1 );
}

//创建表和monthview
- (void)creatMonthViewAndTableView {
    
    self.belowNavigationView.backgroundColor = OBTION_COLOR(99, 182, 181);
    
    [self.segment setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} forState:UIControlStateNormal];
    [self.segment setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} forState:UIControlStateSelected];
    
    _monthView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, (SCREEN_WIDTH - 10) / 7 * 6 + 75)];
    [self.scrollView addSubview:_monthView];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, _monthView.frame.size.height, SCREEN_WIDTH, 1)];
    view.backgroundColor = OBTION_COLOR(108, 197, 199);
    [self.scrollView addSubview:view];
    
    [self addLabelView];
    
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, _monthView.frame.size.height + 45, SCREEN_WIDTH, 1)];
    view1.backgroundColor = OBTION_COLOR(108, 197, 199);
    [self.scrollView addSubview:view1];
    
    
    if (self.continuousArray != nil) {
        _abnormalListTable = [[UITableView alloc]init];
        if (self.isContinuous == YES) {
            _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.continuousArray.count * 110 + 44 + 49);
        }
        else {
            _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.singleArray.count * 90 + 44 + 49);
        }
        _abnormalListTable.scrollEnabled = NO;
        [self.scrollView addSubview:_abnormalListTable];
    }
    else {
        UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, _monthView.frame.size.height + 46 + 30, SCREEN_WIDTH, 44)];
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, view2.frame.size.width, 44)];
        label.text = @"您当前还没有测量记录";
        label.textColor = OBTION_COLOR(102, 102, 102);
        label.textAlignment = NSTextAlignmentCenter;
        [view2 addSubview:label];
        [self.scrollView addSubview:view2];
    }
}

- (void)addLabelView {
    
    
    UIView *labelView = [[UIView alloc]initWithFrame:CGRectMake(0, _monthView.frame.size.height + 1, SCREEN_WIDTH, 44)];
    labelView.backgroundColor = [UIColor whiteColor];
    
    UILabel *meaLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, 0, 70, 44)];
    meaLabel.text = @"当前测量";
    meaLabel.font = [UIFont systemFontOfSize:14];
    [labelView addSubview:meaLabel];
    
    if (self.continuousArray != nil) {
        
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(15 + 70 + 5, 0, SCREEN_WIDTH - 90 - 22 - 15, 44)];
        _timeLabel.font = [UIFont systemFontOfSize:14];
        if (self.isMeasure == YES) {
            UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 32, 10, 22, 22)];
            image.image = [UIImage imageNamed:@"round-present2x"];
            [labelView addSubview:image];
            
            NSDate *currentDate = [NSDate date];//获取当前时间，日期
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"YYYY/MM/dd hh:mm:ss"];
            NSString *dateString = [dateFormatter stringFromDate:currentDate];
            _timeLabel.text = dateString;
        }
        else {
            _timeLabel.text = @"您还没有开始测量";
            _timeLabel.textColor = OBTION_COLOR(102, 102, 102);
        }
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        [labelView addSubview:_timeLabel];
    }
    else {
        UILabel *noTime = [[UILabel alloc]initWithFrame:CGRectMake(15 + 70 + 5, 0, SCREEN_WIDTH - 90 * 2, 44)];
        noTime.font = [UIFont systemFontOfSize:14];
        noTime.text = @"您当前还没有测量数据";
        noTime.alpha = 0.5;
        noTime.textAlignment = NSTextAlignmentCenter;
        [labelView addSubview:noTime];
    }
    
    [self.scrollView addSubview:labelView];
}

//注册单元格
- (void)registeCell {
    _abnormalListTable.delegate = self;
    _abnormalListTable.dataSource = self;
    _abnormalListTable.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [_abnormalListTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    [_abnormalListTable registerNib:[UINib nibWithNibName:NSStringFromClass([HistoricalCell class]) bundle:nil] forCellReuseIdentifier:@"celiang"];
    [_abnormalListTable registerNib:[UINib nibWithNibName:NSStringFromClass([HistoricalRecordCell class]) bundle:nil] forCellReuseIdentifier:@"record"];
    [_abnormalListTable registerNib:[UINib nibWithNibName:NSStringFromClass([HistoricalContinuousCell class]) bundle:nil] forCellReuseIdentifier:@"continuous"];
}

//加载日历
- (void)loadingCalendar {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    FDCalendar *calendar = [[FDCalendar alloc] initWithCurrentDate:[NSDate date]];
    calendar.delegate = self;
    CGRect frame = calendar.frame;
    frame.origin.y = 0;
    calendar.frame = frame;
    [_monthView addSubview:calendar];
}

//点击选择的日期
- (void)selectedDate:(NSDate *)selectedDate {
    
    if (self.isContinuous == YES) {
        
        NSString *dateStr = [selectedDate convertDateToStringFormat:@"yyyy-MM-dd"];
        [self.continuousArray removeAllObjects];
        [self readContinueDataFromCoreDate:dateStr];
    }
    else {
        NSString *dateStr = [selectedDate convertDateToStringFormat:@"yyyy-MM-dd"];
        [self.singleArray removeAllObjects];
        [self readDataFromCoreDate:dateStr];
    }
    
}

//返回上级
- (IBAction)popTheLastView:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
    [_timer invalidate];
    _timer = nil;
}

//清除记录
- (IBAction)clearRecord:(UIButton *)sender {
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"清除测量记录"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
    alert.delegate = self;
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0:
            if (self.isContinuous == YES) {
                [self.continuousArray removeAllObjects];
                _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.continuousArray.count * 110 + 44 + 49);
            }
            else {
                if (self.singleArray.count > 0) {
                    [self.singleArray removeAllObjects];
                    _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.singleArray.count * 90 + 44 + 49);
                }
            }
            [self loadingScrollView];
            [_abnormalListTable reloadData];
            
            break;
        case 1:
            NSLog(@"取消");
            break;
        default:
            break;
    }
}

//连续记录和单次记录
- (IBAction)continuousAndSingleRecord:(UISegmentedControl *)sender {
    if (_monthView.subviews) {
        [_monthView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    if (sender.selectedSegmentIndex == 0) {
        self.isContinuous = YES;
        _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.continuousArray.count * 110 + 44 + 49);
        [self loadingScrollView];
        [_abnormalListTable reloadData];
        [defaults setBool:self.isContinuous forKey:@"chixu"];
        [defaults synchronize];
    }
    else {
        self.isContinuous = NO;
        _abnormalListTable.frame = CGRectMake(0, _monthView.frame.size.height + 46, SCREEN_WIDTH, self.singleArray.count * 90 + 44 + 49);
//        self.scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, _monthView.frame.size.height + _abnormalListTable.frame.size.height + 1 - 64);
        [self loadingScrollView];
        [_abnormalListTable reloadData];
        [defaults setBool:self.isContinuous forKey:@"chixu"];
        [defaults synchronize];
    }
    [self loadingCalendar];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.isContinuous == YES) {
        return self.continuousArray.count;
    }
    else {
        return self.singleArray.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.isContinuous == YES) {
        return 110;
    }
    else {
        return 90;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.isContinuous == YES) {
        HistoricalContinuousCell *cell = [tableView dequeueReusableCellWithIdentifier:@"continuous"];
        __weak typeof (self) weakSelf = self;
        
        NSMutableArray *dataArray = [self.continuousArray objectAtIndex:indexPath.row];
        NSString *startTime = [[dataArray objectAtIndex:0] convertDateToStringFormat:@"HH:mm:ss"];
        NSString *dateTime = [[dataArray objectAtIndex:0] convertDateToStringFormat:@"dd"];
        cell.dateLabel.text = [NSString stringWithFormat:@"%@日",dateTime];
        cell.startTime.text = [NSString stringWithFormat:@"开始时间 %@",startTime];
        NSTimeInterval time = [[dataArray objectAtIndex:1] timeIntervalSinceDate:[dataArray objectAtIndex:0]];
        int times = [[NSString stringWithFormat:@"%f",time] intValue];
        NSString * timeStr = [NSString stringWithFormat:@"%02i:%02i:%02i",times/60/60,times/60 >= 59 ?times/60%60 : times/60 ,times%60];
        
        cell.continuousTime.text = [NSString stringWithFormat:@"持续时间 %@",timeStr];
        NSArray *heartArray = [NSArray arrayWithArray:[[dataArray objectAtIndex:2] componentsSeparatedByString:@","]];
        CGFloat mid_value = [[heartArray valueForKeyPath:@"@avg.floatValue"] intValue];  //平均数
        NSString *midStr = [NSString stringWithFormat:@"%f",mid_value];
        cell.heartLabel.text = [NSString stringWithFormat:@"%@bpm",@(midStr.floatValue)];
        if (mid_value <= 100 && mid_value >= 60) {
            cell.heartNormal.text = @"正常";
            cell.heartLabel.textColor = OBTION_COLOR(40, 188, 33);
            cell.heartNormal.textColor = cell.heartLabel.textColor;
            cell.stateImage.image = [UIImage imageNamed:@"bell-green2x"];
            cell.stateLabel.text = @"心脏很健康";
            cell.stateLabel.textColor = cell.heartLabel.textColor;
            cell.breatheLabel.textColor = cell.heartLabel.textColor;
            cell.breatheNormal.textColor = cell.heartLabel.textColor;
        }
        else if (mid_value > 100) {
            cell.heartNormal.text = @"过快";
            cell.stateLabel.text = @"窦性心率过速";
            cell.stateImage.image = [UIImage imageNamed:@"bell-orange2x"];
            cell.heartLabel.textColor = OBTION_COLOR(252, 17, 27);
            cell.heartNormal.textColor = cell.heartLabel.textColor;
            cell.stateLabel.textColor = cell.heartLabel.textColor;
            cell.breatheLabel.textColor = cell.heartLabel.textColor;
            cell.breatheNormal.textColor = cell.heartLabel.textColor;
        }
        else {
            cell.heartNormal.text = @"过缓";
            cell.stateLabel.text = @"窦性心率过缓";
            cell.stateImage.image = [UIImage imageNamed:@"bell-blue2x"];
            cell.heartLabel.textColor = OBTION_COLOR(62, 121, 203);
            cell.heartNormal.textColor = cell.heartLabel.textColor;
            cell.stateLabel.textColor = cell.heartLabel.textColor;
            cell.breatheLabel.textColor = cell.heartLabel.textColor;
            cell.breatheNormal.textColor = cell.heartLabel.textColor;
        }
        
        
//            __weak typeof (cell) weakCell = cell;
//            cell.mySwipeBlock = ^{
//                for(HistoricalContinuousCell *tmpCell in tableView.visibleCells){
//                    // 将其他正在打开的cell关闭
//                    if (![weakCell isEqual:tmpCell]) {
//                        [tmpCell closeMenu];
//                    }
//    
//                    // 所有cell取消选中状态
//                    tmpCell.selected = NO;
//                }
//            };
        cell.myDeleteBlock =^{
            if (weakSelf.continuousArray.count) {
                [weakSelf.continuousArray removeObjectAtIndex:indexPath.row];

                NSLog(@"删除了 %ld", (long)indexPath.row);
//                    if (indexPath.row == weakSelf.continuousArray.count) {
//                         //删除的是最后一个直接刷新
//                        [_abnormalListTable reloadData];
//                    }
//                    else {
                    // 删除其他的cell，带动画
                    [_abnormalListTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];

                    [_abnormalListTable reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
//                    }
            }
            self.scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, _monthView.frame.size.height + _abnormalListTable.frame.size.height + 1 - 64);
        };
        return cell;
    }
    else {
        HistoricalRecordCell *cell = [tableView dequeueReusableCellWithIdentifier:@"record"];
        cell.numberLabel.text = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
        
//        RecordEntity *record = [self.singleArray objectAtIndex:indexPath.row];
        NSMutableArray *dataArray = [self.singleArray objectAtIndex:indexPath.row];
//        cell.startTimeLabel.text = [NSString stringWithFormat:@"开始时间%@",record.starttime];
//        NSLog(@"%@",record.starttime);
//        NSString *heartStr = record.heartrate;
//        NSArray *heartArray = [NSArray arrayWithArray:[heartStr componentsSeparatedByString:@","]];
//        NSLog(@"%@",heartArray);
        NSString *startTime = [[dataArray objectAtIndex:0] convertDateToStringFormat:@"HH:mm:ss"];
        cell.startTimeLabel.text = [NSString stringWithFormat:@"开始时间 %@",startTime];
        NSArray *heartArray = [NSArray arrayWithArray:[[dataArray objectAtIndex:2] componentsSeparatedByString:@","]];
        CGFloat mid_value = [[heartArray valueForKeyPath:@"@avg.floatValue"] intValue];  //平均数
        NSString *midStr = [NSString stringWithFormat:@"%f",mid_value];
        cell.heartLabel.text = [NSString stringWithFormat:@"%@bpm",@(midStr.floatValue)];
        if (mid_value <= 100 && mid_value >= 60) {
            cell.heartNormalLabel.text = @"正常";
            cell.heartLabel.textColor = OBTION_COLOR(40, 188, 33);
            cell.heartNormalLabel.textColor = cell.heartLabel.textColor;
            cell.healthImage.image = [UIImage imageNamed:@"bell-green2x"];
            cell.healthLabel.text = @"心脏很健康";
            cell.healthLabel.textColor = cell.heartLabel.textColor;
            cell.breatheLabel.textColor = cell.heartLabel.textColor;
            cell.breatheNormalLabel.textColor = cell.heartLabel.textColor;
        }
        else if (mid_value > 100) {
            cell.heartNormalLabel.text = @"过快";
            cell.healthLabel.text = @"窦性心率过速";
            cell.healthImage.image = [UIImage imageNamed:@"bell-orange2x"];
            cell.heartLabel.textColor = OBTION_COLOR(252, 17, 27);
            cell.heartNormalLabel.textColor = cell.heartLabel.textColor;
            cell.healthLabel.textColor = cell.heartLabel.textColor;
            cell.breatheLabel.textColor = cell.heartLabel.textColor;
            cell.breatheNormalLabel.textColor = cell.heartLabel.textColor;
        }
        else {
            cell.heartNormalLabel.text = @"过缓";
            cell.healthLabel.text = @"窦性心率过缓";
            cell.healthImage.image = [UIImage imageNamed:@"bell-blue2x"];
            cell.heartLabel.textColor = OBTION_COLOR(62, 121, 203);
            cell.heartNormalLabel.textColor = cell.heartLabel.textColor;
            cell.healthLabel.textColor = cell.heartLabel.textColor;
            cell.breatheLabel.textColor = cell.heartLabel.textColor;
            cell.breatheNormalLabel.textColor = cell.heartLabel.textColor;
        }
        
        
//            __weak typeof (self) weakSelf = self;
//            __weak typeof (cell) weakCell = cell;
//            cell.mySwipeBlock = ^{
//                for(HistoricalRecordCell *tmpCell in tableView.visibleCells){
//                    // 将其他正在打开的cell关闭
//                    if (![weakCell isEqual:tmpCell]) {
//                        [tmpCell closeMenu];
//                    }
//    
//                    // 所有cell取消选中状态
//                    tmpCell.selected = NO;
//                }
//            };
        cell.myDeleteBlock =^{
//                if (weakSelf.titles.count) {
//                    [weakSelf.titles removeObjectAtIndex:indexPath.row];
//    
//                    NSLog(@"删除了 %ld", indexPath.row);
//                    if (indexPath.row == weakSelf.titles.count) {
//                         //删除的是最后一个直接刷新
//                        [weakSelf.abnormalListTable reloadData];
//                    }else{
//                        // 删除其他的cell，带动画
//                        [weakSelf.abnormalListTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];
//    
//                        [weakSelf.abnormalListTable reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
//                    }
//                }
        };
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 49;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (self.continuousArray != nil) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
        view.backgroundColor = OBTION_COLOR(255, 255, 255);
        UILabel *label = [[UILabel alloc]init];
        label.bounds = CGRectMake(0, 0, 200, 49);
        label.center = CGPointMake(view.frame.size.width/2, view.frame.size.height/2);
        label.text = @"已无更多记录";
        label.textColor = OBTION_COLOR(153, 152, 153);
        label.font = [UIFont systemFontOfSize:14];
        label.textAlignment = NSTextAlignmentCenter;
        [view addSubview:label];
        
        return view;
    }
    else {
        return nil;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [_abnormalListTable deselectRowAtIndexPath:indexPath animated:YES];
    if (self.isContinuous == YES) {
        [_timer invalidate];
        _timer = nil;
        RecorddDetailsController *record = [[RecorddDetailsController alloc]init];
        record.isContinuous = YES;
        record.dataArray = [NSMutableArray arrayWithArray:[self.continuousArray objectAtIndex:indexPath.row]];
        [self.navigationController pushViewController:record animated:YES];
    }
    else {
        [_timer invalidate];
        _timer = nil;
        RecorddDetailsController *record = [[RecorddDetailsController alloc]init];
        record.isContinuous = NO;
        record.dataArray = [NSMutableArray arrayWithArray:[self.singleArray objectAtIndex:indexPath.row]];
        [self.navigationController pushViewController:record animated:YES];
    }
    
}

@end
