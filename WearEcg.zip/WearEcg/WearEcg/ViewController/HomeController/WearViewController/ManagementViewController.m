//
//  ManagementViewController.m
//  WearEcg
//
//  Created by apple on 16/12/12.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ManagementViewController.h"
#import "TabarViewController.h"
#import "ManagementCell.h"
#import "ManagementTwoCell.h"
#import "SearchViewController.h"
#import "AlarmThresholdController.h"
#import "StorageSpaceController.h"
#import "EquipmentInformationController.h"
#import "UseHelpController.h"
#import "stopMeasureView.h"
#import "DebugViewController.h"

@interface ManagementViewController ()<UITableViewDelegate,UITableViewDataSource,SearchBluetoothDelegate,stopMeasureViewDelegate>
{
    UITableView *managementTableView;
    
    NSArray *_topArray;
    
    NSArray *_belowArray;
    
    NSUserDefaults *defaults;
    
    NSString *_deveiceName;
    
    UIImageView *disconnectImage;
}

@end

@implementation ManagementViewController

static NSString * const topCellId = @"manage1";
static NSString * const belowCellId = @"manage2";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    defaults = [NSUserDefaults standardUserDefaults];
    self.isConnected = [defaults boolForKey:@"lianjie"];
    
    self.isBinding = [defaults boolForKey:ecgBinding];
    
    [self loadTheView];
    
    [self registCell];
    
    self.tabBarController.tabBar.hidden = YES;
    
}

//注册单元格
- (void)registCell {
    [managementTableView registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementCell class]) bundle:nil] forCellReuseIdentifier:topCellId];
    [managementTableView registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementTwoCell class]) bundle:nil] forCellReuseIdentifier:belowCellId];
}

//navigationItem
- (void)loadTheView {
    _topArray = [NSArray arrayWithObjects:@"自动搜索连接设备",@"警报设置", nil];
    _belowArray = [NSArray arrayWithObjects:@"查找设备",@"报警阈值",@"设备信息",@"使用帮助",@"厂家调试", nil];
    
    self.view.backgroundColor = OBTION_COLOR(239, 239, 244);
    
    managementTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44 * (_topArray.count + _belowArray.count) + 55)];
    managementTableView.delegate = self;
    managementTableView.dataSource = self;
    managementTableView.scrollEnabled = NO;
    [self.view addSubview:managementTableView];
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"设备管理";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(20, 44 * (_topArray.count + _belowArray.count) + 55 + 40, SCREEN_WIDTH - 40, (SCREEN_WIDTH - 40) / 7.8)];
    [self.view addSubview:view];
    
    disconnectImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    if (self.isConnected == YES) {
        disconnectImage.image = [UIImage imageNamed:@"Disconnect"];
    }
    else {
        disconnectImage.image = [UIImage imageNamed:@"Disconnect3"];
    }
    
    [view addSubview:disconnectImage];
    
    UIButton *disconnectBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, disconnectImage.frame.size.width, disconnectImage.frame.size.height)];
    [disconnectBtn addTarget:self action:@selector(disconnectBtnFromDevice) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:disconnectBtn];
}

- (void)disconnectBtnFromDevice {
    
    if (self.isConnected == YES) {
        disconnectImage.image = [UIImage imageNamed:@"Disconnect3"];
        if ([self.delegate respondsToSelector:@selector(disconnectDeviceFromIOS)]) {
            [self.delegate disconnectDeviceFromIOS];
        }
    }
}

//返回
- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}

//区头高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 44;
    }
    else {
        return 11;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

//区头标题
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
        view.backgroundColor = OBTION_COLOR(239, 239, 244);
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 90, 44)];
        if (self.isBinding == YES) {
            label.text = @"已绑定设备";
        }
        else {
            label.text = @"未绑定设备";
        }
        
        label.font = [UIFont systemFontOfSize:15];
        [view addSubview:label];
        
        UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(20 + label.frame.size.width + 5, 0, 100, 44)];
        lab.textAlignment = NSTextAlignmentRight;
        if (self.isBinding == YES) {
            lab.text = [defaults objectForKey:@"deveice"];
        }
        else {
            lab.text = @"";
        }
        
        lab.font = [UIFont systemFontOfSize:11];
        [view addSubview:lab];
        
        UIButton *bindingBtn = [[UIButton alloc]initWithFrame:CGRectMake(view.frame.size.width - 95, 0, 80, 44)];
        if (self.isBinding == YES) {
            [bindingBtn setTitle:@"解除绑定" forState:UIControlStateNormal];
        }
        else {
            [bindingBtn setTitle:@"绑定设备" forState:UIControlStateNormal];
        }
        bindingBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [bindingBtn setTitleColor:OBTION_COLOR(0, 122, 255) forState:UIControlStateNormal];
        [bindingBtn addTarget:self action:@selector(bingingEquipment) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:bindingBtn];
        
        return view;
    }
    else {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 11)];
        view.backgroundColor = OBTION_COLOR(239, 239, 244);
        return view;
    }
}

//区个数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

//行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 2;
    }
    else {
        return 5;
    }
}

//单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        ManagementCell *cell = [tableView dequeueReusableCellWithIdentifier:topCellId];
        cell.label.text = _topArray[indexPath.row];
        cell.manageSwitch.tag = indexPath.row + 10;
        if (indexPath.row == 0) {
            self.isAutomaticSearch = [defaults boolForKey:ecgSearch];
            [cell.manageSwitch setOn:self.isAutomaticSearch];
        }
        else {
            self.isAutomaticAlarm = [defaults boolForKey:ecgAlarm];
            [cell.manageSwitch setOn:self.isAutomaticAlarm];
        }
        [cell.manageSwitch addTarget:self action:@selector(swtichAction:) forControlEvents:UIControlEventValueChanged];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else {
        ManagementTwoCell *cell = [tableView dequeueReusableCellWithIdentifier:belowCellId];
        cell.label.text = _belowArray[indexPath.row];
        cell.pushbtn.tag = indexPath.row + 100;
        [cell.pushbtn addTarget:self action:@selector(pushNextController:) forControlEvents:UIControlEventTouchUpInside];
        
        return cell;
    }
}

//点击单元格
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [managementTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            SearchViewController *search = [[SearchViewController alloc]init];
            search.delegate = self;
            [self.navigationController pushViewController:search animated:YES];
        }
        else if (indexPath.row == 1) {
            AlarmThresholdController *alarm = [[AlarmThresholdController alloc]init];
            [self.navigationController pushViewController:alarm animated:YES];
        }
        else if (indexPath.row == 2) {
            EquipmentInformationController *equipment = [[EquipmentInformationController alloc]init];
            [self.navigationController pushViewController:equipment animated:YES];
        }
        else if (indexPath.row == 3) {
            UseHelpController *use = [[UseHelpController alloc]init];
            [self.navigationController pushViewController:use animated:YES];
        }
        else {
            DebugViewController *debugVC = [[DebugViewController alloc]init];
            [self.navigationController pushViewController:debugVC animated:YES];
        }
    }
}

//switch使用 按钮状态
- (void)swtichAction:(UISwitch *)sender {
    BOOL isButtonOn = [sender isOn];
    if (sender.tag == 10) {
        if (self.isBinding == NO) {
            [sender setOn:NO];
        }
        else {
            if (isButtonOn) {
                self.isAutomaticSearch = YES;
                [defaults setBool:self.isAutomaticSearch forKey:ecgSearch];
                [defaults synchronize];
            }
            else {
                self.isAutomaticSearch = NO;
                [defaults setBool:self.isAutomaticSearch forKey:ecgSearch];
                [defaults synchronize];
            }
        }
        
    }
    else {
        if (isButtonOn) {
            self.isAutomaticAlarm = YES;
            [defaults setBool:self.isAutomaticAlarm forKey:ecgAlarm];
            [defaults synchronize];
        }
        else {
            self.isAutomaticAlarm = NO;
            [defaults setBool:self.isAutomaticAlarm forKey:ecgAlarm];
            [defaults synchronize];
        }
    }
    
}

- (void)pushNextController:(UIButton *)sender {
    
}

- (void)bingingEquipment {
    if (self.isBinding == YES) {
        stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [stop initWithTitle:@"解除已绑定设备" determineButtonTitle:@"是" cancleButtonTitle:@"否"];
        stop.delegate = self;
        UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:stop];
    }
    else {
        stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [stop initWithTitle:@"绑定已连接设备" determineButtonTitle:@"是" cancleButtonTitle:@"否"];
        stop.delegate = self;
        UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:stop];
    }
}

- (void)stopMeasure {
    if (self.isBinding == YES) {
        self.isBinding = NO;
        self.isAutomaticSearch = NO;
        [defaults setBool:self.isAutomaticSearch forKey:ecgSearch];
        [defaults setBool:self.isBinding forKey:ecgBinding];
        [defaults synchronize];
    }
    else {
        self.isBinding = YES;
        self.isAutomaticSearch = YES;
        [defaults setBool:self.isBinding forKey:ecgBinding];
        [defaults setBool:self.isAutomaticSearch forKey:ecgSearch];
        [defaults synchronize];
    }
    [managementTableView reloadData];
}

- (void)isBingding:(BOOL)isBinding withDeveiceName:(NSString *)deveiceName {
    self.isBinding = isBinding;
    self.isAutomaticSearch = isBinding;
    _deveiceName = deveiceName;
    [defaults setObject:deveiceName forKey:@"deveice"];
    [defaults setBool:self.isBinding forKey:ecgBinding];
    [defaults setBool:self.isAutomaticSearch forKey:ecgSearch];
    [defaults synchronize];
    [managementTableView reloadData];
}

- (void)connectBluetooth:(NSDictionary *)blueDic {
    self.isConnected = YES;
    if ([self.delegate respondsToSelector:@selector(connectBluetoothWithDictionary:)]) {
        [self.delegate connectBluetoothWithDictionary:blueDic];
    }
}

@end
