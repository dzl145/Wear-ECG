//
//  ManagementViewController.h
//  WearEcg
//
//  Created by apple on 16/12/12.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ManagementControllerDelegate <NSObject>

- (void)connectBluetoothWithDictionary:(NSDictionary *)blueDic;

- (void)disconnectDeviceFromIOS;

@end

@interface ManagementViewController:UIViewController


@property (nonatomic, assign)BOOL isAutomaticSearch;

@property (nonatomic, assign)BOOL isAutomaticAlarm;

@property (nonatomic, assign)BOOL isBinding;

@property (nonatomic, retain)id<ManagementControllerDelegate> delegate;

@property (nonatomic, assign)BOOL isConnected;

@end
