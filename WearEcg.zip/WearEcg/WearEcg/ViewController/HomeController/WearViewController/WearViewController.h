//
//  WearViewController.h
//  WearEcg
//
//  Created by HeartDoc on 16/9/29.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ViewControllerBase.h"
#import "BluetoothManager.h"
#import "HeartLive.h"
#import "HeartRate.h"
#import "WearViewModel.h"
#import "HeartCloud_SDK.h"
#import <CoreLocation/CoreLocation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@protocol WearViewControllerDelegate <NSObject>
@optional
- (void)setHiddenHomemenuView:(BOOL)isScreen;
- (void)setHiddenBodyTemperatureConreoller:(BOOL)isHidden;
- (void)setHiddenWearConreoller:(BOOL)isHidden;
- (void)setSlidScroller:(BOOL)isSlid;
- (void)setPacketLossString:(NSString *)percent;

@end

@interface WearViewController : ViewControllerBase<CBCentralManagerDelegate,CBPeripheralDelegate>

// 蓝牙检测
@property (nonatomic,strong)CBCentralManager *centralManager;
//蓝牙管理
@property (nonatomic, strong)BluetoothManager *blueManager;

//心电图 波形视图
@property (nonatomic, strong)HeartLive *heartview;

//心电图 格子视图
@property (nonatomic, strong)HeartLive *gridview;

@property (nonatomic, strong)HeartRate *heartRate;

//显示波形的数据源
@property (nonatomic, strong)NSMutableArray *dataSource;
@property (nonatomic, retain)NSMutableArray *heartRateDataSource;

@property (strong, nonatomic) WearViewModel *wearViewModel;
//心电图所在view
@property (weak, nonatomic) IBOutlet UIView *smallHeartView;

@property (weak, nonatomic) IBOutlet UIView *TopView;
//心电图返回
@property (weak, nonatomic) IBOutlet UIButton *backLandscape;
//心电图心率值
@property (weak, nonatomic) IBOutlet UILabel *HeartValueLabel;
//心电图连接
@property (weak, nonatomic) IBOutlet UILabel *connectLabel;
//心电图测量持续时间
@property (weak, nonatomic) IBOutlet UILabel *testLabel;
//心电图增益
@property (weak, nonatomic) IBOutlet UILabel *gainLabel;
@property (weak, nonatomic) IBOutlet UIButton *gainBtn;


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *smallHeartViewTop;

//波形倍数
@property (nonatomic, assign) CGFloat gainRate;


//信号强度图片
@property (weak, nonatomic) IBOutlet UIImageView *signImage;
//脱联
@property (weak, nonatomic) IBOutlet UIButton *RA_btn;
@property (weak, nonatomic) IBOutlet UIButton *LA_btn;
//电量图片数字
@property (weak, nonatomic) IBOutlet UIImageView *electric_img;
@property (weak, nonatomic) IBOutlet UILabel *electric_lab;

//有无连接设备
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
//开始时间
@property (weak, nonatomic) IBOutlet UILabel *startTimeLabel;
//持续时间
@property (weak, nonatomic) IBOutlet UILabel *longTimeLabel;
//心率
@property (weak, nonatomic) IBOutlet UILabel *heartLabel;
//呼吸率
@property (weak, nonatomic) IBOutlet UILabel *breatheLabel;
@property (weak, nonatomic) IBOutlet UIImageView *memoryImage;

//占用内存
@property (weak, nonatomic) IBOutlet UILabel *memoryLabel;
//心率图
@property (weak, nonatomic) IBOutlet UIView *heartView;
//呼吸率图
@property (weak, nonatomic) IBOutlet UIView *breatheView;
//开始按钮
@property (weak, nonatomic) IBOutlet UIButton *startBtn;

@property (weak, nonatomic) IBOutlet UILabel *heartRateLabel;

@property (weak, nonatomic) IBOutlet UILabel *breatheRateLabel;

@property (weak, nonatomic) IBOutlet UIView *startView;

@property (weak, nonatomic) IBOutlet UIView *taskView;

@property (weak, nonatomic) IBOutlet UIView *titleView;

@property (weak, nonatomic) IBOutlet UIView *timeView;

@property (weak, nonatomic) IBOutlet UIView *memoryView;


@property (nonatomic, assign)BOOL isHeartView;

//按钮状态
@property (nonatomic, assign)BOOL isMeasure;

//单次还是连续
@property (nonatomic, assign)BOOL isSingle;

//蓝牙是否连接
@property (nonatomic, assign)BOOL isConnected;


@property (nonatomic, retain)id<WearViewControllerDelegate> delegate;

@property (strong, nonatomic) HeartCloud_SDK * BlueSdk;

//统计蓝牙包数
@property (nonatomic, assign) NSInteger dataPacket;
@property (weak, nonatomic) IBOutlet UILabel *packetLabel;

//测量心率数据集合(同上，1s获取一次 数据比较少)
@property (nonatomic, strong) NSMutableArray *heartSingleArray;
@property (nonatomic, strong) NSMutableArray *heartContinueArray;

@property (nonatomic, assign) NSInteger singleCount;
@property (nonatomic, assign) NSInteger continueCount;



- (void)setbLeadOff:(int)state;
- (void)setarynDataOrg:(NSInteger)cad;
- (void)heartRateDateOrg:(NSInteger)cad;
- (void)changeTime;

@end
