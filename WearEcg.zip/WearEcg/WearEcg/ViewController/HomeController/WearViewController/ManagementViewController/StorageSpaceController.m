//
//  StorageSpaceController.m
//  WearEcg
//
//  Created by apple on 16/12/14.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "StorageSpaceController.h"
#import "StorageView.h"

@interface StorageSpaceController ()

@end

@implementation StorageSpaceController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadingInitialInterface];
    
    [self circle];
    
    [self creatBtn];
}

- (void)loadingInitialInterface {
    self.view.backgroundColor = OBTION_COLOR(239, 239, 244);
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"存储空间";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setImage:[UIImage imageNamed:@"icon-close2x"] forState:UIControlStateNormal];
    rightBtn.frame = CGRectMake(0, 0, 25, 25);
    [rightBtn addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightBarItem;
}


- (void)circle {
    StorageView *storage = [[StorageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT / 2)];
    [self.view addSubview:storage];
}

- (void)creatBtn {
    NSString *str1 = @"清除缓存 0MB";
    UIButton *cacheBtn = [[UIButton alloc]init];
    cacheBtn.bounds = CGRectMake(0, 0, 183, 47);
    cacheBtn.center = CGPointMake(SCREEN_WIDTH / 2, self.view.frame.size.height / 2 + 50);
    [cacheBtn setTitle:str1 forState:UIControlStateNormal];
    cacheBtn.backgroundColor = [UIColor colorWithHex:0x4fc1e5];
    [cacheBtn addTarget:self action:@selector(clearCache) forControlEvents:UIControlEventTouchUpInside];
    cacheBtn.layer.cornerRadius = 5;
    cacheBtn.layer.masksToBounds = YES;
    [self.view addSubview:cacheBtn];
    
    NSString *str2 = @"清除历史记录 0MB";
    UIButton *recordBtn = [[UIButton alloc]init];
    recordBtn.bounds = CGRectMake(0, 0, 183, 47);
    recordBtn.center = CGPointMake(SCREEN_WIDTH / 2, self.view.frame.size.height / 2 + 120);
    [recordBtn setTitle:str2 forState:UIControlStateNormal];
    recordBtn.backgroundColor = [UIColor colorWithHex:0x68c5c8];
    [recordBtn addTarget:self action:@selector(clearRecord) forControlEvents:UIControlEventTouchUpInside];
    recordBtn.layer.cornerRadius = 5;
    recordBtn.layer.masksToBounds = YES;
    [self.view addSubview:recordBtn];
}

- (void)clearCache {
    
}

- (void)clearRecord {
    
}

- (void)goBack {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
