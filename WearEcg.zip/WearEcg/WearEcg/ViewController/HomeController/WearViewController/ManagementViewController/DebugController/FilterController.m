//
//  FilterController.m
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "FilterController.h"
#import "ManagementThreeCell.h"
#import "BluetoothManager.h"

@interface FilterController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FilterController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadingNavigation];
    
    [self registTableView];
}

- (NSMutableArray *)dataArray {
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}

- (void)loadingNavigation {
    
    self.dataArray = [NSMutableArray arrayWithObjects:@"10",@"20",@"40", nil];
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"滤波模式";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
}

- (void)registTableView {
    UITableView *table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44 * 3)];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    
    [table registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementThreeCell class]) bundle:nil] forCellReuseIdentifier:@"manage3"];
}

- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ManagementThreeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"manage3"];
    cell.label.text = [self.dataArray objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //发送命令
    BluetoothManager *manager = [BluetoothManager ShareBluetooth];
    NSString *str;
    if (indexPath.row == 0) {
        str = [NSString stringWithFormat:@"5a810d0a"];
    }
    else if (indexPath.row == 1) {
        str = [NSString stringWithFormat:@"5a820d0a"];
    }
    else {
        str = [NSString stringWithFormat:@"5a830d0a"];
    }
    [manager sendCommndStrToBluetooth:str isReply:NO];
}

@end
