//
//  WireUpgradeController.m
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "WireUpgradeController.h"

@interface WireUpgradeController ()

@end

@implementation WireUpgradeController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}



@end
