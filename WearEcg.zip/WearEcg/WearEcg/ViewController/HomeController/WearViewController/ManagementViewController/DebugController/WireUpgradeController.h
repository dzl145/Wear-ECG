//
//  WireUpgradeController.h
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WireUpgradeController : UIViewController

@end
