//
//  DeviceNameController.m
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "DeviceNameController.h"

@interface DeviceNameController ()

@end

@implementation DeviceNameController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}



@end
