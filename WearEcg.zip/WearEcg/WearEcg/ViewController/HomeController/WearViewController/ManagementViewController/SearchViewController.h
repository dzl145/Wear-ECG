//
//  SearchViewController.h
//  WearEcg
//
//  Created by apple on 16/12/13.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartCloud_SDK.h"
#import <CoreLocation/CoreLocation.h>

// 蓝牙搜索协议代理
@protocol SearchBluetoothDelegate <NSObject>

@optional
//连接蓝牙
- (void)connectBluetooth:(NSDictionary *)blueDic;
//连接的设备名
- (void)deveiceName:(NSString *)deveiceName;
//绑定
- (void)isBingding:(BOOL)isBinding withDeveiceName:(NSString *)deveiceName;


@end


@interface SearchViewController : UIViewController<CBCentralManagerDelegate,UIAlertViewDelegate>


// 蓝牙检测
@property (nonatomic,strong)CBCentralManager *centralManager;

@property (weak, nonatomic) IBOutlet UIImageView *smallBall;

@property (nonatomic, assign)float originalAngle;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UIView *searchView;

@property (weak, nonatomic) IBOutlet UILabel *promptLabel;
@property (weak, nonatomic) IBOutlet UILabel *searchLabel;

//蓝牙是否打开
@property (nonatomic, assign)BOOL blueToothOpen;

//代理对象
@property (weak, nonatomic)id<SearchBluetoothDelegate> delegate;

//蓝牙连接SDK
@property (strong, nonatomic) BluetoothManager * blueManager;

//是否绑定
@property (nonatomic, assign)BOOL isBinding;


@end


