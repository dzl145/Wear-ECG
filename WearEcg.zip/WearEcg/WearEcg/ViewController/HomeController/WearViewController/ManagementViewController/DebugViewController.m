//
//  DebugViewController.m
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "DebugViewController.h"
#import "DebugShowController.h"
#import "ConnectStateView.h"

@interface DebugViewController ()
{
    ConnectStateView *connectState;
}
@end

@implementation DebugViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadingNavigation];
}

- (void)loadingNavigation {
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"厂家调试";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
}

- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)determineButton:(UIButton *)sender {
    [self.view endEditing:YES];
    if ([self.passwordTF.text isEqualToString:@"456123"]) {
        DebugShowController *debugShowVC = [[DebugShowController alloc]init];
        [self.navigationController pushViewController:debugShowVC animated:YES];
    }
    else {
        connectState = [[ConnectStateView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [connectState initWithTitle:@"密码输入错误,请重新输入"];
        UIView * keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:connectState];
        
        [self performSelector:@selector(delayMethod) withObject:nil afterDelay:1.5];
    }
}

- (void)delayMethod {
    [connectState removeFromSuperview];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

@end
