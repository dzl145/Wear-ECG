//
//  SearchViewController.m
//  WearEcg
//
//  Created by apple on 16/12/13.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//
#define CENTER_X SCREEN_WIDTH / 2
#define CENTER_Y 136
#define RADIUS 91

#import "SearchViewController.h"
#import "ManuallyAddController.h"
#import "SearchCell.h"
#import "ManualCell.h"
#import "EquipmentCell.h"
#import "HomeMainController.h"
#import "stopMeasureView.h"

@interface SearchViewController ()<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,BluetoothManagerDelegate,stopMeasureViewDelegate,UIAlertViewDelegate>
{
    NSTimer *timer;
    NSUserDefaults *defaults;
    NSString * blueName;
}
@end

@implementation SearchViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    defaults = [NSUserDefaults standardUserDefaults];
    
    self.isBinding = [defaults boolForKey:ecgBinding];
    
    [self registCell];
    [self addView];
    
    self.centralManager = [[CBCentralManager alloc]initWithDelegate:self queue:nil options:nil];
    
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}


- (void)viewWillAppear:(BOOL)animated {
    self.blueManager = [BluetoothManager ShareBluetooth];
    [self.blueManager addDelegateForBlueArr:self];
    self.blueManager.delegate = self;
}

//注册单元格
- (void)registCell {
    [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass([SearchCell class]) bundle:nil] forCellReuseIdentifier:@"cellID"];
    [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass([ManualCell class]) bundle:nil] forCellReuseIdentifier:@"manual"];
    [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass([EquipmentCell class]) bundle:nil] forCellReuseIdentifier:@"equipment"];
}

- (IBAction)searchDevice:(UIButton *)sender {
    if (_blueToothOpen == YES) {
        [self searchEquipment];
    }
}


//转动定时器
- (void)addSearchTimer {
    _originalAngle = 180.0;
    
    if (timer == nil) {
        timer = [NSTimer scheduledTimerWithTimeInterval:0.005 target:self selector:@selector(circle) userInfo:Nil repeats:YES];
    }
}

//navigationItem
- (void)addView {
    
    self.view.backgroundColor = OBTION_COLOR(239, 239, 244);
    _promptLabel.backgroundColor = [UIColor clearColor];
    _promptLabel.textColor = OBTION_COLOR(153, 153, 153);
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.pagingEnabled = NO;
    
    _searchView.backgroundColor = OBTION_COLOR(239, 239, 244);
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"查找设备";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setImage:[UIImage imageNamed:@"icon-thehook2x"] forState:UIControlStateNormal];
    rightBtn.frame = CGRectMake(0, 0, 25, 25);
    [rightBtn addTarget:self action:@selector(determine) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightBarItem;
}

//返回按钮
- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
    [self.blueManager stopAddingMode];
    [timer invalidate];
    timer = nil;
}

//扫描二维码
- (void)determine {
//    [self.navigationController popViewControllerAnimated:YES];
//    NSArray * ctrlArray = self.navigationController.viewControllers;
//    [self.navigationController popToViewController:[ctrlArray objectAtIndex:0] animated:YES];
    
    
    [self.blueManager stopAddingMode];
    [timer invalidate];
    timer = nil;
}

//搜索设备
- (void)searchEquipment {
    self.searchLabel.text = @"正在查找设备";
    [self.blueManager.BlueNumberArr removeAllObjects];
    if (_blueToothOpen == YES) {
        [self addSearchTimer];
        [[NSRunLoop currentRunLoop]addTimer:timer forMode:NSRunLoopCommonModes];
        //开始搜索设备
        AU_RESULT_START_ADDING_MODE result = [self.blueManager startAddingMode:NO];
         if (result == AU_RESULT_START_ADDING_MODE_OK) {
         }
    }
    else {
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        NSString *app_Name = [infoDictionary objectForKey:@"CFBundleName"];
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"打开蓝牙来允许“%@”连接到",app_Name] delegate:self cancelButtonTitle:@"设置" otherButtonTitles:@"好", nil];
        [alert show];
    }
}

#pragma mark - CLLocationManagerDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if(buttonIndex == 0) {
        NSURL *url = [NSURL URLWithString:@"prefs:root=Bluetooth"];
        if ([[UIApplication sharedApplication] canOpenURL:url])
        {
            [[UIApplication sharedApplication] openURL:url];
        }
    }
}

#pragma mark - BluetoothManagerDelegate
//搜到到蓝牙回调
- (void)bluetoothFindCallback:(NSString *)uuid withRSSI:(NSNumber *)RSSI {
    [_tableView reloadData];
}

//连接蓝牙成功回调
-(void)bluetoothConnectSucessCallback:(NSString *)uuid withDeviceName:(NSString *)deviceName {
    for (NSDictionary * dic in self.blueManager.BlueNumberArr) {
        if ([dic[@"uuid"] isEqual:uuid]) {
            if ([self.delegate respondsToSelector:@selector(connectBluetooth:)]) {
                [self.delegate connectBluetooth:dic];
            }
            break;
        }
    }
    if (self.isBinding == YES) {
//        NSArray * ctrlArray = self.navigationController.viewControllers;
//        [self.navigationController popToViewController:[ctrlArray objectAtIndex:0] animated:YES];
        [self.blueManager stopAddingMode];
        [timer invalidate];
        timer = nil;
    }
    else {
        stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [stop initWithTitle:@"绑定已连接设备" determineButtonTitle:@"是" cancleButtonTitle:@"否"];
        stop.delegate = self;
        UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:stop];
    }
    
    [self backOut];
}

//转动
- (void)circle {
    _originalAngle++;
    float huDu = _originalAngle/180*M_PI;
    
    float move_x = CENTER_X + RADIUS * cos(huDu);
    float move_y = CENTER_Y + RADIUS * sin(huDu);
    _smallBall.center = CGPointMake(move_x, move_y);
}

#pragma mark - CLLocationManagerDelegate
-(void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    //第一次打开或者每次蓝牙状态改变都会调用这个函数
    if(central.state==CBCentralManagerStatePoweredOn){
        _blueToothOpen = YES;
    }
    else{
        _blueToothOpen = NO;
    }
//    [self searchEquipment];
}

#pragma mark - UITableViewDelegate,UITableViewDateSouce
//区头高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 1) {
        return 22;
    }
    else {
        return 0;
    }
}
// [-CBCentralManagerDelegate centralManagerDidUpdateState:]
//自定义区头标题
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 1) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 22)];
        view.backgroundColor = OBTION_COLOR(239, 239, 244);
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(25, 0, 100, 22)];
        label.text = @"其他设备";
        label.font = [UIFont systemFontOfSize:14];
        [view addSubview:label];
        return view;
    }
    else {
        return [[UIView alloc]init];
    }
}

//区个数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

//行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 1) {
        return self.blueManager.BlueNumberArr.count;
    }
    else {
        return 1;
    }
}

//单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        SearchCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
        if (self.isBinding == YES) {
            cell.equipmentLabel.text = [defaults objectForKey:@"deveice"];
        }
        else {
            cell.equipmentLabel.text = @"无可匹配设备";
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else {
        EquipmentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"equipment"];
        cell.equipmentLabel.text = self.blueManager.BlueNumberArr[indexPath.row][@"deviceName"];
        return cell;
    }
//    else {
//        ManualCell *cell = [tableView dequeueReusableCellWithIdentifier:@"manual"];
//        return cell;
//    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [_tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 1) {
        //连接
        blueName = self.blueManager.BlueNumberArr[indexPath.row][@"deviceName"];
        [defaults setValue:blueName forKey:@"current"];
        [defaults synchronize];
        NSString * uuid = self.blueManager.BlueNumberArr[indexPath.row][@"uuid"];
        for (NSDictionary * blueDic in self.blueManager.BlueNumberArr) {
            if (![blueDic[@"uuid"] isEqualToString:uuid] && [self.blueManager isConnected]) {
                [self.blueManager disconnectDevice];
            }
        }
        //执行连接命令
        [self.blueManager connectNewFoundDevice:uuid withPeripheral:self.blueManager.BlueNumberArr[indexPath.row][@"peripheral"]];
    }
//    if (indexPath.section == 2) {
//        [timer invalidate];
//        timer = nil;
//        ManuallyAddController *add = [[ManuallyAddController alloc]init];
//        [self.navigationController pushViewController:add animated:YES];
//    }
}

- (void)backOut {
    [self.blueManager.BlueNumberArr removeAllObjects];
    [self.blueManager stopAddingMode];
    [self.blueManager removeDelegateFromBlueArr:self];
//    for (UIViewController *controller in self.navigationController.viewControllers) {
//        if ([controller isKindOfClass:[HomeMainController class]]) {
//            HomeMainController *home =(HomeMainController *)controller;
//            [self.navigationController popToViewController:home animated:YES];
//        }
//    }
    [timer invalidate];
    timer = nil;
}

#pragma mark - stopMeasureViewDelegate
- (void)stopMeasure {
//    NSArray * ctrlArray = self.navigationController.viewControllers;
//    [self.navigationController popToViewController:[ctrlArray objectAtIndex:0] animated:YES];
    _originalAngle = 180.0;
    self.searchLabel.text = @"点击开始查找设备";
    self.isBinding = YES;
    [defaults setBool:self.isBinding forKey:ecgBinding];
    [defaults synchronize];
    if ([self.delegate respondsToSelector:@selector(isBingding:withDeveiceName:)]) {
        [self.delegate isBingding:self.isBinding withDeveiceName:blueName];
    }
    
}



@end
