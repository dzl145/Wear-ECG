//
//  DebugShowController.m
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "DebugShowController.h"
#import "SearchCell.h"
#import "WearViewController.h"
#import "FilterController.h"
#import "ManagementCell.h"
#import "BluetoothManager.h"

@interface DebugShowController ()<UITableViewDelegate,UITableViewDataSource,WearViewControllerDelegate>
{
    UITableView *table;
    NSUserDefaults *defaults;
}
@end

@implementation DebugShowController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    defaults = [NSUserDefaults standardUserDefaults];
    
    [self loadingNavigation];
    
    [self registeTableView];
}

- (NSMutableArray *)dataArray {
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}

- (void)loadingNavigation {
    
    
    self.dataArray = [NSMutableArray arrayWithObjects:@"丢包率",@"滤波模式",@"无线升级",@"设备改名",@"重连次数",@"校准时间", nil];
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"调试";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
}

- (void)registeTableView {
    table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44 * 6)];
    table.delegate = self;
    table.dataSource = self;
    table.scrollEnabled = NO;
    [self.view addSubview:table];
    
    [table registerNib:[UINib nibWithNibName:NSStringFromClass([SearchCell class]) bundle:nil] forCellReuseIdentifier:@"cellID"];
    [table registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementCell class]) bundle:nil] forCellReuseIdentifier:@"manage1"];
}

- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == 0) {
        ManagementCell *cell1 = [tableView dequeueReusableCellWithIdentifier:@"manage1"];
        cell1.label.text = @"丢包率";
        [cell1.manageSwitch setOn:[defaults boolForKey:@"diubao"]];
        NSLog(@"%d",[defaults boolForKey:@"diubao"]);
        cell1.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell1.manageSwitch addTarget:self action:@selector(swtichAction:) forControlEvents:UIControlEventValueChanged];
        return cell1;
    }
    else {
        SearchCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
        cell.label.text = [self.dataArray objectAtIndex:indexPath.row];
        if (indexPath.row == 4) {
            cell.equipmentLabel.text = [NSString stringWithFormat:@"%d",[defaults integerForKey:@"number"]];
        }
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [table deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 1) {
        FilterController *filterVC = [[FilterController alloc]init];
        [self.navigationController pushViewController:filterVC animated:YES];
    }
    else if (indexPath.row == 5) {
        NSDate *date = [NSDate date];
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"yyMMddHHmmss"];
        NSString *dateStr = [dateFormatter stringFromDate:date];
        NSString *commandStr = [NSString stringWithFormat:@"50%@0d0a",dateStr];
        NSLog(@"command == %@",commandStr);
        BluetoothManager *blue = [BluetoothManager ShareBluetooth];
        [blue sendCommndStrToBluetooth:commandStr isReply:NO];
    }
}

//switch使用 按钮状态
- (void)swtichAction:(UISwitch *)sender {
    BOOL isButtonOn = [sender isOn];
    if (isButtonOn) {
        [defaults setBool:YES forKey:@"diubao"];
        [defaults synchronize];
    }
    else {
        [defaults setBool:NO forKey:@"diubao"];
        [defaults synchronize];
    }
}

@end
