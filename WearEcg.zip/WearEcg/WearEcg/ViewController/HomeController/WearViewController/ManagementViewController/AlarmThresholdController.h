//
//  AlarmThresholdController.h
//  WearEcg
//
//  Created by apple on 16/12/14.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlarmThresholdController : UIViewController
//上限
@property (weak, nonatomic) IBOutlet UILabel *ceilingLabel;
//下限
@property (weak, nonatomic) IBOutlet UILabel *belowLabel;

//遮罩
@property (strong, nonatomic) UIView *mastView;

//数据源
@property (strong, nonatomic) NSArray *dataArr;
//选择框
@property (strong, nonatomic) UIView *selectView;


@end
