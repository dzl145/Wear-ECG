//
//  AlarmThresholdController.m
//  WearEcg
//
//  Created by apple on 16/12/14.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "AlarmThresholdController.h"


@interface AlarmThresholdController ()<UIPickerViewDelegate,UIPickerViewDataSource>

{
    NSUserDefaults *defaults;
}
@end

@implementation AlarmThresholdController

- (NSArray *)dataArr {
    if (_dataArr == nil) {
        _dataArr = [[NSArray alloc]init];
    }
    return _dataArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    defaults = [NSUserDefaults standardUserDefaults];
    
    [self loadingInitialInterface];
    
}

- (void)loadingInitialInterface {
    
    self.view.backgroundColor = OBTION_COLOR(239, 239, 244);
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"报警阈值";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setImage:[UIImage imageNamed:@"icon-close2x"] forState:UIControlStateNormal];
    rightBtn.frame = CGRectMake(0, 0, 25, 25);
    [rightBtn addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightBarItem;
    
    if ([defaults objectForKey:@"ceilingAlarm"] || [defaults objectForKey:@"belowAlarm"]) {
        self.ceilingLabel.text = [defaults objectForKey:@"ceilingAlarm"];
        self.belowLabel.text = [defaults objectForKey:@"belowAlarm"];
    }
}

- (void)goBack {
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)ceilingPicker:(UIButton *)sender {
    
    NSMutableArray * data = [[NSMutableArray alloc]init];
    for (NSInteger i = 105; i <= 160; i = i + 5) {
        NSString * num = [NSString stringWithFormat:@"%ld次／分",(long)i];
        [data addObject:num];
    }
    self.dataArr = data;
    //创建pickerView
    [self creatPikerView:_dataArr withCeiling:YES];
}


- (IBAction)lowerLimitPicker:(UIButton *)sender {
    
    NSMutableArray * data = [[NSMutableArray alloc]init];
    for (NSInteger i = 20; i <= 60; i = i + 5) {
        NSString * num = [NSString stringWithFormat:@"%ld次／分",(long)i];
        [data addObject:num];
    }
    self.dataArr = data;
    //创建pickerView
    [self creatPikerView:_dataArr withCeiling:NO];
}

- (void)creatPikerView:(NSArray *)data withCeiling:(BOOL)ceiling {
    
    //创建遮罩层
    if (self.mastView != nil) {
        [self.mastView removeFromSuperview];
        self.mastView = nil;
    }
    self.mastView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [self.view addSubview:self.mastView];
    //添加取消键盘手势
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reomveSelectView)];
    [self.mastView addGestureRecognizer:tap];
    
    if (self.selectView != nil) {
        [self.selectView removeFromSuperview];
        self.selectView = nil;
    }
    self.selectView = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - (_dataArr.count - 1) * 44 + 60, SCREEN_WIDTH, _dataArr.count * 44)];
    [self.view addSubview:self.selectView];
    
    int y;
    NSString *str=[_dataArr componentsJoinedByString:@""];
    
    UIPickerView *picker = [[UIPickerView alloc]init];
    if ([str rangeOfString:@"120次／分"].location !=NSNotFound) {
        y = 0;
        picker.frame = CGRectMake(0, 70, SCREEN_WIDTH, 300);
    }
    else {
        y = -60;
        picker.frame = CGRectMake(0, y, SCREEN_WIDTH, 300);
    }
    [picker setBackgroundColor:[UIColor whiteColor]];
    picker.dataSource = self;
    picker.delegate = self;
    if (ceiling == YES) {
        [picker selectRow:5 inComponent:0 animated:NO];
    }
    else {
        [picker selectRow:3 inComponent:0 animated:NO];
    }
    
    [self.selectView addSubview:picker];
}

#pragma mark -- PickerViewDelete
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

//每列的行数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _dataArr.count;
}


//数据赋值
- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component __TVOS_PROHIBITED
{
    return [_dataArr objectAtIndex:row];
}

//选中pickerView中component列row行时触发的事件 联动实现
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *str=[_dataArr componentsJoinedByString:@""];
    if ([str rangeOfString:@"120次／分"].location !=NSNotFound) {
        self.ceilingLabel.text = [_dataArr objectAtIndex:row];
        [defaults setObject:self.ceilingLabel.text forKey:@"ceilingAlarm"];
        [defaults synchronize];
    }
    else {
        self.belowLabel.text = [_dataArr objectAtIndex:row];
        [defaults setObject:self.belowLabel.text forKey:@"belowAlarm"];
        [defaults synchronize];
    }
}

//返回行高
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component __TVOS_PROHIBITED
{
    return 44;
}

- (void)reomveSelectView {
    if (self.mastView != nil) {
        [self.mastView removeFromSuperview];
        self.mastView = nil;
    }
    if (self.selectView != nil) {
        [self.selectView removeFromSuperview];
        self.selectView = nil;
    }
    
}


@end
