//
//  ManuallyAddController.h
//  WearEcg
//
//  Created by apple on 16/12/14.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManuallyAddController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *currentLabel;


@property (weak, nonatomic) IBOutlet UITextField *equipmentTF;


@end
