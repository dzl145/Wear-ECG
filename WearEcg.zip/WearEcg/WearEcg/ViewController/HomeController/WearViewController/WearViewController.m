  //
//  WearViewController.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/29.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "WearViewController.h"
#import "CharView.h"
#import "ManagementViewController.h"
#import "HomeMenuView.h"
#import "HistoricalRecordController.h"
#import "HomeMainController.h"
#import "MeasureView.h"
#import "stopMeasureView.h"
#import "ConnectStateView.h"
#import "SearchViewController.h"
#import "GainView.h"
#import "DebugShowController.h"
#import "ScaleView.h"

@interface WearViewController ()<stopMeasureViewDelegate,MeasureDelegate,BluetoothManagerDelegate,SearchBluetoothDelegate,GainViewDelegate,ManagementControllerDelegate>
{
    //测量时间
    unsigned int seconds;
    
    int bLeadOff;                     //如果脱落为1，否则0  输入数据
    
    //监测时长计时器
    NSTimer *checkTimer;
    //断开时间计时器
    NSTimer *disconnectTimer;
    //记录测量
    NSUserDefaults *defaults;
    //
    ConnectStateView *_state;
    
    SearchViewController *search;
    
    //是否重置波形起始位置
    BOOL isReset;
    BOOL isRateReset;
    //返回数居
    NSString *dataStr;
    //是否打开
    BOOL _blueToothOpen;
    //本页
    BOOL isThisPage;
    
    int _intOriginal;
    
    BOOL disconnectDevice;
    //断开连接时间
    NSInteger _disconnectSeconds;
    
    UILabel *timeLabel;
    
    NSDate *singleStartTime;
    NSDate *continueStartTime;
    
    int time;
    
    UIView *TimeView;
    
    DebugShowController *debug;
    
    int reconnectNumber;
    
    ScaleView *scale;
}

@end

@implementation WearViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.centralManager = [[CBCentralManager alloc]initWithDelegate:self queue:nil options:nil];
    
    search = [[SearchViewController alloc]init];
    search.delegate = self;
    
    _gainRate = 0.5;
    self.dataPacket = 0;
    _intOriginal = 0;
    _disconnectSeconds = 0;
    seconds = 0;
    reconnectNumber = 0;
    
    isReset = NO;
    isRateReset = NO;
    self.isMeasure = NO;
    self.isConnected = NO;
    isThisPage = YES;
    
    defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:self.isMeasure forKey:ecgIsMeasure];
    [defaults setInteger:reconnectNumber forKey:@"number"];
    [defaults setBool:self.isConnected forKey:@"lianjie"];
    [defaults synchronize];
    
    [self addHeartView];
    [self addBreatheRateView];
    
    //添加格子view
    [self loadHeartView:self.gridview];
    
    //添加心电的View
    [self loadHeartView:self.heartview];
    //添加心率view
    [self loadHeartRateView:self.heartRate];
    
    [self addSmallHeartView];
    
    
    if (self.isMeasure == YES) {
        [self changeBtnAndTimeView];
    }
    else {
        [self changeBtnAndTimeViewAfterStop];
    }
    [self creatXAndTime];
    
    if (![defaults objectForKey:SingleCounts]) {
        self.singleCount = 0;
    }
    else {
        self.singleCount = [[defaults objectForKey:SingleCounts] integerValue];
    }
    
    if (![defaults objectForKey:ContinueCounts]) {
        self.continueCount = 10000;
    }
    else {
        self.continueCount = [[defaults objectForKey:ContinueCounts] integerValue];
    }
    
}

- (void)viewWillAppear:(BOOL)animated {
    self.blueManager = [BluetoothManager ShareBluetooth];
    [self.blueManager addDelegateForBlueArr:self];
    self.blueManager.delegate = self;
}

- (WearViewModel *)wearViewModel{
    if (_wearViewModel == nil) {
        _wearViewModel = [[WearViewModel alloc]init:self];
    }
    return _wearViewModel;
}
- (NSMutableArray *)dataSource {
    if (_dataSource == nil) {
        _dataSource = [[NSMutableArray alloc]init];
    }
    return _dataSource;
}
- (NSMutableArray *)heartRateDataSource {
    if (_heartRateDataSource == nil) {
        _heartRateDataSource = [[NSMutableArray alloc]init];
    }
    return _heartRateDataSource;
}
-(NSMutableArray *)heartSingleArray{
    if (_heartSingleArray == nil) {
        _heartSingleArray = [[NSMutableArray alloc]init];
    }
    return _heartSingleArray;
}
-(NSMutableArray *)heartContinueArray{
    if (_heartContinueArray == nil) {
        _heartContinueArray = [[NSMutableArray alloc]init];
    }
    return _heartContinueArray;
}

#pragma mark - CLLocationManagerDelegate
-(void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    //第一次打开或者每次蓝牙状态改变都会调用这个函数
    if(central.state==CBCentralManagerStatePoweredOn){
        _blueToothOpen = YES;
    }
    else{
        _blueToothOpen = NO;
    }
    [self automaticSearch];
}

#pragma mark - 自动搜索
- (void)automaticSearch {
    BOOL isAutomatic = [defaults boolForKey:ecgSearch];
    BOOL isbinding = [defaults boolForKey:ecgBinding];
    if (_blueToothOpen == YES) {
        if (isAutomatic == YES && isbinding == YES) {
            //开始搜索设备
            AU_RESULT_START_ADDING_MODE result = [self.blueManager startAddingMode:NO];
            
            if (result == AU_RESULT_START_ADDING_MODE_OK) {
            }
        }
    }
    else {
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        NSString *app_Name = [infoDictionary objectForKey:@"CFBundleName"];
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"打开蓝牙来允许“%@”连接到",app_Name] delegate:self cancelButtonTitle:@"设置" otherButtonTitles:@"好", nil];
        [alert show];
    }
}

#pragma mark - CLLocationManagerDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if(buttonIndex == 0) {
        NSURL *url = [NSURL URLWithString:@"prefs:root=Bluetooth"];
        if ([[UIApplication sharedApplication] canOpenURL:url])
        {
            [[UIApplication sharedApplication] openURL:url];
        }
    }
}

#pragma mark - 搜索到蓝牙自动连接
- (void)bluetoothFindCallback:(NSString *)uuid withRSSI:(NSNumber *)RSSI {
    
    BOOL isAutomatic = [defaults boolForKey:ecgSearch];
    BOOL isbinding = [defaults boolForKey:ecgBinding];
    if (isAutomatic == YES && isbinding == YES && isThisPage == YES) {
        for (int i = 0; i < self.blueManager.BlueNumberArr.count; i++) {
            NSString *blueName = self.blueManager.BlueNumberArr[i][@"deviceName"];
            NSString *deveiceName = [defaults objectForKey:@"deveice"];
            if ([blueName isEqualToString:deveiceName]) {
                [self.blueManager connectNewFoundDevice:uuid withPeripheral:self.blueManager.BlueNumberArr[i][@"peripheral"]];
            }
        }
    }
}

- (void)addSmallHeartView {
    [self.smallHeartView bringSubviewToFront:self.TopView];
    [self.smallHeartView bringSubviewToFront:self.gainLabel];
    [self.smallHeartView bringSubviewToFront:self.gainBtn];
    
    [self.gainBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, -30, 0, 0)];
    [self.gainBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 50, 0, 0)];
    
    self.TopView.backgroundColor = [UIColor colorWithHex:0x000000];
    self.TopView.alpha = 0.5;
    CGRect rect = self.smallHeartView.frame;
    rect.size.height = SCREEN_WIDTH;
    self.smallHeartView.frame = rect;
    
    scale = [[ScaleView alloc]initWithFrame:CGRectMake(0, 0, 10, self.smallHeartView.frame.size.height)];
    scale.coefficient = _gainRate;
    [self.smallHeartView addSubview:scale];
}

//改变背景
- (void)changeBeijing:(BOOL)connected {
    
    if (connected == NO) {
        self.titleView.backgroundColor = [UIColor colorWithHex:0xe1e1e6];
        self.timeView.backgroundColor = [UIColor colorWithHex:0xe1e1e6];
        self.memoryView.backgroundColor = [UIColor colorWithHex:0xbfbfc3];
    }
    else {
        self.titleView.backgroundColor = [UIColor colorWithHex:0xbee0e4];
        self.timeView.backgroundColor = [UIColor colorWithHex:0xbee0e4];
        self.memoryView.backgroundColor = [UIColor colorWithHex:0x96d3d7];
    }
}

//显示心率
- (void)addHeartView {
    
    debug = [[DebugShowController alloc]init];
    [self changeBeijing:NO];
    
    self.heartLabel.textColor = OBTION_COLOR(44, 129, 3);
    self.breatheLabel.textColor = OBTION_COLOR(44, 129, 3);
    self.HeartValueLabel.textColor = OBTION_COLOR(104, 197, 200);
    self.testLabel.textColor = OBTION_COLOR(104, 197, 200);
    
    NSArray * arrColor = [NSArray arrayWithObjects:
                          [UIColor colorWithHex:0xb0daf9],
                          [UIColor colorWithHex:0xd3f6fb],
                          [UIColor colorWithHex:0xe8f4dc],
                          [UIColor colorWithHex:0xfae6d5],
                          [UIColor colorWithHex:0xf7d8d7], nil];
    
    NSDate *startDate = [NSDate date];
    CGRect rect = CGRectMake(0, 0, SCREEN_WIDTH, CharViewHeight);
    CharView * charview = [[CharView alloc]initWithFrame:rect objectsArray:self.heartRateDataSource startDate:startDate showStyle:CharViewXShowStyle_Auto colorArray:arrColor YDataValue:20 XDataValue:1];
    [self.heartView insertSubview:charview atIndex:0];
}

//显示呼吸率
- (void)addBreatheRateView {
    
    NSArray *arrColor = [NSArray arrayWithObjects:
                         OBTION_COLOR(246, 216, 215),
                         OBTION_COLOR(246, 216, 215),
                         OBTION_COLOR(232, 243, 221),
                         OBTION_COLOR(232, 243, 221),
                         OBTION_COLOR(249, 230, 214), nil];
    
    
    CGRect rect = CGRectMake(0, 0, SCREEN_WIDTH, CharViewHeight);
    CharView * charview = [[CharView alloc]initWithFrame:rect objectsArray:nil startDate:nil showStyle:CharViewXShowStyle_Auto colorArray:arrColor YDataValue:4 XDataValue:1];
    [self.breatheView insertSubview:charview atIndex:0];
}

//创建x轴时间
- (void)creatXAndTime {
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(35, self.heartView.frame.origin.y + 46, self.view.frame.size.width - 35, 1)];
    lineView.backgroundColor = [UIColor lightGrayColor];
    [self.heartView addSubview:lineView];
    UIView *lineView2 = [[UIView alloc]initWithFrame:CGRectMake(35, self.heartView.frame.origin.y + 295, self.view.frame.size.width - 35, 1)];
    lineView2.backgroundColor = [UIColor lightGrayColor];
    [self.heartView addSubview:lineView2];
    
    int number = (SCREEN_WIDTH - 70);
    for (int i = 0; i < 2; i ++) {
        UIView *small = [[UIView alloc]initWithFrame:CGRectMake(35 + number * i, self.heartView.frame.origin.y + 41, 1, 5)];
        small.backgroundColor = [UIColor lightGrayColor];
        [self.heartView addSubview:small];
        
        UIView *small2 = [[UIView alloc]initWithFrame:CGRectMake(35 + number * i, self.heartView.frame.origin.y + 290, 1, 5)];
        small2.backgroundColor = [UIColor lightGrayColor];
        [self.heartView addSubview:small2];
    }
}

-(void)setbLeadOff:(int)state {
    
    bLeadOff = state;
}

#pragma mark - 开始或停止测量
- (IBAction)startAndStopMeasurement:(UIButton *)sender {
    if (self.isConnected == NO) {
        stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [stop initWithTitle:@"请检查蓝牙和设备是否打开" determineButtonTitle:@"连接设备" cancleButtonTitle:@"取消连接"];
        stop.delegate = self;
        UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:stop];
    }
    else {
        if (self.isMeasure == NO) {
            if (disconnectDevice == YES) {
                [self loadingConnectWithTitle:@"设备已断开,正在等待重连"];
            }
            else {
                isReset = YES;
                isRateReset = YES;
                MeasureView *measureView = [[MeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
                measureView.delegate = self;
                UIView * keywindow = [[UIApplication sharedApplication] keyWindow];
                [keywindow addSubview:measureView];
            }
            
        }
        else {
            if (self.isSingle == YES) {//单次
                if (seconds < 30) {
                    stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
                    [stop initWithTitle:@"单次测量未完成将不保存数据,\n确定要停止测量吗?" determineButtonTitle:@"确定" cancleButtonTitle:@"取消"];
                    stop.delegate = self;
                    UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
                    [keywindow addSubview:stop];
                }
            }
            else {//连续
                if (seconds < 20) {
                    stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
                    [stop initWithTitle:@"测量时间太短将不保存数据,\n确定要停止测量吗?" determineButtonTitle:@"确定" cancleButtonTitle:@"取消"];
                    stop.delegate = self;
                    UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
                    [keywindow addSubview:stop];
                }
                else {
                    stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
                    [stop initWithTitle:@"停止本次测量" determineButtonTitle:@"确定" cancleButtonTitle:@"取消"];
                    stop.delegate = self;
                    UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
                    [keywindow addSubview:stop];
                }
            }
        }
    }
}

#pragma mark - 设备管理
- (IBAction)equipmentManagement:(UIButton *)sender {
    isThisPage = NO;
    [self.blueManager stopAddingMode];
    ManagementViewController *managementVC = [[ManagementViewController alloc]init];
    managementVC.delegate = self;
    [self.navigationController pushViewController:managementVC animated:YES];
}

#pragma mark - 历史记录
- (IBAction)historicalRecord:(UIButton *)sender {
    isThisPage = NO;
    [self.blueManager stopAddingMode];
    HistoricalRecordController *historVC = [[HistoricalRecordController alloc]init];
    [self.navigationController pushViewController:historVC animated:YES];
}

#pragma mark - 横屏心电图
- (IBAction)goToECG:(UIButton *)sender {
    isReset = YES;
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    CGFloat duration = [UIApplication sharedApplication].statusBarOrientationAnimationDuration;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    self.navigationController.view.transform = CGAffineTransformIdentity;
    self.navigationController.view.transform = CGAffineTransformMakeRotation(M_PI/2);
    self.navigationController.view.bounds = CGRectMake(0, -22, SCREEN_HEIGHT, SCREEN_WIDTH + 130);
    [UIView commitAnimations];
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    self.smallHeartViewTop.constant = 0;
    NSArray* constrains = self.smallHeartView.constraints;
    for (NSLayoutConstraint* constraint in constrains) {
        if (constraint.firstAttribute == NSLayoutAttributeHeight) {
            constraint.constant = SCREEN_WIDTH;
        }
    }
    
    if ([self.delegate respondsToSelector:@selector(setSlidScroller:)]) {
        [self.delegate setSlidScroller:YES];
    }
    
    [self hiddenAllViews];
    [self.breatheView setHidden:YES];
    [self.heartView setHidden:YES];
    [self.taskView setHidden:YES];
    self.tabBarController.tabBar.hidden = YES;
    [self.heartview setMaxContainerCapacity:2 andScreenWidth:SCREEN_HEIGHT];
    [self.gridview clearContext:YES];
    [self.heartview clearContext:YES];
    
}

#pragma mark - 竖屏
- (IBAction)goToVerticalScreen:(UIButton *)sender {
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    CGFloat duration = [UIApplication sharedApplication].statusBarOrientationAnimationDuration;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:duration];
    self.navigationController.view.transform = CGAffineTransformIdentity;
    self.navigationController.view.transform = CGAffineTransformMakeRotation(M_PI * 2);
    self.navigationController.view.bounds = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    [UIView commitAnimations];
    if ([self.delegate respondsToSelector:@selector(setSlidScroller:)]) {
        [self.delegate setSlidScroller:NO];
    }
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self.breatheView setHidden:NO];
    [self.heartView setHidden:NO];
    [self.taskView setHidden:NO];
    [self notHiddenAllViews];
    self.tabBarController.tabBar.hidden = NO;
    
    
}

- (void)hiddenAllViews {
    if ([self.delegate respondsToSelector:@selector(setHiddenHomemenuView:)]) {
        [self.delegate setHiddenHomemenuView:YES];
    }
    if ([self.delegate respondsToSelector:@selector(setHiddenBodyTemperatureConreoller:)]) {
        [self.delegate setHiddenBodyTemperatureConreoller:YES];
    }
}

- (void)notHiddenAllViews {
    if ([self.delegate respondsToSelector:@selector(setHiddenHomemenuView:)]) {
        [self.delegate setHiddenHomemenuView:NO];
    }
    if ([self.delegate respondsToSelector:@selector(setHiddenBodyTemperatureConreoller:)]) {
        [self.delegate setHiddenBodyTemperatureConreoller:NO];
    }
}

#pragma mark - 改变增益
- (IBAction)changeGainRatio:(UIButton *)sender {
    CGPoint point = [sender convertPoint:sender.bounds.origin toView:self.view];
    point.x = (point.x + sender.frame.size.width/2) - 240;
    point.y = point.y + sender.frame.size.height + 10;
    
    GainView * gainView = [[self.view superview] viewWithTag:1001];
    if(gainView != nil) {
        return;
    }
    
    gainView = [[[NSBundle mainBundle] loadNibNamed:@"GainView" owner:self options:nil] objectAtIndex:0];
    gainView.frame = CGRectMake(0,  0, self.view.frame.size.width, self.view.frame.size.height);
    [gainView setScaleGain:_gainRate];
    gainView.delegate = self;
    [gainView setScaleViewPostion:point];
    gainView.tag = 1001;
    [[self.view superview] addSubview:gainView];
    [[self.view superview] bringSubviewToFront:gainView];
}

#pragma mark --GainViewDelegate
- (void)ECGGainViewDelegate:(float)rate{
    _gainRate = rate;
    if (scale) {
        [scale removeFromSuperview];
        scale = [[ScaleView alloc]initWithFrame:CGRectMake(0, 0, 10, self.smallHeartView.frame.size.height)];
        scale.coefficient = _gainRate;
        [self.smallHeartView addSubview:scale];
    }
    if (rate == 0.25)
    {
        _gainLabel.text = @"2.5 MM/mv  25.0 MM/s";
    }
    else if (rate == 0.5)
    {
        _gainLabel.text = @"5.0 MM/mv  25.0 MM/s";
    }
    else if (rate == 1.0)
    {
        _gainLabel.text = @"10.0 MM/mv  25.0 MM/s";
    }
    else if (rate == 2.0)
    {
        _gainLabel.text = @"20.0 MM/mv  25.0 MM/s";
    }
    if (rate < 0.5) {
        [self.gainBtn setTitle:[NSString stringWithFormat:@"x%.2f",rate] forState:UIControlStateNormal];
    }
    else{
        [self.gainBtn setTitle:[NSString stringWithFormat:@"x%.1f",rate] forState:UIControlStateNormal];
    }
}

//开始测量  改变状态
- (void)changeBtnAndTimeView {
    seconds = 0;
    time = 0;
    [self.startBtn setImage:[UIImage imageNamed:@"icon-stop"] forState:UIControlStateNormal];
    
    NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"HH:mm:ss"];
    NSString * date = [formatter stringFromDate:[NSDate date]];
    self.startTimeLabel.text = date;
    
    if (self.isSingle == YES) {
        singleStartTime = [NSDate date];
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc]init];
        dateFormatter.dateFormat=@"yyyy-MM-dd hh:mm:ss";
        
    }
    else {
        continueStartTime = [NSDate date];
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc]init];
        dateFormatter.dateFormat=@"yyyy-MM-dd hh:mm:ss";
        
    }
    [self changeTime];
    
    checkTimer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(monitorMethod:) userInfo:nil repeats:YES];
    [checkTimer fire];
}

//心率显示时间
- (void)changeTime {
    if (TimeView.subviews) {
        [TimeView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    
    TimeView = [[UIView alloc]initWithFrame:CGRectMake(0, self.heartView.frame.origin.y + 50, SCREEN_WIDTH, 20)];
    [self.heartView addSubview:TimeView];
    for (int i = 0; i < 2; i++) {
    
        timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(10 + 250 * i, 0, 50, 20)];
        NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"HH:mm"];
        NSDate *dat = [NSDate dateWithTimeInterval:60 * i sinceDate:[NSDate date]];
        NSString *dateStr = [formatter stringFromDate:dat];
        
        timeLabel.text = dateStr;
        timeLabel.textAlignment = NSTextAlignmentCenter;
        timeLabel.font = [UIFont systemFontOfSize:10];
        timeLabel.textColor = [UIColor lightGrayColor];
        [TimeView addSubview:timeLabel];
    }
}

//结束测量  改变状态
- (void)changeBtnAndTimeViewAfterStop {
    [self.startBtn setImage:[UIImage imageNamed:@"icon-start"] forState:UIControlStateNormal];
    self.startTimeLabel.text = @"--:--:--";
    self.longTimeLabel.text = @"--:--:--";
    self.heartLabel.text = @"--";
    self.breatheLabel.text = @"--";
    
    self.testLabel.text = @"--:--:--";
    self.HeartValueLabel.text = @"--";
    
    if (checkTimer) {
        [checkTimer invalidate];
        checkTimer = nil;
    }
    
}

//监测计时器
- (void)monitorMethod:(NSTimer *)timer {
    
    seconds++;
    ++time;
    if (time % 4 == 0 && seconds != 0) {
        CGFloat percent = (1 - _dataPacket/200.0) * 100;
        if (percent < 0) {
            percent = 0;
        }
        NSString *percentStr = [NSString stringWithFormat:@"%d%%",(int)percent];
        if ([defaults boolForKey:@"diubao"]) {
            self.packetLabel.text = percentStr;
        }
        
        self.dataPacket = 0;
    }
    NSString * timeStr = [NSString stringWithFormat:@"%02i:%02i:%02i",seconds/60/60,seconds/60 >= 59 ?seconds/60%60 : seconds/60 ,seconds%60];
    self.longTimeLabel.text = timeStr;
    self.testLabel.text = timeStr;
    if (self.isSingle == YES) {
        if (seconds == 30) {
            [self stopMeasureCommand];
            
            NSDate *endTime = [NSDate date];
            NSDateFormatter *dateFormatter=[[NSDateFormatter alloc]init];
            dateFormatter.dateFormat=@"yyyy-MM-dd hh:mm:ss";
            
            NSMutableArray *dataArray = [NSMutableArray arrayWithObjects:singleStartTime,endTime,[self.heartSingleArray componentsJoinedByString:@","], nil];
            [defaults setValue:dataArray forKey:[NSString stringWithFormat:@"%d",self.singleCount]];
            self.singleCount++;
            [defaults setObject:[NSString stringWithFormat:@"%d",self.singleCount] forKey:SingleCounts];
            [defaults synchronize];
            
            [self.heartSingleArray removeAllObjects];
        }
    }
}


- (void)loadHeartView:(HeartLive *)viewStyle {
    if (viewStyle == nil) return;
    [self.smallHeartView addSubview:viewStyle];
    [self.gridview setMaxContainerCapacity:2 andScreenWidth:SCREEN_WIDTH];
    viewStyle.translatesAutoresizingMaskIntoConstraints = NO;
    [self.smallHeartView addConstraints:[self getHeartViewLayout:viewStyle subView:_smallHeartView]];
}

- (void)loadHeartRateView:(HeartRate *)viewStyle {
    if (viewStyle == nil) return;
    [self.heartView addSubview:viewStyle];
    [self.heartRate setMaxContainerCapacity:2 andScreenWidth:SCREEN_WIDTH];
    viewStyle.translatesAutoresizingMaskIntoConstraints = NO;
    [self.heartView addConstraints:[self getHeartViewLayout:viewStyle subView:_heartView]];
}

#pragma mark - 连接成功/失败显示
- (void)loadingConnectWithTitle:(NSString *)title {
    if (_state) {
        [_state removeFromSuperview];
        _state = [[ConnectStateView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [_state initWithTitle:title];
        UIView * keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:_state];
        
        [self performSelector:@selector(delayMethod) withObject:nil afterDelay:2.0];
    }
    else {
        _state = [[ConnectStateView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [_state initWithTitle:title];
        UIView * keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:_state];
        
        [self performSelector:@selector(delayMethod) withObject:nil afterDelay:1.5];
    }
}

//延迟消失
- (void)delayMethod {
    [_state removeFromSuperview];
}

#pragma mark ---------- 波形图相关 -----------
//显示心电图视图
- (HeartLive *)heartview
{
    if (!_heartview) {
        _heartview = [[HeartLive alloc]init];
        _heartview.drawStyle = HeartDrawStyle_Wave;
        _heartview.backgroundColor = [UIColor clearColor];
    }
    return _heartview;
}

- (HeartLive *)gridview
{
    if (!_gridview) {
        _gridview = [[HeartLive alloc]init];
        _gridview.drawStyle = HeartDrawStyle_Grid;
        _gridview.backgroundColor = [UIColor whiteColor];
    }
    return _gridview;
}

- (HeartRate *)heartRate
{
    if (!_heartRate) {
        _heartRate = [[HeartRate alloc]init];
        _heartRate.drawStyle = HeartRateDrawStyle_Wave;
        _heartRate.backgroundColor = [UIColor clearColor];
    }
    return _heartRate;
}

// 刷新方式绘制
- (void)timerRefresnFun
{
    if (_heartview) {
        [[PointContainer sharedContainer] addPointAsRefreshChangeform:[self.wearViewModel bubbleRefreshPoint:_gainRate isreset:isReset]];
        [_heartview fireDrawingWithPoints:[PointContainer sharedContainer].refreshPointContainer pointsCount:[PointContainer sharedContainer].numberOfRefreshElements];
        isReset = NO;
    }
    
}


- (NSArray *)convertDemoData:(short **)rawdata dataLength:(int)length doWilsonConvert:(BOOL)wilsonConvert
{
    NSMutableArray *data = [[NSMutableArray alloc] init];
    for (int i=0; i<12; i++)
    {
        NSMutableArray *array = [[NSMutableArray alloc] init];
        [data addObject:array];
    }
    
    for (int i=0; i<length; i++)
    {
        for (int j=0; j<12; j++)
        {
            NSMutableArray *array = [data objectAtIndex:j];
            NSNumber *number = [NSNumber numberWithInt:rawdata[i][j]];
            [array insertObject:number atIndex:i];
        }
    }
    return data;
}

#pragma mark ------ 约束条件
-(NSArray *)getHeartViewLayout:(UIView *)childView subView:(UIView *)subView {
    NSLayoutConstraint *top = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeTop multiplier:1 constant:0];
    NSLayoutConstraint *bottom = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeBottom multiplier:1 constant:0];
    NSLayoutConstraint *left = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeLeft multiplier:1 constant:0];
    NSLayoutConstraint *right = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeRight multiplier:1 constant:0];
    
    return [NSArray arrayWithObjects:top,bottom,left,right, nil];
}

#pragma mark---------蓝牙的操作方法和协议-----------
//连接蓝牙成功回调
- (void)connectBluetoothWithDictionary:(NSDictionary *)blueDic {
    
    self.blueManager = [BluetoothManager ShareBluetooth];
    [self.blueManager addDelegateForBlueArr:self];
    [self connectBluesucceed:blueDic];
    //192 223 247
}

- (void)connectBluesucceed:(NSDictionary *)blueDict {
    //改变连接设备名称样式
    self.titleLabel.text = @"已连接设备";
    self.connectLabel.text = @"已连接设备";
    
    [self changeBeijing:YES];
    
    self.isConnected = YES;
    [defaults setBool:self.isConnected forKey:@"lianjie"];
    [defaults synchronize];
}

//断开蓝牙回调
- (void)bluetoothDisconnectCallback:(NSString *)uuid withDeviceName:(NSString *)deviceName {
    if ([deviceName hasPrefix:@"MECG"]) {
        NSLog(@"断开蓝牙%@",deviceName);
    }
    reconnectNumber++;
    disconnectDevice = YES;
    [defaults setInteger:reconnectNumber forKey:@"number"];
    [defaults synchronize];
    self.titleLabel.text = @"正在重新连接设备";
    self.connectLabel.text = @"正在重新连接设备";
    [self loadingConnectWithTitle:@"正在重新连接设备"];
    //暂停定时器
    if (checkTimer) {
        [checkTimer setFireDate:[NSDate distantFuture]];
    }
    //开启断开时间定时器
    disconnectTimer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(disconnectTime) userInfo:nil repeats:YES];
    [disconnectTimer fire];
    
}

//断开蓝牙
- (void)disconnectDeviceFromIOS {
    
    [self.blueManager disconnectDevice];
    
    //取消定时器
    if (disconnectTimer) {
        [disconnectTimer invalidate];
        disconnectTimer = nil;
    }
    [self.heartRate clearContext:YES];
    self.titleLabel.text = @"未连接设备";
    self.connectLabel.text = @"未连接设备";
    self.memoryImage.image = [UIImage imageNamed:@"icon-notice"];
    self.memoryLabel.text = @"";
    [self changeBtnAndTimeViewAfterStop];
    self.electric_img.image = [UIImage imageNamed:@"electricity5"];
    self.electric_lab.text = @"";
    [self changeBeijing:NO];
    self.isMeasure = NO;
    [self.RA_btn setTitleColor:OBTION_COLOR(255, 255, 255) forState:UIControlStateNormal];
    [self.LA_btn setTitleColor:OBTION_COLOR(255, 255, 255) forState:UIControlStateNormal];
    [defaults setBool:self.isMeasure forKey:ecgIsMeasure];
    [defaults synchronize];
    self.isConnected = NO;
    [defaults setBool:self.isConnected forKey:@"lianjie"];
    [defaults synchronize];
}

- (void)disconnectTime {
    _disconnectSeconds++;
    
    AU_RESULT_START_ADDING_MODE result = [self.blueManager startAddingMode:NO];
    if (result == AU_RESULT_START_ADDING_MODE_OK) {
        
        for (int i = 0; i < self.blueManager.BlueNumberArr.count; i++) {
            NSString *blueStr = self.blueManager.BlueNumberArr[i][@"deviceName"];
            NSString * uuid = self.blueManager.BlueNumberArr[i][@"uuid"];
            if ([[defaults valueForKey:@"current"] isEqualToString:blueStr]) {
                [self.blueManager connectNewFoundDevice:uuid withPeripheral:self.blueManager.BlueNumberArr[i][@"peripheral"]];
            }
        }
    }
    if (_disconnectSeconds > 600) {
        //取消定时器
        [disconnectTimer invalidate];
        disconnectTimer = nil;
        [self.blueManager stopAddingMode];
        [self.heartRate clearContext:YES];
        //取消屏幕常亮
        [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
        [self storageData];
        self.titleLabel.text = @"未连接设备";
        self.connectLabel.text = @"未连接设备";
        [self changeBtnAndTimeViewAfterStop];
        self.electric_img.image = [UIImage imageNamed:@"electricity5"];
        self.electric_lab.text = @"";
        [self changeBeijing:NO];
        self.isMeasure = NO;
        [self.RA_btn setTitleColor:OBTION_COLOR(255, 255, 255) forState:UIControlStateNormal];
        [self.LA_btn setTitleColor:OBTION_COLOR(255, 255, 255) forState:UIControlStateNormal];
        [defaults setBool:self.isMeasure forKey:ecgIsMeasure];
        [defaults synchronize];
        self.isConnected = NO;
        [defaults setBool:self.isConnected forKey:@"lianjie"];
        [defaults synchronize];
    }
}

//连接重连成功回调
- (void)bluetoothConnectSucessCallback:(NSString *)uuid withDeviceName:(NSString *)deviceName {
    if (uuid == nil) return;
    if ([deviceName hasPrefix:@"MECG"]) {
        NSLog(@"心电设备%@",deviceName);
    }
    disconnectDevice = NO;
    self.blueManager = [BluetoothManager ShareBluetooth];
    NSArray * blueArr = self.blueManager.BlueNumberArr;
    for (NSDictionary * dic in blueArr) {
        if ([dic[@"uuid"] isEqual:uuid]) {
            [self connectBluesucceed:dic];
            break;
        }
    }
    if (checkTimer) {
        //开启定时器
        [checkTimer setFireDate:[NSDate distantPast]];
    }
    if (disconnectTimer) {
        _disconnectSeconds = 0;
        [disconnectTimer invalidate];
        disconnectTimer = nil;
    }
    if ([defaults boolForKey:@"continue"] == NO && [defaults boolForKey:ecgIsMeasure] == YES) {
        //保持屏幕常亮@"ecgIsMeasure"
        [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
        //改变状态
//        [self changeBtnAndTimeView];
        //发送命令
        NSString *commndString = @"51810d0a";
        dataStr = @"";
        [self sendCommndStr:commndString isReply:YES];
    }
//    if (isThisPage == YES) {
        [self loadingConnectWithTitle:@"设备连接成功"];
//    }
}

////重连失败回调
//- (void)bluetoothreReConnectFail {
//    [self stopMeasureCommand];
//    if (isThisPage == YES) {
//        [self loadingConnectWithTitle:@"设备重连失败"];
//    }
//}

#pragma mark ------ 发送命令
//命令计时器 单次命令400s 5次(只要有数据返回则停止发送) 注意:断开蓝牙命令暂时没有返回数据
- (void)sendCommndStr:(NSString *)commndStr isReply:(BOOL)reply {
    [self.blueManager sendCommndStrToBluetooth:commndStr isReply:reply];
}

//收到回复数据回调
-(void)bluetoothReceiveDataCallback:(NSString *)value {
//    NSLog(@"*** %@    ",value);
    //01 电量
    if ([value rangeOfString:@"01"].location != NSNotFound) {
        
        if (value.length > 12) {
            NSUInteger lacation = [value rangeOfString:@"01"].location;
            NSInteger length = value.length - lacation;
            if (length >= 12) {
                NSString * valueStr = [value substringWithRange:NSMakeRange(lacation, 12)];
                [self.wearViewModel parsingElectricity:valueStr];
            }
        }
        else {
            if(value.length == 12) {
                [self.wearViewModel parsingElectricity:value];
            }
        }
    }
    //02 心率数据
    if([value rangeOfString:@"02"].location != NSNotFound) {
//        self.dataPacket++;
        NSArray *dataArr = [value componentsSeparatedByString:@"02"];
        for (int i = 0; i < dataArr.count; i ++) {
            NSString *str = [dataArr objectAtIndex:i];
            if (i == 0) {
                if (dataStr.length == 0) {
                    if (str.length == 26) {
                        str = [@"02" stringByAppendingString:str];
                        [self.wearViewModel parsingHeartRate:str];
                    }
                }
                else {
                    str = [dataStr stringByAppendingString:str];
                    [self.wearViewModel parsingHeartRate:str];
                }
            }
            else if (i == 1) {
                if (str.length == 26) {
                    dataStr = @"";
                    str = [@"02" stringByAppendingString:str];
                    [self.wearViewModel parsingHeartRate:str];
                }
                else {
                    dataStr = [@"02" stringByAppendingString:str];
                }
            }
            else if (i == 2) {
                dataStr = [@"02" stringByAppendingString:str];
            }
        }
    }
    //05 呼吸率数据
    if([value rangeOfString:@"05"].location != NSNotFound) {
//        [self.homeViewModel parsingBreathingRate:value];
    }
    if([value rangeOfString:@"07"].location != NSNotFound) {
        NSLog(@"%@",value);
        NSLog(@"代理接收到指令信息");
        if (value.length > 4) {
            NSUInteger lacation = [value rangeOfString:@"07"].location;
            NSInteger length = value.length - lacation;
            if (length >= 4) {
                NSString * valueStr = [value substringWithRange:NSMakeRange(lacation, 4)];
//                [self.homeViewModel parsingBlueOrder:valueStr];
            }
        }
        else {
            if(value.length == 4){
//                [self.homeViewModel parsingBlueOrder:value];
            }
        }
    }
}
//心电图
- (void)setarynDataOrg:(NSInteger)cad {
    [self.dataSource addObject:[NSNumber numberWithInteger:cad]];
    _intOriginal++;
    if (_intOriginal == 10) {
        [self BluetoothSataTransmission];
        _intOriginal = 0;
    }
}

- (void)BluetoothSataTransmission {
    
    for (int i = 0; i < 10; i ++) {
        [self timerRefresnFun];
    }
    [self.dataSource removeAllObjects];
}

//心率图
- (void)heartRateDateOrg:(NSInteger)cad {
    [self.heartRateDataSource addObject:[NSNumber numberWithInteger:cad]];
    if (self.isSingle == YES) {
        [self.heartSingleArray addObject:[NSNumber numberWithInteger:cad]];
    }
    else {
        [self.heartContinueArray addObject:[NSNumber numberWithInteger:cad]];
    }
    [self heartRateTransmission];
}

- (void)heartRateTransmission {
    [self heartRateTimerRefresnFun];
    
    [self.heartRateDataSource removeAllObjects];
}

// 刷新方式绘制
- (void)heartRateTimerRefresnFun
{
    if (_heartRate) {
        if ([self.wearViewModel heartRateRefreshPoint:_gainRate isReset:isRateReset].x >= (SCREEN_WIDTH - 35)) {
            [self.heartRate clearContext:YES];
            [self changeTime];
            isRateReset = YES;
        }
        [[PointContainerRate sharedContainer] addPointAsRefreshChangeform:[self.wearViewModel heartRateRefreshPoint:_gainRate isReset:isRateReset]];
        [_heartRate fireDrawingWithPoints:[PointContainerRate sharedContainer].refreshPointContainer pointsCount:[PointContainerRate sharedContainer].numberOfRefreshElements];
        isRateReset = NO;
    }
}

#pragma mark - MeasureDelegate
- (void)ECGMeasureDelegate:(BOOL)is60s {
    self.isMeasure = YES;
    [defaults setBool:self.isMeasure forKey:ecgIsMeasure];
    [defaults synchronize];
    self.isSingle = is60s;
//    if (self.isSingle == YES) {
//        [defaults setBool:self.isSingle forKey:@"single"];
//        [defaults synchronize];
//    }
//    else {
//        [defaults setBool:self.isSingle forKey:@"continue"];
//        [defaults synchronize];
//    }
    [defaults setBool:self.isSingle forKey:@"single"];
    [defaults synchronize];
    //保持屏幕常亮
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    //改变状态
    [self changeBtnAndTimeView];
    //发送命令
    NSString *commndString = @"51810d0a";
    dataStr = @"";
    [self sendCommndStr:commndString isReply:YES];
}

#pragma mark - stopMeasureViewDelegate
- (void)stopMeasure {
    
    if (self.isConnected == NO) {
        isThisPage = NO;
        ManagementViewController *managementVC = [[ManagementViewController alloc]init];
        managementVC.delegate = self;
        [self.navigationController pushViewController:managementVC animated:YES];
    }
    else {
        [self stopMeasureCommand];
        [self storageData];
    }
}

- (void)storageData {
    if (self.isSingle == NO && seconds >= 20) {
        NSDate *endTime = [NSDate date];
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc]init];
        dateFormatter.dateFormat=@"yyyy-MM-dd hh:mm:ss";
        
        NSMutableArray *dataArray = [NSMutableArray arrayWithObjects:continueStartTime,endTime,[self.heartContinueArray componentsJoinedByString:@","], nil];
        [defaults setValue:dataArray forKey:[NSString stringWithFormat:@"%d",self.continueCount]];
        self.continueCount++;
        [defaults setObject:[NSString stringWithFormat:@"%d",self.continueCount] forKey:ContinueCounts];
        [defaults synchronize];
        
        [self.heartContinueArray removeAllObjects];
    }
}

- (void)stopMeasureCommand {
    [self.heartRate clearContext:YES];
    self.isMeasure = NO;
    [defaults setBool:self.isMeasure forKey:ecgIsMeasure];
    [defaults synchronize];
    //取消屏幕常亮
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
    [self changeBtnAndTimeViewAfterStop];
    
    //发送命令
    NSString *commndString = @"51820d0a";
    [self sendCommndStr:commndString isReply:NO];
    
    
}


@end
