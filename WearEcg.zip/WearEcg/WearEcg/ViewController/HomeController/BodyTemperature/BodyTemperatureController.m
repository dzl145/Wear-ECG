//
//  BodyTemperatureController.m
//  WearEcg
//
//  Created by apple on 16/12/12.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "BodyTemperatureController.h"
#import "TemHistoryViewController.h"
#import "TemManageViewController.h"
#import "YLIneView.h"
#import "TCircleView.h"
#import "stopMeasureView.h"

@interface BodyTemperatureController ()<stopMeasureViewDelegate>

{
    float x;
    TCircleView *secCircle;
    NSTimer *timer;
}
@property(nonatomic,weak)YLIneView* LineView;
@end

@implementation BodyTemperatureController

//static NSInteger xCoordinateInMoniter = 320;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.equipmentLabel.textColor = OBTION_COLOR(104, 197, 200);
    self.historyLabel.textColor = OBTION_COLOR(104, 197, 200);
    x = 34.0;
    self.isConnect = NO;
    [self setXValuesArray];
    [self loadLineChatView];
    
//    [self loadHeartRateView:self.bodyFigure];
    
    MLHRVView *hrvView = [[MLHRVView alloc] initWithFrame:CGRectMake(45, 20, SCREEN_WIDTH - 45, 160)];
    hrvView.backgroundColor = [UIColor clearColor];
    [self.lineChatView addSubview:hrvView];
    
    self.hrvView = hrvView;
    
//    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(addshuju) userInfo:Nil repeats:YES];
    
    [self creatThermometer];
    [[NSRunLoop currentRunLoop]addTimer:timer forMode:NSRunLoopCommonModes];
}

- (NSMutableArray *)rrNews{
    
    if (!_rrNews) {
        
        _rrNews = [NSMutableArray array];
    }
    
    return _rrNews;
}

- (BodyFigure *)bodyFigure {
    if (!_bodyFigure) {
        _bodyFigure = [[BodyFigure alloc]init];
        _bodyFigure.drawStyle = BodyFigureDrawStyle_Wave;
        _bodyFigure.backgroundColor = [UIColor clearColor];
    }
    return _bodyFigure;
}

- (NSMutableArray *)xValuesArray {
    if (_xValuesArray == nil) {
        _xValuesArray = [[NSMutableArray alloc]init];
    }
    return _xValuesArray;
}

- (NSMutableArray *)bodyFigureValue {
    if (_bodyFigureValue == nil) {
        _bodyFigureValue = [[NSMutableArray alloc]init];
    }
    return _bodyFigureValue;
}

- (void)creatThermometer {
    secCircle=[[TCircleView alloc]initWithFrame:CGRectMake((SCREEN_WIDTH - 200) / 2, 20, 200, 200)];
    secCircle.persentage = (float)(arc4random()%10)/10; // 随机生成一个小数
    [self.view addSubview:secCircle];
    timer = [NSTimer scheduledTimerWithTimeInterval:0.2f target:self selector:@selector(disconnectTime) userInfo:nil repeats:YES];
    [timer fire];
}

- (void)disconnectTime {
//    float b = (float)(arc4random()%100)/100;
    
    x = x + 0.1;
    if (x >= 44.0) {
        x = x - 10.0;
    }
    secCircle.persentage = (float)(0.003175)*(22.5 + (3.857143*(x-35.0)*10));
    self.meaTemperatureLabel.text = [NSString stringWithFormat:@"%.1f°C",x];
    if (x < 36.0) {
        //低温
        self.meaTemperatureLabel.textColor = [UIColor colorWithHex:0x7edfed];
    }
    else if (x >= 36.0 && x <= 37.3) {
        //正常
        self.meaTemperatureLabel.textColor = [UIColor colorWithHex:0x68c5c8];
    }
    else {
        //发烧
        self.meaTemperatureLabel.textColor = [UIColor colorWithHex:0xfaaf4e];
    }
//    self.hrvView.isPass = YES;
//    self.hrvView.rrNew = x;
}

- (void)addshuju {
    
//    x = arc4random()%100;
//    self.bodyFigureValue = [NSMutableArray arrayWithObject:[NSString stringWithFormat:@"%d",x]];
////    [self heartRateTimerRefresnFun];
//    [self.bodyFigureValue removeAllObjects];
    int value = arc4random()%80;
    
    self.hrvView.isPass = YES;
    self.hrvView.rrNew = value;
}

//加载折线图底层
- (void)loadLineChatView {
    
    YLIneView* LineView = [[YLIneView alloc] initWithFrame:CGRectMake(15, 0,(SCREEN_WIDTH - 15), 220)];
    LineView.xKeDuValus = [NSArray arrayWithArray:self.xValuesArray];
    LineView.yKeDuValus = @[@"35.0",@"36.0",@"37.0",@"38.0",@"39.0",@"40.0",@"41.0",@"42.0"];
    LineView.yValueColor = OBTION_COLOR(51, 51, 51);
    LineView.xValueColor = OBTION_COLOR(51, 51, 51);
    [self.lineChatView addSubview:LineView];
    self.LineView = LineView;
}

- (void)setXValuesArray {
    
    NSString *str = @"00:00";
    int count = (SCREEN_WIDTH - 30 - 15) / 56;
    for (int i = 0; i < (count + 1); i++) {
        [self.xValuesArray addObject:str];
    }
}

//开始或停止按钮
- (IBAction)startAndStopButton:(UIButton *)sender {
    if (self.isConnect == NO) {
        stopMeasureView *stop = [[stopMeasureView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        [stop initWithTitle:@"请检查蓝牙和设备是否打开" determineButtonTitle:@"连接设备" cancleButtonTitle:@"取消连接"];
        stop.delegate = self;
        UIView *keywindow = [[UIApplication sharedApplication] keyWindow];
        [keywindow addSubview:stop];
    }
}

//历史记录界面
- (IBAction)goToTheHistoryViewController:(UIButton *)sender {
    TemHistoryViewController *temHistory = [[TemHistoryViewController alloc]init];
    [self.navigationController pushViewController:temHistory animated:YES];
}

//设备管理界面
- (IBAction)goToTheManagementViewController:(UIButton *)sender {
    TemManageViewController *temManage = [[TemManageViewController alloc]init];
    [self.navigationController pushViewController:temManage animated:YES];
}

//连接成功以后改变状态
- (void)changeStateAfterConnected {
    self.meaTemperatureLabel.text = @"00°C";
    self.meaLengthLabel.text = @"测量时长 00:00";
    self.meaResultLabel.text = @"测量结果 正常";
    self.connectionLabel.text = @"已连接设备";
    
    [self.alarmButton setImage:[UIImage imageNamed:@"icon-remindopen2x"] forState:UIControlStateNormal];
    [self.doctorButton setImage:[UIImage imageNamed:@"icon-doctor2x"] forState:UIControlStateNormal];
}

//断开连接以后的状态
- (void)changeStateAfterDisconnected {
    self.meaTemperatureLabel.text = @"－－°C";
    self.meaLengthLabel.text = @"测量时长 --:--";
    self.meaResultLabel.text = @"测量结果 --";
    self.connectionLabel.text = @"无连接设备";
    self.signalImage.image = [UIImage imageNamed:@"icon-wifi2x"];
    self.batteryImage.image = [UIImage imageNamed:@"icon-power2x"];
    [self.alarmButton setImage:[UIImage imageNamed:@"icon-ring noconnect2x"] forState:UIControlStateNormal];
    [self.doctorButton setImage:[UIImage imageNamed:@"icon-doctor noconnect2x"] forState:UIControlStateNormal];
}


- (void)loadHeartRateView:(BodyFigure *)viewStyle {
    if (viewStyle == nil) return;
    [self.lineChatView addSubview:viewStyle];
    [self.bodyFigure setMaxContainerCapacity:2 andScreenWidth:SCREEN_WIDTH];
    viewStyle.translatesAutoresizingMaskIntoConstraints = NO;
    [self.lineChatView addConstraints:[self getHeartViewLayout:viewStyle subView:_lineChatView]];
}


#pragma mark ------ 约束条件
-(NSArray *)getHeartViewLayout:(UIView *)childView subView:(UIView *)subView {
    NSLayoutConstraint *top = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeTop multiplier:1 constant:0];
    NSLayoutConstraint *bottom = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeBottom multiplier:1 constant:0];
    NSLayoutConstraint *left = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeLeft multiplier:1 constant:0];
    NSLayoutConstraint *right = [NSLayoutConstraint constraintWithItem:childView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:subView attribute:NSLayoutAttributeRight multiplier:1 constant:0];
    
    return [NSArray arrayWithObjects:top,bottom,left,right, nil];
}


//计算温度波形的点
- (CGPoint)heartRateRefreshPoint:(float)rate isReset:(BOOL)reset {
    
    CGFloat heartHeight = CGRectGetHeight(self.bodyFigure.frame);
    static NSInteger dataSourceCounterIndex = -1;
    dataSourceCounterIndex ++;
    dataSourceCounterIndex %= [self.bodyFigureValue count];
    //    CGFloat pixelPerPoint = (SCREEN_WIDTH - 70) * 3.6 / 300;
    CGFloat pixelPerPoint = 3;
    //每次以 1 递增 相当于2px(两个像素)
    static NSInteger xCoordinateInMoniter = 45;
    if (reset) {
        xCoordinateInMoniter = 45;
    }
    NSInteger sourceValue = [self.bodyFigureValue[dataSourceCounterIndex] integerValue];
    NSInteger cadwValues = (sourceValue - 80) > 0 ? -(sourceValue - 80) : labs((sourceValue - 80));
    //根据倍数设置
    CGPoint targetPointToAdd = (CGPoint){xCoordinateInMoniter ,(CGFloat)cadwValues + (heartHeight/2 - 8)};//0.4
    xCoordinateInMoniter += pixelPerPoint;
    xCoordinateInMoniter %= (int)(CGRectGetWidth(self.bodyFigure.frame) * 2);//* 2.5
    //    NSLog(@"x == %ld",xCoordinateInMoniter);
    //    NSLog(@"y == %f",(CGFloat)cadwValues + (heartHeight/2 - 12));
    NSLog(@"x == %f  y == %f",targetPointToAdd.x,targetPointToAdd.y);
    
    return targetPointToAdd;
}

// 刷新方式绘制
- (void)heartRateTimerRefresnFun
{
    if (_bodyFigure) {
        [[PointContainerBody sharedContainer] addPointAsRefreshChangeform:[self heartRateRefreshPoint:1.0 isReset:NO]];
        [_bodyFigure fireDrawingWithPoints:[PointContainerBody sharedContainer].refreshPointContainer pointsCount:[PointContainerBody sharedContainer].numberOfRefreshElements];
    }
}

- (void)stopMeasure {
    if (self.isConnect == NO) {
        
    }
    else {
        
    }
}

@end
