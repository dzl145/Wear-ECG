//
//  TemManageViewController.h
//  WearEcg
//
//  Created by dzl on 17/2/14.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TemManageViewController : UIViewController

@end
