//
//  TemUseHelpController.m
//  WearEcg
//
//  Created by dzl on 17/2/16.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "TemUseHelpController.h"

@interface TemUseHelpController ()

@end

@implementation TemUseHelpController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadingInitialInterface];
}

- (void)loadingInitialInterface {
    self.view.backgroundColor = OBTION_COLOR(239, 239, 244);
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"使用帮助";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setImage:[UIImage imageNamed:@"icon-close2x"] forState:UIControlStateNormal];
    rightBtn.frame = CGRectMake(0, 0, 25, 25);
    [rightBtn addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightBarItem;
}

- (void)goBack {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
