//
//  TemManageViewController.m
//  WearEcg
//
//  Created by dzl on 17/2/14.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "TemManageViewController.h"
#import "ManagementCell.h"
#import "ManagementTwoCell.h"
#import "ManagementThreeCell.h"
#import "TemEquipmentController.h"
#import "TemUseHelpController.h"
#import "AlarmTimeController.h"
#import "AlarmTemperatureController.h"

@interface TemManageViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *_topArray;
    NSArray *_midArray;
    NSArray *_belowArray;
    UITableView *managementTableView;
}

@end

@implementation TemManageViewController

static NSString * const topCellId = @"manage1";
static NSString * const belowCellId = @"manage2";
static NSString * const midCellId = @"manage3";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadTheView];
    
    [self registCell];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [managementTableView reloadData];
}

//注册单元格
- (void)registCell {
    [managementTableView registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementCell class]) bundle:nil] forCellReuseIdentifier:topCellId];
    [managementTableView registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementTwoCell class]) bundle:nil] forCellReuseIdentifier:belowCellId];
    [managementTableView registerNib:[UINib nibWithNibName:NSStringFromClass([ManagementThreeCell class]) bundle:nil] forCellReuseIdentifier:midCellId];
}


- (void)loadTheView {
    
    self.tabBarController.tabBar.hidden = YES;
    
    _topArray = [NSArray arrayWithObjects:@"自动搜索连接设备",@"警报设置", nil];
    _midArray = [NSArray arrayWithObjects:@"显示精度",@"测量单位", nil];
    _belowArray = [NSArray arrayWithObjects:@"查找设备",@"报警温度",@"警报时长",@"设备信息",@"使用帮助", nil];
    
    self.view.backgroundColor = OBTION_COLOR(239, 239, 244);
    
    managementTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44 * (_topArray.count + _belowArray.count + _midArray.count) + 66)];
    managementTableView.delegate = self;
    managementTableView.dataSource = self;
    managementTableView.scrollEnabled = NO;
    [self.view addSubview:managementTableView];
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"设备管理";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"icon-lift arrow"] forState:UIControlStateNormal];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
}

//返回
- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}

//区头高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 44;
    }
    else {
        return 11;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

//区头标题
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
        view.backgroundColor = OBTION_COLOR(239, 239, 244);
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 90, 44)];
        label.text = @"未绑定设备";
        label.font = [UIFont systemFontOfSize:15];
        [view addSubview:label];
        
        UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(20 + label.frame.size.width + 5, 0, 100, 44)];
        lab.text = @"";
        lab.font = [UIFont systemFontOfSize:11];
        [view addSubview:lab];
        
        UIButton *bindingBtn = [[UIButton alloc]initWithFrame:CGRectMake(view.frame.size.width - 95, 0, 80, 44)];
        [bindingBtn setTitle:@"绑定设备" forState:UIControlStateNormal];
        bindingBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [bindingBtn setTitleColor:OBTION_COLOR(0, 122, 255) forState:UIControlStateNormal];
        [bindingBtn addTarget:self action:@selector(bingingEquipment) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:bindingBtn];
        
        return view;
    }
    else {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 11)];
        view.backgroundColor = OBTION_COLOR(239, 239, 244);
        return view;
    }
}

//区个数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

//行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 2;
    }
    else if (section == 1) {
        return 2;
    }
    else {
        return 5;
    }
}

//单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        ManagementCell *cell = [tableView dequeueReusableCellWithIdentifier:topCellId];
        cell.label.text = _topArray[indexPath.row];
        cell.manageSwitch.tag = indexPath.row + 100;
        [cell.manageSwitch addTarget:self action:@selector(swtichAction:) forControlEvents:UIControlEventValueChanged];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 1) {
        ManagementThreeCell *cell = [tableView dequeueReusableCellWithIdentifier:midCellId];
        cell.label.text = _midArray[indexPath.row];
        if (indexPath.row == 0) {
            cell.valueLabel.text = @"0.1°";
        }
        else {
            cell.valueLabel.text = @"°C";
        }
        
        return cell;
    }
    else {
        ManagementTwoCell *cell = [tableView dequeueReusableCellWithIdentifier:belowCellId];
        if (indexPath.row == 1) {
            NSString *highTem;
            if ([[NSUserDefaults standardUserDefaults] valueForKey:@"temOnline"] != nil) {
                highTem = [[NSUserDefaults standardUserDefaults] valueForKey:@"temOnline"];
                cell.memoryLab.text = [NSString stringWithFormat:@">%@°C",highTem];
            }
            
        }
        else if (indexPath.row == 2) {
            if ([[NSUserDefaults standardUserDefaults] valueForKey:@"alarmTime"] != nil) {
                cell.memoryLab.text = [[NSUserDefaults standardUserDefaults] valueForKey:@"alarmTime"];
            }
        }
        cell.label.text = _belowArray[indexPath.row];
        
        
        return cell;
    }
}

//点击单元格
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [managementTableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            
        }
        else if (indexPath.row == 1) {
            AlarmTemperatureController *alarmVC = [[AlarmTemperatureController alloc]init];
            [self.navigationController pushViewController:alarmVC animated:YES];
        }
        else if (indexPath.row == 2) {
            AlarmTimeController *alarmTimeVC = [[AlarmTimeController alloc]init];
            [self.navigationController pushViewController:alarmTimeVC animated:YES];
        }
        else if (indexPath.row == 3) {
            TemEquipmentController *temEquiVC = [[TemEquipmentController alloc]init];
            [self.navigationController pushViewController:temEquiVC animated:YES];
        }
        else {
            TemUseHelpController *temUseHelpVC = [[TemUseHelpController alloc]init];
            [self.navigationController pushViewController:temUseHelpVC animated:YES];
        }
    }
}




- (void)bingingEquipment {
    
}

//switch使用 按钮状态
- (void)swtichAction:(UISwitch *)sender {
    
}

@end
