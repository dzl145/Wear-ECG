//
//  AlarmTimeController.m
//  WearEcg
//
//  Created by dzl on 17/2/20.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "AlarmTimeController.h"
#import "AlarmTimeCell.h"
#import "ConnectStateView.h"

@interface AlarmTimeController ()<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *table;
    NSString *timeStr;
    ConnectStateView *_state;
}
@end

@implementation AlarmTimeController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadingNavigation];
    
    [self registeTable];
}

- (NSMutableArray *)dataArray {
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}

- (void)loadingNavigation {
    self.dataArray = [NSMutableArray arrayWithObjects:@"1分钟",@"5分钟",@"10分钟",@"15分钟",@"20分钟",@"30分钟",@"手动停止", nil];
    
    self.view.backgroundColor = [UIColor colorWithHex:0xf6f6f6];
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"警报时长";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setTitle:[NSString stringWithFormat:@"取消"] forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    leftBtn.frame = CGRectMake(0, 0, 40, 40);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setTitle:[NSString stringWithFormat:@"保存"] forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    rightBtn.frame = CGRectMake(0, 0, 40, 40);
    [rightBtn addTarget:self action:@selector(saveData) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightBarItem;
}

- (void)registeTable {
    table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44 * 7)];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    table.scrollEnabled = NO;
    
    [table registerNib:[UINib nibWithNibName:NSStringFromClass([AlarmTimeCell class]) bundle:nil] forCellReuseIdentifier:@"alarm"];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 7;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    AlarmTimeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"alarm"];
    cell.alarmLabel.text = [self.dataArray objectAtIndex:indexPath.row];
    cell.chooseImg.image = [UIImage imageNamed:@""];
    cell.backgroundColor = [UIColor colorWithHex:0xf6f6f6];
//    cell.selectedBackgroundView = [[UIView alloc] initWithFrame:cell.frame];
//    cell.selectedBackgroundView.backgroundColor = [UIColor colorWithHex:0xffffff];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [table reloadData];
    AlarmTimeCell *cell = [table cellForRowAtIndexPath:indexPath];
    cell.chooseImg.image = [UIImage imageNamed:@"TICK"];
    
    cell.selectedBackgroundView = [[UIView alloc] initWithFrame:cell.frame];
    cell.selectedBackgroundView.backgroundColor = [UIColor colorWithHex:0xffffff];
    
    timeStr = [self.dataArray objectAtIndex:indexPath.row];
}


- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)saveData {
    if (timeStr != nil) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setValue:timeStr forKey:@"alarmTime"];
        [defaults synchronize];
        [self loadingConnectWithTitle:@"保存成功"];
    }
    else {
        NSLog(@"meiyou");
    }
}

- (void)loadingConnectWithTitle:(NSString *)title {
    _state = [[ConnectStateView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [_state initWithTitle:title];
    UIView * keywindow = [[UIApplication sharedApplication] keyWindow];
    [keywindow addSubview:_state];
    
    [self performSelector:@selector(delayMethod) withObject:nil afterDelay:1.0];
}

//延迟消失
- (void)delayMethod {
    [_state removeFromSuperview];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
