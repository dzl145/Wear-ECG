//
//  AlarmTemperatureController.h
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlarmTemperatureController : UIViewController

//遮罩
@property (strong, nonatomic) UIView *mastView;

//数据源
@property (strong, nonatomic) NSMutableArray *integerDataArr;
@property (nonatomic, retain) NSMutableArray *decimalDataArr;
//选择框
@property (strong, nonatomic) UIView *selectView;

@property (nonatomic, assign) BOOL isHighDegree;

@end
