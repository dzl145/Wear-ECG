//
//  AlarmTemperatureController.m
//  WearEcg
//
//  Created by dzl on 17/2/21.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "AlarmTemperatureController.h"
#import "ConnectStateView.h"

@interface AlarmTemperatureController ()<UIPickerViewDelegate,UIPickerViewDataSource>
{
    NSUserDefaults *defaults;
    NSString *highTem;
    NSString *lowTem;
    UIView *temView;
    ConnectStateView *_state;
}
@end

@implementation AlarmTemperatureController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    defaults = [NSUserDefaults standardUserDefaults];
    self.isHighDegree = YES;
    [defaults setBool:self.isHighDegree forKey:@"HighDegree"];
    [defaults synchronize];
    
    [self loadingNavigation];
    
    [self creatPikerView];
    
    [self creatDegreeLimit];
}

- (NSMutableArray *)integerDataArr {
    if (_integerDataArr == nil) {
        _integerDataArr = [[NSMutableArray alloc]init];
    }
    return _integerDataArr;
}

- (NSMutableArray *)decimalDataArr {
    if (_decimalDataArr == nil) {
        _decimalDataArr = [[NSMutableArray alloc]init];
    }
    return _decimalDataArr;
}

- (void)loadingNavigation {
    
    self.integerDataArr = [NSMutableArray arrayWithObjects:@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41", nil];
    self.decimalDataArr = [NSMutableArray arrayWithObjects:@"9",@"8",@"7",@"6",@"5",@"4",@"3",@"2",@"1",@"0", nil];
    
    if ([defaults valueForKey:@"temOnline"] != nil) {
        highTem = [defaults valueForKey:@"temOnline"];
    }
    if ([defaults valueForKey:@"temOffline"] != nil) {
        lowTem = [defaults valueForKey:@"temOffline"];
    }
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.bounds = CGRectMake(0, 0, 200, 44);
    titleLabel.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
    titleLabel.textColor = OBTION_COLOR(255, 255, 255);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"设备管理";
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setTitle:[NSString stringWithFormat:@"取消"] forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    leftBtn.frame = CGRectMake(0, 0, 40, 40);
    [leftBtn addTarget:self action:@selector(popTheLastView) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBarItem;
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setTitle:[NSString stringWithFormat:@"保存"] forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    rightBtn.frame = CGRectMake(0, 0, 40, 40);
    [rightBtn addTarget:self action:@selector(saveData) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = rightBarItem;
}

- (void)creatPikerView {
    
    
    UIPickerView *picker = [[UIPickerView alloc]init];
    picker.frame = CGRectMake(0, 0, SCREEN_WIDTH, 220);
    [picker setBackgroundColor:[UIColor whiteColor]];
    picker.dataSource = self;
    picker.delegate = self;
    
    [picker selectRow:2 inComponent:0 animated:NO];
    [picker selectRow:4 inComponent:1 animated:NO];
    
    [self.view addSubview:picker];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 220, SCREEN_WIDTH, 1)];
    view.backgroundColor = OBTION_COLOR(201, 201, 201);
    [self.view addSubview:view];
}

- (void)creatDegreeLimit {
    if (temView.subviews) {
        [temView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    
    temView = [[UIView alloc]initWithFrame:CGRectMake(0, 221, SCREEN_WIDTH, 88)];
    
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
    UILabel *highFever = [[UILabel alloc]initWithFrame:CGRectMake(15, 2, 150, 40)];
    highFever.text = @"高烧体温度数";
    [view1 addSubview:highFever];
    
    UILabel *highDegree = [[UILabel alloc]initWithFrame:CGRectMake(view1.frame.size.width - 15 - 150, 2, 150, 40)];
    if (highTem != nil) {
        highDegree.text = [NSString stringWithFormat:@">%@°C",highTem];
    }
    
    highDegree.textAlignment = NSTextAlignmentRight;
    [view1 addSubview:highDegree];
    
    UIButton *highBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, view1.frame.size.width, view1.frame.size.height)];
    highBtn.tag = 20;
    [highBtn addTarget:self action:@selector(highAndLowDegreeLimit:) forControlEvents:UIControlEventTouchUpInside];
    [view1 addSubview:highBtn];
    [temView addSubview:view1];
    
    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 44, SCREEN_WIDTH, 44)];
    UILabel *lowFever = [[UILabel alloc]initWithFrame:CGRectMake(15, 2, 150, 40)];
    lowFever.text = @"低烧体温度数";
    [view2 addSubview:lowFever];
    
    UILabel *lowDegree = [[UILabel alloc]initWithFrame:CGRectMake(view2.frame.size.width - 15 - 150, 2, 150, 40)];
    if (lowTem != nil) {
        lowDegree.text = [NSString stringWithFormat:@"<%@°C",lowTem];
    }
    
    lowDegree.textAlignment = NSTextAlignmentRight;
    [view2 addSubview:lowDegree];
    
    UIButton *lowBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, view2.frame.size.width, view2.frame.size.height)];
    lowBtn.tag = 21;
    [lowBtn addTarget:self action:@selector(highAndLowDegreeLimit:) forControlEvents:UIControlEventTouchUpInside];
    [view2 addSubview:lowBtn];
    [temView addSubview:view2];
    
    [self.view addSubview:temView];
    
}

#pragma mark -- PickerViewDelete
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 3;
}

//每列的行数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSInteger result = 0;
    switch (component) {
        case 0:
            result = self.integerDataArr.count;//根据数组的元素个数返回几行数据
            break;
        case 1:
            result = self.decimalDataArr.count;
            break;
        case 2:
            result = 1;
            break;
            
        default:
            break;
    }
    
    return result;
}


//数据赋值
- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component __TVOS_PROHIBITED
{
    NSString * title = nil;
    switch (component) {
        case 0:
            title = self.integerDataArr[row];
            break;
        case 1:
            title = self.decimalDataArr[row];
            break;
        case 2:
            title = @"°C";
            break;
        default:
            break;
    }
    
    return title;
}

//返回行高
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component __TVOS_PROHIBITED
{
    return 44;
}

//选中pickerView中component列row行时触发的事件 联动实现
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *integer;
    NSString *decimal;
    if (component == 0) {
        integer = [self.integerDataArr objectAtIndex:row];
        [defaults setValue:integer forKey:@"high"];
        [defaults synchronize];
    }
    else if (component == 1) {
        decimal = [self.decimalDataArr objectAtIndex:row];
        [defaults setValue:decimal forKey:@"low"];
        [defaults synchronize];
    }
    
    NSString *temStr = [NSString stringWithFormat:@"%@.%@",[defaults valueForKey:@"high"],[defaults valueForKey:@"low"]];
    if ([defaults valueForKey:@"high"] && [defaults valueForKey:@"low"]) {
        if ([defaults boolForKey:@"HighDegree"] == YES) {
            highTem = [NSString stringWithFormat:@"%@",temStr];
            NSLog(@"highTem == %@",highTem);
        }
        else {
            lowTem = [NSString stringWithFormat:@"%@",temStr];
            NSLog(@"lowTem == %@",lowTem);
        }
    }
    
    [self creatDegreeLimit];
}


- (void)popTheLastView {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)saveData {
    [defaults setValue:highTem forKey:@"temOnline"];
    [defaults setValue:lowTem forKey:@"temOffline"];
    [defaults synchronize];
    [self loadingConnectWithTitle:@"保存成功"];
}

- (void)highAndLowDegreeLimit:(UIButton *)sender {
    if (sender.tag == 20) {
        self.isHighDegree = YES;
        
    }
    else {
        self.isHighDegree = NO;
    }
    [defaults setBool:self.isHighDegree forKey:@"HighDegree"];
    [defaults synchronize];
}

- (void)reomveSelectView {
    if (self.mastView != nil) {
        [self.mastView removeFromSuperview];
        self.mastView = nil;
    }
    if (self.selectView != nil) {
        [self.selectView removeFromSuperview];
        self.selectView = nil;
    }
    
}

- (void)loadingConnectWithTitle:(NSString *)title {
    _state = [[ConnectStateView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [_state initWithTitle:title];
    UIView * keywindow = [[UIApplication sharedApplication] keyWindow];
    [keywindow addSubview:_state];
    
    [self performSelector:@selector(delayMethod) withObject:nil afterDelay:1.0];
}

//延迟消失
- (void)delayMethod {
    [_state removeFromSuperview];
    [self.navigationController popViewControllerAnimated:YES];
}


@end
