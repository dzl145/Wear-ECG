//
//  BodyTemperatureController.h
//  WearEcg
//
//  Created by apple on 16/12/12.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ViewControllerBase.h"
#import "BodyFigure.h"
#import "MLHRVView.h"

@interface BodyTemperatureController : ViewControllerBase

@property (nonatomic, strong) BodyFigure *bodyFigure;

@property (weak, nonatomic) IBOutlet UIImageView *temperatureImage;

@property (weak, nonatomic) IBOutlet UILabel *meaTemperatureLabel;

@property (weak, nonatomic) IBOutlet UILabel *meaLengthLabel;

@property (weak, nonatomic) IBOutlet UILabel *meaResultLabel;

@property (weak, nonatomic) IBOutlet UIImageView *signalImage;

@property (weak, nonatomic) IBOutlet UIImageView *batteryImage;

@property (weak, nonatomic) IBOutlet UILabel *connectionLabel;

@property (weak, nonatomic) IBOutlet UIButton *alarmButton;

@property (weak, nonatomic) IBOutlet UIButton *doctorButton;


@property (weak, nonatomic) IBOutlet UIButton *startBtn;


@property (weak, nonatomic) IBOutlet UILabel *equipmentLabel;

@property (weak, nonatomic) IBOutlet UILabel *historyLabel;


@property (weak, nonatomic) IBOutlet UIView *lineChatView;

@property (nonatomic, retain) NSMutableArray *xValuesArray;

@property (nonatomic, retain) NSMutableArray *bodyFigureValue;

@property (nonatomic, strong)NSMutableArray *rrNews;

@property (nonatomic, weak)MLHRVView *hrvView;

@property (nonatomic, strong)NSTimer *timer;

@property (nonatomic, assign) BOOL isConnect;

@end
