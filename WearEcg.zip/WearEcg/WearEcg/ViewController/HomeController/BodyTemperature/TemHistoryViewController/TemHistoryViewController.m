//
//  TemHistoryViewController.m
//  WearEcg
//
//  Created by dzl on 17/2/14.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import "TemHistoryViewController.h"
#import "TemCalendar.h"

@interface TemHistoryViewController ()<TemCalendarDelegate>
{
    UIView *_monthView;
}

@end

@implementation TemHistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self creatMonthViewAndTableView];
    
    [self loadingCalendar];
    
    [self addGestures];
}

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden = YES;
}

//创建表和monthview
- (void)creatMonthViewAndTableView{
    
    self.tabBarController.tabBar.hidden = YES;
    self.belowNavigationView.backgroundColor = OBTION_COLOR(99, 182, 181);
    self.navigationView.backgroundColor = OBTION_COLOR(108, 197, 199);
    
    [self.segmentControl setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} forState:UIControlStateNormal];
    [self.segmentControl setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} forState:UIControlStateSelected];
    
    _monthView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, (SCREEN_WIDTH - 10) / 7 * 6 + 75)];
    [self.mainScrollView addSubview:_monthView];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, _monthView.frame.size.height, SCREEN_WIDTH, 1)];
    view.backgroundColor = OBTION_COLOR(108, 197, 199);
    [self.mainScrollView addSubview:view];
    
//    [self addLabelView];
    
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(0, _monthView.frame.size.height + 45, SCREEN_WIDTH, 1)];
    view1.backgroundColor = OBTION_COLOR(108, 197, 199);
    [self.mainScrollView addSubview:view1];
}

//双击手势
- (void)addGestures {
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doubleTap)];
    [doubleTap setNumberOfTapsRequired:2];
    [self.navigationView addGestureRecognizer:doubleTap];
}

//回到最上方方法
- (void)doubleTap {
    [self.mainScrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

//加载日历
- (void)loadingCalendar {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    TemCalendar *calendar = [[TemCalendar alloc] initWithCurrentDate:[NSDate date]];
    calendar.delegate = self;
    CGRect frame = calendar.frame;
    frame.origin.y = 0;
    calendar.frame = frame;
    [_monthView addSubview:calendar];
}

//点击选择的日期
- (void)selectedDate:(NSDate *)selectedDate {
    
}

//返回按钮
- (IBAction)backViewController:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

//清除记录
- (IBAction)cleanRecord:(UIButton *)sender {
    
}

//点击连续或单次记录
- (IBAction)clickContinuousAndSingleRecord:(UISegmentedControl *)sender {
    if (_monthView.subviews) {
        [_monthView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    if (sender.selectedSegmentIndex == 0) {
        
    }
    else {
        
    }
    [self loadingCalendar];
}

@end
