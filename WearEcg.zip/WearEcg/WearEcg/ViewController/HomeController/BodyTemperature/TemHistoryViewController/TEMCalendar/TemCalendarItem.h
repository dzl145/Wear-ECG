//
//  TemCalendarItem.h
//  WearEcg
//
//  Created by dzl on 17/2/14.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

#define DeviceWidth [UIScreen mainScreen].bounds.size.width

@protocol TemCalendarItemDelegate;

@interface TemCalendarItem : UIView

@property (strong, nonatomic) NSDate *date;
@property (weak, nonatomic) id<TemCalendarItemDelegate> delegate;
@property (nonatomic, assign)BOOL isHave;
@property (nonatomic, retain)UICollectionViewCell *beforeCell;
@property (nonatomic, retain)UICollectionViewCell *afterCell;

- (NSDate *)nextMonthDate;
- (NSDate *)previousMonthDate;

@end


@protocol TemCalendarItemDelegate <NSObject>

- (void)calendarItem:(TemCalendarItem *)item didSelectedDate:(NSDate *)date;

@end
