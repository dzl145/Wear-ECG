//
//  TemCalendar.h
//  WearEcg
//
//  Created by dzl on 17/2/14.
//  Copyright © 2017年 HeartDoc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TemCalendarDelegate <NSObject>

- (void)selectedDate:(NSDate *)selectedDate;

@end

@interface TemCalendar : UIView

@property (weak, nonatomic) id<TemCalendarDelegate> delegate;
- (instancetype)initWithCurrentDate:(NSDate *)date;

@end
