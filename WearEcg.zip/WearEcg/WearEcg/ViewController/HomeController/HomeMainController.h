//
//  HomeMainController.h
//  WearEcg
//
//  Created by HeartDoc on 16/9/28.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "ViewControllerBase.h"
#import "HomeMenuView.h"

@interface HomeMainController : ViewControllerBase

@property (weak, nonatomic) IBOutlet UIScrollView *mainScrollView;

//滚动高度
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentViewH;

//标题滚动层
@property (weak, nonatomic) IBOutlet UIScrollView *titleScrollView;

//视图内容 滚动层
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

//scrollView高度
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scrollViewHeight;


@property (nonatomic, assign)NSInteger btnTag;

@end
