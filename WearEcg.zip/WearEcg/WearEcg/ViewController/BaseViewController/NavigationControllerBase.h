//
//  RootNavigationController.h
//  StudyTour
//
//  Created by owen on 16/09/27.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationControllerBase : UINavigationController

@end
