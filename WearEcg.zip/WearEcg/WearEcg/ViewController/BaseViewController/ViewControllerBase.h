//
//  ViewControllerBase.h
//  WearEcg
//
//  Created by owen on 16/5/10.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerBase : UIViewController

//设置导航标题
-(void)setNavigationItemTitle : (NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size;

//设置左边按钮 文本
-(void)setNavigationItemleftBar : (NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size;

//设置右边按钮 文本
-(void)setNavigationItemlRihtBar : (NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size;

//设置左边按钮 图片
-(void)setNavigationItemLeftFroImage : (NSString *)image title:(NSString *)title;

//设置左边按钮 图片
-(void)setNavigationItemLeftFroImage : (NSString *)image title:(NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size;

//设置左边按钮 图片
-(void)setNavigationItemRightFroImage : (NSString *)image title:(NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size;

//提示样式
//- (void)showTips:(NSString *)str;
//
////显示等待
//- (void)showHud : (NSString *)tipStr;
//
////显示等待 等待time后自动消失
//- (void)showHud : (NSString *)tipStr showtime : (CGFloat)time;
//
////隐藏等待
//- (void)hideHud;


@end
