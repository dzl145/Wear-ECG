//
//  ViewControllerBase.m
//  WearEcg
//
//  Created by owen on 16/5/10.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "ViewControllerBase.h"
/**
 *  是否正在手势返回中的标示状态
 */
static BOOL _isPoping;

@implementation ViewControllerBase

- (void)viewDidLoad {
    [super viewDidLoad];
 
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

//响应导航侧滑
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    if (!_isPoping) {
        _isPoping = YES;
        return YES;
    }
    return NO;
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //开启ios右滑返回
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    }
}
- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    //在didAppear时置为NO
    _isPoping = NO;
    
}

-(void)setNavigationItemTitle : (NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size
{
    if (title == nil || [title isEqualToString:@""]) {
        return;
    }
    self.navigationItem.title = title;
    if (color == nil ){
        return;
    }
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:size],
                                                                          NSForegroundColorAttributeName:color}];
}

-(void)setNavigationItemleftBar : (NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size
{
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    if (title == nil || [title isEqualToString:@""]) {
        [leftBtn setTitle:@"" forState:UIControlStateNormal];
        return;
    }
    else{
        leftBtn.titleLabel.numberOfLines = 0;
        [leftBtn setTitle:title forState:UIControlStateNormal];
        leftBtn.titleLabel.font = [UIFont systemFontOfSize :size];
        [leftBtn sizeToFit];
        if (color != nil) {
            [leftBtn setTitleColor:color forState:UIControlStateNormal];
        }
    }
    [leftBtn addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *itemback = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = itemback;
}

-(void)setNavigationItemlRihtBar : (NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size
{
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    if (title == nil || [title isEqualToString:@""]) {
        [rightBtn setTitle:@"" forState:UIControlStateNormal];
        return;
    }
    else{
        rightBtn.titleLabel.numberOfLines = 0;
        [rightBtn setTitle:title forState:UIControlStateNormal];
        rightBtn.titleLabel.font = [UIFont systemFontOfSize:size];
        [rightBtn sizeToFit];
        if (color != nil) {
            [rightBtn setTitleColor:color forState:UIControlStateNormal];
        }
    }
    [rightBtn addTarget:self action:@selector(right:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *itemback = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    self.navigationItem.rightBarButtonItem = itemback;
}

-(void)setNavigationItemLeftFroImage : (NSString *)image title:(NSString *)title {
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [btn sizeToFit];

    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
    item.title = title;
    self.navigationItem.leftBarButtonItem = item;
}

-(void)setNavigationItemLeftFroImage : (NSString *)image title:(NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size
{
    UIBarButtonItem * item = [self createUIBarButtonItemImg:image title:title ColorHex:color fontsize:size selector:@selector(back:)];
    self.navigationItem.leftBarButtonItem = item;
}

-(void)setNavigationItemRightFroImage : (NSString *)image title:(NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size{
    UIBarButtonItem * item = [self createUIBarButtonItemImg:image title:title ColorHex:color fontsize:size selector:@selector(right:)];
    item.action = @selector(right:);
    self.navigationItem.rightBarButtonItem = item;
}

-(UIBarButtonItem *)createUIBarButtonItemImg : (NSString *)image title:(NSString *)title ColorHex : (UIColor *)color fontsize : (CGFloat)size selector : (SEL)selector{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:size];
    if (color != nil) {
        [btn setTitleColor:color forState:UIControlStateNormal];
    }
    if (title != nil) {
        btn.titleLabel.numberOfLines = 0;
        [btn setTitle:title forState:UIControlStateNormal];
        [btn sizeToFit];
    }
    [btn addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
    return item;
}

-(void)right : (UIBarButtonItem *)itemBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)back : (UIBarButtonItem *)itemBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}

//显示提示
//- (void)showTips:(NSString *)str {
//    [Loading showTips:str];
//}
////显示等待
//- (void)showHud : (NSString *)tipStr {
//    [Loading showHud : tipStr];
//}
//
//- (void)showHud : (NSString *)tipStr showtime : (CGFloat)time{
//    [Loading showHud:tipStr showtime:time];
//}
////隐藏等待
//- (void)hideHud{
//    [Loading hideHud];
//}

@end
