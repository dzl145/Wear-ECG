//
//  RootNavigationController.m
//  StudyTour
//
//  Created by owen on 16/09/27.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "NavigationControllerBase.h"


@implementation NavigationControllerBase

- (void)viewDidLoad {
    [super viewDidLoad];

//    self.view.backgroundColor = [UIColor colorWithHex:appThemeColor];
    
//    [self.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
//    self.navigationBar.tintColor = [UIColor whiteColor];
//    self.navigationBar.barTintColor = [UIColor themeColor];
    
    //设置导航不通明
    self.navigationBar.translucent = NO;
    //设置导航 去除黑色边线
//    [self.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
//    self.navigationBar.shadowImage = [[UIImage alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
