//
//  RootTabBarController.m
//  StudyTour
//
//  Created by owen on 16/09/27.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "TabBarControllerBase.h"

@implementation TabBarControllerBase

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
