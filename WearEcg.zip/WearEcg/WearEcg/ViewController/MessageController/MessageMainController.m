//
//  MessageMainController.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/27.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "MessageMainController.h"

@interface MessageMainController ()

@end

@implementation MessageMainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}

@end
