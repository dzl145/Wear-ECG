//
//  StoreMainController.m
//  WearEcg
//
//  Created by HeartDoc on 16/9/28.
//  Copyright © 2016年 HeartDoc. All rights reserved.
//

#import "StoreMainController.h"

@interface StoreMainController ()

@end

@implementation StoreMainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
