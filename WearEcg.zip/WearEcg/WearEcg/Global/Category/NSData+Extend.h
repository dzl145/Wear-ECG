//
//  NSData+Extend.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/27.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (Extend)

//将NSData转换成十六进制的字符串:
- (NSString *)convertDataToHexStr;


@end
