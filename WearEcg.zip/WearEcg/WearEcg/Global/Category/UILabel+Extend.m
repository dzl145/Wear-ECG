//
//  UILabel+Extend.m
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/25.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "UILabel+Extend.h"

@implementation UILabel (Extend)


-(void)SetLineSpacing : (CGFloat)space
{
    NSString * labelText = [NSString stringWithString:self.text];
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setAlignment:NSTextAlignmentCenter];//居中
    [paragraphStyle setLineSpacing:space];//调整行间距
    
    
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    self.attributedText = attributedString;
//    [self sizeToFit];
}



@end
