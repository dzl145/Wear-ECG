//
//  UIImage+Expand.h
//  WearEcg
//
//  Created by lxl on 16/4/7.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Expand)
/**
 *  @author lxl, 16-04-07 16:04:55
 *
 *  拉伸图片专用
 */
- (UIImage *)stretchImage;



/**
 *  压缩图片指定大小
 */
- (UIImage *)scaleToSize : (CGSize)size;

@end
