//
//  NSDate+Format.m
//  WearEcg
//
//  Created by HeartDoc on 16/5/12.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "NSDate+Format.h"

@implementation NSDate (Format)

+ (NSDate *)convertStringToDate:(NSString *)textDate {
    if (textDate == nil || [textDate isEqualToString: @""]) {
        return nil;
    }
    if ([textDate containsString:@"年"]) {
        textDate = [textDate stringByReplacingOccurrencesOfString:@"年"withString:@""];
        textDate = [textDate stringByReplacingOccurrencesOfString:@"月"withString:@""];
        textDate = [textDate stringByReplacingOccurrencesOfString:@"日"withString:@""];
    }
    textDate = [textDate stringByReplacingOccurrencesOfString:@"/" withString:@""];
    textDate = [textDate stringByReplacingOccurrencesOfString:@" " withString:@""];
    textDate = [textDate stringByReplacingOccurrencesOfString:@"-" withString:@""];
    textDate = [textDate stringByReplacingOccurrencesOfString:@":" withString:@""];
    NSDateFormatter * formatter=[[NSDateFormatter alloc]init];
    [formatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
    [formatter setDateFormat:@"yyyyMMddHHmmss"];
    if (textDate.length == 6) {
        //yyyyMM
        textDate = [NSString stringWithFormat:@"%@01000000",textDate];
        NSDate * date = [formatter dateFromString:textDate];
        return date;
    }
    else if (textDate.length == 8) {
        //yyyyMMdd
        textDate = [NSString stringWithFormat:@"%@000000",textDate];
        NSDate * date = [formatter dateFromString:textDate];
        return date;
    }
    else if(textDate.length == 14){
        //yyyyMMddHHmmss
        NSDate * date = [formatter dateFromString:textDate];
        return date;
    }
    return nil;
}

+ (NSString *)convertDateToString:(NSDate *)date Symbol:(NSString *)character {
    if (date == nil || character == nil || [character isEqualToString: @""]) {
        return nil;
    }
    NSString * formatStr = [NSString stringWithFormat:@"yyyy%@MM%@dd",character,character];
    return [NSDate convertDateToString:date Format:formatStr];
}

+ (NSString *)convertDateToString:(NSDate *)date Format:(NSString *)formatStr {
    if (formatStr == nil || [formatStr isEqualToString:@""]) {
        return nil;
    }
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:formatStr];
    //NSDate转NSString
    NSString * dateString = [dateFormatter stringFromDate:date];
    return dateString;
}

- (NSString *)convertDateToStringFormat:(NSString *)formatStr {
    if (formatStr == nil || [formatStr isEqualToString:@""]) {
        return nil;
    }
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:formatStr];
    //NSDate转NSString
    NSString * dateString = [dateFormatter stringFromDate:self];
    return dateString;
}

+ (NSInteger)getDaysOfYear:(NSInteger)year Month:(NSInteger)month {
    NSInteger days = 0;
    NSArray * arr = [NSArray arrayWithObjects:@"31", @"28", @"31", @"30", @"31", @"30", @"31", @"31", @"30", @"31", @"30", @"31", nil];
    
    if (((year%4 == 0 && year%100 != 0) || year%400 == 0) && month == 2)
    {
        days = 29; // 闰年2月29天
    }
    else{
        @try {
            days = [[arr objectAtIndex:(month -1)] integerValue];
        }
        @catch (NSException *exception) {
            NSError *err = [[exception userInfo] valueForKey:@"error"];
            NSLog(@"error: %@, %s %d", [err description], __FILE__, __LINE__);
            return 0;
        }
        @finally {
            
        }
    }
    return days;
}

- (NSString *)convertTimeStrFromOtherDate:(NSDate *)otherDate {
    double interval = 0;
    //大于
    if ([self compare:otherDate] == NSOrderedDescending) {
        interval = [self timeIntervalSinceDate:otherDate];
    }
    else{
        interval = [otherDate timeIntervalSinceDate:self];
    }
    NSString *measurement = [NSString stringWithFormat:@"%02i:%02i:%02i",(unsigned int)interval/60/60,(unsigned int)interval/60 >= 59 ?(unsigned int)interval/60%60 : (unsigned int)interval/60 ,(unsigned int)interval%60];
    return measurement;
}

- (NSInteger)intervalForOtherDate:(NSDate *)otherDate {
    NSInteger end = (long)[otherDate timeIntervalSince1970];
    NSInteger start = (long)[self timeIntervalSince1970];
    return labs(end - start);
}


- (NSString *)intervalFromLastDate:(NSString *)dateString1 toTheDate:(NSString *)dateString2 {
    NSArray *timeArray1 = [dateString1 componentsSeparatedByString:@"."];
    dateString1 = [timeArray1 objectAtIndex:0];
    
    NSArray *timeArray2 = [dateString2 componentsSeparatedByString:@"."];
    dateString2 = [timeArray2 objectAtIndex:0];
    
    NSLog(@"%@.....%@",dateString1,dateString2);
    NSDateFormatter *date = [[NSDateFormatter alloc] init];
    [date setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSDate *d1 = [date dateFromString:dateString1];
    
    NSTimeInterval late1 = [d1 timeIntervalSince1970]*1;
    
    NSDate *d2 = [date dateFromString:dateString2];
    
    NSTimeInterval late2 = [d2 timeIntervalSince1970]*1;
    
    NSTimeInterval cha = late2-late1;
    NSString *timeString = @"";
    NSString *house = @"";
    NSString *min = @"";
    NSString *sen = @"";
    
    sen = [NSString stringWithFormat:@"%d", (int)cha%60];
    //        min = [min substringToIndex:min.length-7];
    //    秒
    sen = [NSString stringWithFormat:@"%@", sen];
    
    
    min = [NSString stringWithFormat:@"%d", (int)cha/60%60];
    //        min = [min substringToIndex:min.length-7];
    //    分
    min=[NSString stringWithFormat:@"%@", min];
    
    //    小时
    house = [NSString stringWithFormat:@"%d", (int)cha/3600];
    //        house = [house substringToIndex:house.length-7];
    house = [NSString stringWithFormat:@"%@", house];
    
    
    timeString = [NSString stringWithFormat:@"%@:%@:%@",house,min,sen];
    
    return timeString;
}


@end
