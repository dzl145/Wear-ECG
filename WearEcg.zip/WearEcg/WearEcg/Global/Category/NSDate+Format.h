//
//  NSDate+Format.h
//  WearEcg
//
//  Created by HeartDoc on 16/5/12.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Format)


/*
 *转换 字符串日期 -> NSDate类型日期
 * textStr  文本类型的带有文字日期
 * retrun NSDate  yyyy MM dd
 */
+(NSDate *)convertStringToDate : (NSString *)textDate;


/*
 *转换 NSDate类型日期 -> NSString*类型
 * date NSDate类型日期
 * character 要转成带有字符的日期 字符串
 * retrun NSString yyyy MM dd
 */
+(NSString *)convertDateToString : (NSDate *)date Symbol : (NSString *)character;


/*
 * 指定格式转换 NSDate->NSString
 * formatStr 指定格式 yyyy-MM-dd HH:mm:ss
 * retrun NSString 指定的格式
 */
+(NSString *)convertDateToString : (NSDate *)date Format: (NSString *)formatStr;

/*
 * 指定格式转换 NSDate->NSString
 * formatStr 指定格式 yyyy-MM-dd HH:mm:ss
 * retrun NSString 指定的格式
 */
-(NSString *)convertDateToStringFormat: (NSString *)formatStr;

/*
 * 获取每月的天数
 * year 年
 * month 月
 * retrun 天数
 */
+(NSInteger)getDaysOfYear:(NSInteger) year Month : (NSInteger) month;

/*
 * 两个日期 的差值转换成 标准时间格式
 * otherDate : 比较的日期
 */
-(NSString *)convertTimeStrFromOtherDate : (NSDate *)otherDate;

/*
 * 两个日期 的差值（精确到秒）
 * otherDate : 比较的日期
 */
-(NSInteger)intervalForOtherDate : (NSDate *)otherDate;

@end
