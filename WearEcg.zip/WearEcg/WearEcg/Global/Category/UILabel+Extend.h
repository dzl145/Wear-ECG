//
//  UILabel+Extend.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/25.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Extend)

//设置行间距
-(void)SetLineSpacing : (CGFloat)space;

@end
