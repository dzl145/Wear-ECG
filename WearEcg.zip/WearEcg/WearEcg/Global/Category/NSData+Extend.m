//
//  NSData+Extend.m
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/27.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "NSData+Extend.h"

@implementation NSData (Extend)

//将NSData转换成十六进制的字符串则可使用如下方式:
- (NSString *)convertDataToHexStr {
    if (!self || [self length] == 0) {
        return @"";
    }
    NSMutableString *string = [[NSMutableString alloc] initWithCapacity:[self length]];
    
    [self enumerateByteRangesUsingBlock:^(const void *bytes, NSRange byteRange, BOOL *stop) {
        unsigned char *dataBytes = (unsigned char*)bytes;
        for (NSInteger i = 0; i < byteRange.length; i++) {
            NSString *hexStr = [NSString stringWithFormat:@"%x", (dataBytes[i]) & 0xff];
            if ([hexStr length] == 2) {
                [string appendString:hexStr];
            } else {
                [string appendFormat:@"0%@", hexStr];
            }
        }
    }];
    
    return string;
}

/**
 *  将二进制数据转换成十六进制字符串
 *  @param data 二进制数据
 *  @return 十六进制字符串
 */
+ (NSString *)data2Hex:(NSData *)data {
    if (!data) {
        return nil;
    }
    Byte *bytes = (Byte *)[data bytes];
    NSMutableString *str = [NSMutableString stringWithCapacity:data.length * 2];
    for (int i=0; i < data.length; i++){
        [str appendFormat:@"%0x", bytes[i]];
    }
    return str;
}


@end
