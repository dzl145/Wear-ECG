//
//  NSString+Extend.h
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/14.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString (Extend)

//MD5加密
- (NSString *)MD5String;

//获取字体的高度
- (float) heightWithFont: (UIFont *) font withinWidth: (float) width;

//获取字体的宽度
- (float) widthWithFont: (UIFont *) font;

//去除前后空格
-(NSString *)Trim;

//将十六进制字符串转换成NSData的代码;
- (NSData *)convertHexStrToData;

//是否只含有16进制数据
- (BOOL)isHexFormatString;

//将16进制 装换成 2进制字符串
-(NSString *)convertHexToBinary;

//将2进制 装换成 16进制字符串
- (NSString *)convertBinaryToHex;

//十六进制转十进制 字符串
-(NSString *)convertHexToDecimal;

//将十进制转化为十六进制
- (NSString *)convertDecimalToHex;

//十进制转二进制  decimal10:进制字符串
- (NSString *)convertDecimalToBinary;

//  二进制转十进制
- (NSString *)convertBinaryToDecimal;






@end
