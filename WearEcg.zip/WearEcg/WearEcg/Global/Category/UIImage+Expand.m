//
//  UIImage+Expand.m
//  WearEcg
//
//  Created by lxl on 16/4/7.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "UIImage+Expand.h"

@implementation UIImage (Expand)
- (UIImage *)stretchImage{
    UIEdgeInsets edge = UIEdgeInsetsMake(0, 15, 0,15);
    //UIImageResizingModeStretch：拉伸模式，通过拉伸UIEdgeInsets指定的矩形区域来填充图片
   //UIImageResizingModeTile：平铺模式，通过重复显示UIEdgeInsets指定的矩形区域来填充图
     return [self resizableImageWithCapInsets:edge resizingMode:UIImageResizingModeStretch];
}



- (UIImage *)scaleToSize : (CGSize)size{
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(size);
    // 绘制改变大小的图片
    [self drawInRect:CGRectMake(0,0, size.width, size.height)];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage =UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    //返回新的改变大小后的图片
    return scaledImage;
}
@end
