//
//  NSString+Extend.m
//  EcgWear
//
//  Created by 宋敬佩 on 16/6/14.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "NSString+Extend.h"
#import <CommonCrypto/CommonDigest.h>

@implementation NSString (Extend)

- (NSString *)MD5String{
    
    const char *cStr = [self UTF8String];
    unsigned char digest[32];
    CC_MD5( cStr, (CC_LONG)strlen(cStr), digest ); // This is the md5 call
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD2_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_MD2_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];

    return  output;
}

- (float) heightWithFont: (UIFont *) font withinWidth: (float) width
{
    CGRect textRect = [self boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
                                         options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                                      attributes:@{NSFontAttributeName:font}
                                         context:nil];
    
    return textRect.size.height;
}

- (float) widthWithFont: (UIFont *) font
{
    CGRect textRect = [self boundingRectWithSize:CGSizeMake(MAXFLOAT, font.pointSize)
                                         options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                      attributes:@{NSFontAttributeName:font}
                                         context:nil];
    
    return textRect.size.width;
}


-(NSString *)Trim
{
    NSString * newStr = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    return newStr;
}


//将十六进制字符串转换成NSData:
- (NSData *)convertHexStrToData {
    if (!self || [self length] == 0) {
        return nil;
    }
    
    NSMutableData *hexData = [[NSMutableData alloc] init];
    NSRange range;
    if ([self length] % 2 == 0) {
        range = NSMakeRange(0, 2);
    }
    else {
        range = NSMakeRange(0, 1);
    }
    for (NSInteger i = range.location; i < [self length]; i += 2) {
        unsigned int anInt;
        NSString *hexCharStr = [self substringWithRange:range];
        NSScanner *scanner = [[NSScanner alloc] initWithString:hexCharStr];
        
        [scanner scanHexInt:&anInt];
        NSData *entity = [[NSData alloc] initWithBytes:&anInt length:1];
        [hexData appendData:entity];
        
        range.location += range.length;
        range.length = 2;
    }
    
    return hexData;
}

- (BOOL)isHexFormatString
{
    return [[NSCharacterSet characterSetWithCharactersInString:@"0123456789ABCDEF"] isSupersetOfSet:[NSCharacterSet characterSetWithCharactersInString:[self uppercaseString]]];
}



// Hex format NSString to hex format NSData
- (NSData *)convertToHexData:(NSString *)hexString
{
    if ([self isHexFormatString]) {
        NSString *command = hexString;
        command = [command stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSMutableData *commandToSend= [[NSMutableData alloc] init];
        unsigned char whole_byte;
        char byte_chars[3] = {'\0','\0','\0'};
        int i;
        for (i=0; i < [command length]/2; i++) {
            byte_chars[0] = [command characterAtIndex:i*2];
            byte_chars[1] = [command characterAtIndex:i*2+1];
            whole_byte = strtol(byte_chars, NULL, 16);
            [commandToSend appendBytes:&whole_byte length:1];
        }
        return [NSData dataWithData:commandToSend];
    }
    return nil;
}


//将16进制转化为二进制字符串
-(NSString *)convertHexToBinary
{
    NSString * hexStr = [self uppercaseString];
    
    NSMutableDictionary  *hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    
    [hexDic setObject:@"0000" forKey:@"0"];
    
    [hexDic setObject:@"0001" forKey:@"1"];
    
    [hexDic setObject:@"0010" forKey:@"2"];
    
    [hexDic setObject:@"0011" forKey:@"3"];
    
    [hexDic setObject:@"0100" forKey:@"4"];
    
    [hexDic setObject:@"0101" forKey:@"5"];
    
    [hexDic setObject:@"0110" forKey:@"6"];
    
    [hexDic setObject:@"0111" forKey:@"7"];
    
    [hexDic setObject:@"1000" forKey:@"8"];
    
    [hexDic setObject:@"1001" forKey:@"9"];
    
    [hexDic setObject:@"1010" forKey:@"A"];
    
    [hexDic setObject:@"1011" forKey:@"B"];
    
    [hexDic setObject:@"1100" forKey:@"C"];
    
    [hexDic setObject:@"1101" forKey:@"D"];
    
    [hexDic setObject:@"1110" forKey:@"E"];
    
    [hexDic setObject:@"1111" forKey:@"F"];
    
    NSMutableString *binaryString=[[NSMutableString alloc] initWithCapacity:(hexStr.length * 2)];
    
    for (int i=0; i<[hexStr length]; i++) {
        
        NSRange rage = NSMakeRange(i, 1);;
        
        NSString *key = [hexStr substringWithRange:rage];
        
        [binaryString appendFormat:@"%@",[hexDic objectForKey:key]];
    }
    
    return binaryString;
}



//将十进制转化为十六进制
- (NSString *)convertDecimalToHex
{
    uint16_t num = (unsigned short)[self intValue];
    NSMutableString * result = [[NSMutableString alloc]init];
    while (num > 0) {
        int ab = num % 16;
        char c;
        if (ab > 9) {
            c = 'a' + (ab - 10);
        }
        else{
            c = '0' + ab;
        }
        NSString * reminder = [NSString stringWithFormat:@"%c",c];
        [result insertString:reminder atIndex:0];
        num = num / 16;
    }
    return result;
}

//- (NSString *)convertDecimalToHex
//{
//    NSString *nLetterValue;
//    NSString *str =@"";
//    uint16_t tmpid = (unsigned short)[self intValue];
//    uint16_t ttmpig;
//    for (int i = 0; i<9; i++) {
//        ttmpig = tmpid % 16;
//        tmpid = tmpid / 16;
//        switch (ttmpig)
//        {
//            case 10:
//                nLetterValue =@"a";break;
//            case 11:
//                nLetterValue =@"b";break;
//            case 12:
//                nLetterValue =@"c";break;
//            case 13:
//                nLetterValue =@"d";break;
//            case 14:
//                nLetterValue =@"e";break;
//            case 15:
//                nLetterValue =@"f";break;
//            default:
//                nLetterValue = [NSString stringWithFormat:@"%u",ttmpig];
//        }
//        str = [nLetterValue stringByAppendingString:str];
//        if (tmpid == 0) {
//            break;
//        }
//        
//    }
//    return str;
//}


//十六进制转十进制 字符串
-(NSString *)convertHexToDecimal{
    unsigned int anInt;
    NSScanner *scanner = [[NSScanner alloc] initWithString:self];
    [scanner scanHexInt:&anInt];
    NSString *intStr=[NSString stringWithFormat:@"%d",anInt];
    return intStr;
}


//十进制转二进制  decimal10进制字符串
- (NSString *)convertDecimalToBinary
{
    NSString *decimal = self;
    int num = [decimal intValue];
    int remainder = 0;      //余数
    int divisor = 0;        //除数
    
    NSString * prepare = @"";
    
    while (true)
    {
        remainder = num % 2;
        divisor = num / 2;
        num = divisor;
        prepare = [prepare stringByAppendingFormat:@"%d",remainder];
        
        if (divisor == 0){
            break;
        }
    }
    NSString * result = @"";
    int preparelen = (int)prepare.length;
    int digit = 8 * ((preparelen-1)/ 8 + 1);

    for (int i = digit-1; i >= 0; i --){
        //取反(prepare是正向拼接 如16：00001->0001 0000)
        if (i >= preparelen) {
            result = [result stringByAppendingFormat:@"0"];
        }
        else{
            result = [result stringByAppendingFormat:@"%@",
                      [prepare substringWithRange:NSMakeRange(i , 1)]];
        }
    }
    return result;
}

//  二进制转十进制
- (NSString *)convertBinaryToDecimal
{
    NSString *binary = self;
    int ll = 0 ;
    int temp = 0 ;
    for (int i = 0; i < binary.length; i ++)
    {
        temp = [[binary substringWithRange:NSMakeRange(i, 1)] intValue];
        temp = temp * powf(2, binary.length - i - 1);
        ll += temp;
    }
    
    NSString * result = [NSString stringWithFormat:@"%d",ll];
    
    return result;
}


//2转16
- (NSString *)convertBinaryToHex
{
    NSString * decumalStr = [self convertBinaryToDecimal];
    NSString * result = [decumalStr convertDecimalToHex];
    return result;
}


//
//string BinToHex(const string &strBin, bool bIsUpper = false)
//{
//    string strHex;
//    strHex.resize(strBin.size() * 2);
//    for (size_t i = 0; i < strBin.size(); i++)
//    {
//        uint8_t cTemp = strBin[i];
//        for (size_t j = 0; j < 2; j++)
//            {
//                 uint8_t cCur = (cTemp & 0x0f);//15
//                 if (cCur < 10)
//                 {
//                     cCur += '0';
//                 }
//                 else
//                 {
//                     cCur += ((bIsUpper ? 'A' : 'a') - 10);
//                 }
//                strHex[2 * i + 1 - j] = cCur;
//                cTemp >>= 4;
//          }
//    }
//    return strHex;
//}

@end
