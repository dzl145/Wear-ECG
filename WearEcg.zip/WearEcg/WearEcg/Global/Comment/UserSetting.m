//
//  UserSetting.m
//  WearEcg
//
//  Created by lxl on 16/1/19.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "UserSetting.h"
#include <sys/xattr.h>
#import "HDPublicClass.h"

@implementation UserSetting


+ (BOOL)getWifiSetup{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"WIFIUPLOAD"];
}

+ (void)setWifiSetup:(BOOL)isWiFi{
    [[NSUserDefaults standardUserDefaults] setBool:isWiFi forKey:@"WIFIUPLOAD"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (BOOL)setNotBackUp:(NSString *)filePath
{
    NSError *error = nil;
    NSURL *fileURL = [NSURL fileURLWithPath:filePath];
    NSNumber *attrValue = [NSNumber numberWithBool:YES];
    
    //真的 资源排除备份，否则为假
    [fileURL setResourceValue:attrValue
                       forKey:NSURLIsExcludedFromBackupKey
                        error:&error];
    if (error != nil) {
        NSLog(@"%@",[error localizedDescription]);
        return NO;
    }
    return YES;
}


//程序是否第一次安装运行
#define kIsFirstTimeInstall @"kIsFirstTimeInstall"
+ (BOOL)isFirstTimeInstallApplication {
    BOOL  hasRunBefore = [[NSUserDefaults standardUserDefaults] boolForKey:kIsFirstTimeInstall];
    if (!hasRunBefore) {
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kIsFirstTimeInstall];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return YES;
    }
    return NO;
}

//NSString * str2 =  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
+ (NSString *)getCurAppVesion{
    NSString * version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    return version;
}

+ (void)setNewestAppVesion : (NSString *)version{
    [[NSUserDefaults standardUserDefaults] setObject:version forKey:CurNewestKey];
    [NSUserDefaults resetStandardUserDefaults];
}

+ (NSString *)getNewestAppVesion{
    NSString * newVersion = [[NSUserDefaults standardUserDefaults] valueForKey :CurNewestKey];
    if (newVersion == nil || [newVersion isEqualToString:@""]) {
        return nil;
    }
    return newVersion;
}

+ (NSString *)getSystemVesion{
    NSString* sysytemVersion = [[UIDevice currentDevice] systemVersion];
    return sysytemVersion;
}



+ (void)setDeviceTipsState : (BOOL)isOn{
    [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:isOn] forKey:DeviceTipState];
    [NSUserDefaults resetStandardUserDefaults];
}


+ (BOOL)getDeviceTipsState{
    NSNumber * isON = [[NSUserDefaults standardUserDefaults] valueForKey :DeviceTipState];
    if (isON == nil) {
        return NO;
    }
    return [isON boolValue];
}

+ (void)setMvCorrectState : (BOOL)isOn{
    [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:isOn] forKey:MvCorrect];
    [NSUserDefaults resetStandardUserDefaults];
}
+ (BOOL)getMvCorrectState{
    NSNumber * isON = [[NSUserDefaults standardUserDefaults] valueForKey :MvCorrect];
    if (isON != nil) {
        return [isON boolValue];
    }
    return NO;
}

+ (void)setPacketLossState : (BOOL)isOn{
    [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:isOn] forKey:PacketLoss];
    [NSUserDefaults resetStandardUserDefaults];
}
+ (BOOL)getPacketLossState{
    NSNumber * isON = [[NSUserDefaults standardUserDefaults] valueForKey :PacketLoss];
    if (isON != nil) {
        return [isON boolValue];
    }
    return NO;
}

+ (void)setLastMeasurementWay : (NSInteger)way{
    [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithInteger:way] forKey:MeasurtWay];
    [NSUserDefaults resetStandardUserDefaults];
}
+ (NSInteger)getLastMeasurementWay{
    NSNumber * isON = [[NSUserDefaults standardUserDefaults] valueForKey :MeasurtWay];
    if (isON != nil) {
        return [isON integerValue];
    }
    return 0;
}


+ (void)setHomeMenuList:(NSArray *)menuArr{
    [[NSUserDefaults standardUserDefaults] setObject:menuArr forKey:HomeMenuList];
    [NSUserDefaults resetStandardUserDefaults];
}
+ (NSArray *)getHomeMenuList{
    
    NSArray * array = [[NSUserDefaults standardUserDefaults] valueForKey :HomeMenuList];
    if (array == nil) {
        NSDictionary * heartdic = @{@"title":@"心电",@"logoDefult":@"icon-ecg",@"logoSelect":@"iconchoose-ecg"};
        NSDictionary * temperaturedic = @{@"title":@"体温",@"logoDefult":@"icon-body temperature",@"logoSelect":@"iconchoose-body timpera"};
        NSDictionary * pressuredic = @{@"title":@"胎心仪",@"logoDefult":@"icon-tire right",@"logoSelect":@"iconchoose-tire right"};
        NSDictionary * adddic = @{@"title":@"手表",@"logoDefult":@"icon-watch",@"logoSelect":@"iconchoose-watch"};

        array = [NSArray arrayWithObjects:heartdic,temperaturedic,pressuredic,adddic,nil];
    }
    return array;
}


+ (NSInteger)getCurNetWorkState {
    NSNumber * type = [[NSUserDefaults standardUserDefaults] valueForKey:NetWorkState];
    if (type == nil) {
        return 0;
    }
    return [type integerValue];
}




@end
