//
//  Loading.m
//  WearEcg
//
//  Created by HeartDoc on 16/6/7.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "Loading.h"
#import "AppDelegate.h"

@implementation Loading

static Loading * loading;

//单例
+ (Loading *)ShareLoading;{
    
    if (loading != nil) {
        return loading;
    }
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        loading = [[Loading alloc]init];
    });
    
    return loading;
}

+ (id)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        loading = [super allocWithZone:zone];
    });
    return loading;
}

- (id)copyWithZone:(NSZone *)zone
{
    return loading;
}


#pragma -mark HUD
+ (void)showHud : (NSString *)tipStr
{
    [[Loading ShareLoading].hud show:YES];
    if (tipStr != nil && ![tipStr isEqualToString:@""]) {
        [Loading ShareLoading].hud.labelText = tipStr;
    }
}

+ (void)hideHud
{
    [[Loading ShareLoading].hud hide:YES];
}

- (MBProgressHUD *)hud
{
    if(!_hud){
        _hud = [[MBProgressHUD alloc] init];
        _hud.labelText = @"";
        
        AppDelegate * app = (AppDelegate *)[UIApplication sharedApplication].delegate;
        [app.window addSubview:_hud];
        [app.window bringSubviewToFront:_hud];
    }
    return _hud;
}

+ (void)showHud : (NSString *)tipStr showtime : (CGFloat)time
{
    [self showHud : tipStr];
    [[Loading ShareLoading].hud hide:YES afterDelay:1];
}

+ (void)showTips:(NSString *)str {
    AppDelegate * app = (AppDelegate *)[UIApplication sharedApplication].delegate;
    MBProgressHUD *progressTip = [MBProgressHUD showHUDAddedTo:app.window animated:YES];
    [app.window bringSubviewToFront:progressTip];
    
    progressTip.mode = MBProgressHUDModeText;
    progressTip.labelText = str;
    progressTip.margin = 10.f;
    progressTip.removeFromSuperViewOnHide = YES;
    progressTip.yOffset = SCREEN_HEIGHT/2 * 0.75f;

    // 新改属性
    progressTip.minSize = CGSizeMake(160, 30);
    progressTip.cornerRadius = 20;
    progressTip.labelFont = [UIFont systemFontOfSize:14];
    [progressTip hide:YES afterDelay:1];
}



@end
