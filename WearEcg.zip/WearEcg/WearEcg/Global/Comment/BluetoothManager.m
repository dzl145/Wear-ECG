//
//  BluetoothManager.m
//  EcgWear
//
//  Created by HeartDoc on 16/8/4.
//  Copyright © 2016年 owen. All rights reserved.
//

#import "BluetoothManager.h"
#import "WearViewController.h"

@implementation BluetoothManager

static BluetoothManager * bluetooth;
//单例
+ (BluetoothManager *)ShareBluetooth{
    
    if (bluetooth != nil) {
        return bluetooth;
    }
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        bluetooth = [[BluetoothManager alloc]init];
    });
    
    return bluetooth;
}

-(instancetype)init{
    self = [super init];
    if (self) {
        // SDK初始化
        self.BlueSdk = [[HeartCloud_SDK alloc] init];
        self.BlueSdk.delegate = self;
        self.commndState = NO;
        commndTimer = nil;
        isInitiativeDis = NO;
        reconnection = NO;
    }
    return self;
}

+ (id)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        bluetooth = [super allocWithZone:zone];
    });
    return bluetooth;
}

- (id)copyWithZone:(NSZone *)zone
{
    return bluetooth;
}

-(NSMutableArray *)BlueNumberArr{
    if (_BlueNumberArr ==nil) {
        _BlueNumberArr = [[NSMutableArray alloc]init];
    }
    return _BlueNumberArr;
}

-(NSMutableArray<BluetoothManagerDelegate> *)delegateArr{
    if (_delegateArr ==nil) {
        _delegateArr = [[NSMutableArray<BluetoothManagerDelegate> alloc]init];
    }
    return _delegateArr;
}

#pragma mark ------ 方法函数
- (void)addDelegateForBlueArr:(id<BluetoothManagerDelegate>)delegate{
    if (delegate == nil) {
        return;
    }
    if (![self.delegateArr containsObject:delegate]) {
        [self.delegateArr addObject:delegate];
    }
//     NSLog(@"###### 代理已经添加 代理个数为 : %ld",(long)self.delegateArr.count);
}

- (void)removeDelegateFromBlueArr : (id<BluetoothManagerDelegate>)delegate{
    if (delegate == nil) {
        return;
    }
    if ([self.delegateArr containsObject:delegate]) {
        [self.delegateArr removeObject:delegate];
    }
//    NSLog(@"******* 代理已经删除 代理个数为 : %ld",(long)self.delegateArr.count);
}

- (AU_RESULT_START_ADDING_MODE)startAddingMode:(BOOL)isReConnect{
    reconnection = isReConnect;
    if (!isReConnect && reConnectTimer != nil) {
        [self cancleTimer:reConnectTimer timerType:BlueTimerType_ReConnect];
        [self stopAddingMode];
        if (self.reConnectObj) {
            SEL selector = @selector(bluetoothreReConnectFail);
            for (id delegate in self.delegateArr) {
                if ([delegate respondsToSelector:selector]) {
                    [delegate bluetoothreReConnectFail];
                }
            }
            [self removeDelegateFromBlueArr:self.reConnectObj];
            self.reConnectObj = nil;
        }
    }
    AU_RESULT_START_ADDING_MODE result = [self.BlueSdk startAddingMode];
    if (result != AU_RESULT_START_ADDING_MODE_OK) {
        NSLog(@"%@",[NSString stringWithFormat:@"未能成功进入添加设备模式(错误代码:%ld)", (long)result]);
    }
    return result;
}

- (void)stopAddingMode {
    [self.BlueSdk stopAddingMode];
    if (self.onUUID == nil) {
        [self.BlueNumberArr removeAllObjects];
        self.BlueNumberArr = nil;
    }
}


- (void)connectNewFoundDevice:(NSString *)uuid withPeripheral:(CBPeripheral *)peripheral{
    [self.BlueSdk connectNewFoundDevice:uuid withPeripheral:peripheral];
}

- (void)reConnectKnownDevice{
//    if (reConnectObj == nil) {
//        return;
//    }
//    self.reConnectObj = reConnectObj;
//    [self addDelegateForBlueArr:reConnectObj];
    AU_RESULT_START_ADDING_MODE result = [self startAddingMode:YES];
    if (result == AU_RESULT_START_ADDING_MODE_OK) {
        reConnectTimer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(blueReConnect:) userInfo:nil repeats:YES];
        [reConnectTimer fire];
    }
}

- (BOOL)isConnected {
    if (self.onUUID != nil) {
        return [self.BlueSdk isConnected:self.onUUID];
    }
    return NO;
}

- (void)disconnectDevice {
    if (self.onUUID != nil) {
        [self.BlueSdk disconnectDevice:self.onUUID];
    }
    
}

// 设置连接间隔 默认值(30ms) 有效值:0x02〜0x20
- (AU_RESULT_CONFIG_DEVICE)configDevice:(NSString *)uuid connectionInterval:(AU_CONNECTION_INTERVAL)value{
    return [self configDevice:uuid connectionInterval:value];
}


#pragma mark - AU_SDK_BLE_UART_Delegate
//  过滤一般情况下，可以通过以下3个属性("设备名"、"厂商ID"、"服务列表")来过滤
- (void)device:(NSString *)uuid stateChanged:(AU_BLE_STATE)state userInfo:(NSDictionary *)advertisementData withperipheral:(CBPeripheral *)peripheral withRSSI:(NSNumber *)RSSI {
    switch (state) {
            //发现新的BLE设备
        case AU_BLE_STATE_FOUND_NEW_DEVICE:
        {
            // 获取"设备名"
            NSString *deviceName = [advertisementData valueForKey:CBAdvertisementDataLocalNameKey];
            NSLog(@"deviceName == %@",deviceName);
            
            // hasPrefix 字符xString串前面是否包含aString   ]
            if (deviceName != nil && ([deviceName hasPrefix:@"MECG"] || [deviceName hasPrefix:@"XY"]))
            {
                //回调搜索到的蓝牙
//                if (![self isHasUUIDInArray:uuid]) {
                    NSDictionary * blueDic = @{@"uuid":uuid, @"deviceName":deviceName, @"peripheral":peripheral};
                    [self.BlueNumberArr addObject:blueDic];
                    if (reconnection) {
                        //连接
                        NSString * newnestUuid = [[HDPublicClass shareInstance] getBlueConnectUuid];
                        if (newnestUuid != nil && [newnestUuid isEqualToString:uuid]) {
                            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                            [defaults objectForKey:@"deveice"];
                            if ([[defaults objectForKey:@"deveice"] isEqualToString:deviceName]) {
                                [self.BlueSdk connectNewFoundDevice:uuid withPeripheral:nil];
                            }
                        }
                    }
                    else {
                        SEL selector = @selector(bluetoothFindCallback:withRSSI:);
                        for (id delegate in self.delegateArr) {
                            if ([delegate respondsToSelector:selector]) {
                                [delegate bluetoothFindCallback:uuid withRSSI:RSSI];
                            }
                        }
                    }
//                }
            }
            break;
        }
        case AU_BLE_STATE_CONNECTED:
        {
            // 连接的时候结束搜索 表示设备已经完成连接，正在进行初始化
            [self.BlueSdk stopAddingMode];
            SEL selector = @selector(bluetoothConnectInitCallback:);
            for (id delegate in self.delegateArr) {
                if ([delegate respondsToSelector:selector]) {
                    [delegate bluetoothConnectInitCallback:uuid];
                }
            }
            
            break;
        }
        case AU_BLE_STATE_READY:
        {
            NSString *deviceName = [advertisementData valueForKey:CBAdvertisementDataLocalNameKey];
            self.onUUID = uuid;
            reconnection = NO;
            if ([self.delegate respondsToSelector:@selector(bluetoothConnectSucessCallback:withDeviceName:)]) {
                [self.delegate bluetoothConnectSucessCallback:uuid withDeviceName:deviceName];
            }
            [[HDPublicClass shareInstance] updateBlueConnectUuid:uuid];
            
            break;
        }
        case AU_BLE_STATE_DISCONNECTED:
        {
            [self.BlueNumberArr removeAllObjects];
            _BlueNumberArr = nil;
            self.onUUID = nil;
            NSString *deviceName = [advertisementData valueForKey:CBAdvertisementDataLocalNameKey];
            SEL selector = @selector(bluetoothDisconnectCallback:withDeviceName:);
//            for (id delegate in self.delegateArr) {
                if ([self.delegate respondsToSelector:selector]) {
                    [self.delegate bluetoothDisconnectCallback:uuid withDeviceName:deviceName];
                }
//            }
             [self.delegateArr removeAllObjects];
            _delegateArr = nil;
            if (isInitiativeDis) {
                [self isInitiativeDisconnectState:NO];
            }
            break;
        }
        default:
            break;
    }
}

// 回调通知：APP接收命令结果
- (void)device:(NSString *)uuid didReceiveData:(NSData *)data error:(NSError *)error{
    if (error != nil) {
        NSLog(@"Bluetooth didReceiveData error : %@",error);
        return;
    }
    NSString *value = [data convertDataToHexStr];
    if([value rangeOfString:@"07"].location != NSNotFound){
        //命令响应
        self.commndState = YES;
    }
//    NSLog(@"*** %@    ",value);
    //执行回调
//    for (id delegate in self.delegateArr) {
        if ([self.delegate respondsToSelector:@selector(bluetoothReceiveDataCallback:)]) {
            
            [self.delegate bluetoothReceiveDataCallback:value];
            if([value rangeOfString:@"01"].location != NSNotFound){
                NSString *commndString = @"56810d0a";
                [self sendCommndStrToBluetooth:commndString isReply:NO];
            }
        }
//    }
}

-(BOOL)isHasUUIDInArray : (NSString *)uuid{
    for (NSDictionary * blueDic in self.BlueNumberArr) {
        if (blueDic[@"uuid"] != nil && [blueDic[@"uuid"] isEqualToString:uuid]) {
            return YES;
        }
    }
    return NO;
}

// 设置蓝牙断开状态
-(void)isInitiativeDisconnectState : (BOOL)isInitiative{
    isInitiativeDis = isInitiative;
}
-(BOOL)isInitiativeDisconnect{
    return isInitiativeDis;
}

#pragma mark ------ 发送命令
//命令计时器 单次命令400ms 5次(只要有数据返回则停止发送) 注意:断开蓝牙命令暂时没有返回数据
-(BOOL)sendCommndStrToBluetooth:(NSString *)commndStr isReply:(BOOL)reply {
    if(self.onUUID == nil){
        NSLog(@"蓝牙未连接");
        return NO;
    }
    //如果当前计时器存在 说明还有未完成的命令
    if (commndTimer != nil) {
        return NO;
    }
    self.commndState = NO;
    if (reply) {
        commndTimer = [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(sendCommndTimer:) userInfo:commndStr repeats:YES];
        [commndTimer fire];
    }
    else{
        [self sendDataToBluetooth:commndStr];
    }
    return YES;
}

//发送命令计时器 (不是线程安全的,self.commndState 只能判断当次的状态)
- (void)sendCommndTimer:(NSTimer *)timer {
    NSString * commndStr = [timer userInfo];
    static NSInteger postNum = 0;
    //判断时候已经接收到命令 是则停止发送 否则继续发送共5次 没有回复 则强制断开
    if (self.commndState) {
        [self cancleTimer:timer timerType:BlueTimerType_Commnd];
        self.commndState = NO;
        postNum = 0;
        NSLog(@"已经收到命令回复,停止发送命令");
    }
    else{
        if (postNum < 5) {
            postNum++;
            NSLog(@"发送命令次数 ： %ld",(long)postNum);
            [self sendDataToBluetooth:commndStr];
        }
        else{
            //当下位机没有命令回复时 暂时视为上位机主动断开连接
            [self isInitiativeDisconnectState:YES];
            [self disconnectDevice];
            [self cancleTimer:timer timerType:BlueTimerType_Commnd];
            postNum = 0;
            NSLog(@"没有收到命令回复,断开蓝牙连接");
        }
    }
}

//发送命令向蓝牙
- (void)sendDataToBluetooth:(NSString *)commndString {
    
    if (commndString.length > 0)
    {
        if ([commndString isHexFormatString])
        {
            // 生成NSData格式的命令
            NSData *command = [commndString convertHexStrToData];
            
            // 向BLE设备发送命令
            AU_RESULT_SEND_DATA result = [self.BlueSdk sendData:command toDevice:self.onUUID];
            
            // 即便返回结果为"AU_RESULT_SEND_DATA_OK"，也只表示APP成功发出数据，不等于BLE已接收到数据）
            if (result != AU_RESULT_SEND_DATA_OK) {
                NSLog(@"%@",[NSString stringWithFormat:@"未能成功发送数据(错误代码:%ld)", (long)result]);
            }
            else {
                NSLog(@"%@",[NSString stringWithFormat:@"已发送数据[%@]", [command description]]);
            }
        }
        else {
            NSLog(@"请正确输入HEX格式的命令内容");
        }
    }
    else {
        NSLog(@"命令不能为空");
    }
}

- (void)blueReConnect:(NSTimer *)timer {
     NSLog(@"~~~~~~~~ 正在重连中...");
    static NSInteger times = 0;
    BOOL isConnet = [self isConnected];
    if (isConnet) {
        times = 0;
        [self cancleTimer:timer timerType:BlueTimerType_ReConnect];
        NSLog(@"~~~~~~~~ 重连成功");
        for (id delegate in self.delegateArr) {
            if ([delegate respondsToSelector:@selector(bluetoothReconnectSucessCallback:)]) {
                [delegate bluetoothReconnectSucessCallback:self.onUUID];
            }
        }
        return;
    }
    if (times >= 600) {
        [self stopAddingMode];
        [self clearData];
        times = 0;
        [self cancleTimer:timer timerType:BlueTimerType_ReConnect];
        //重连失败
        SEL selector = @selector(bluetoothreReConnectFail);
        for (id delegate in self.delegateArr) {
            if ([delegate respondsToSelector:selector]) {
                [delegate bluetoothreReConnectFail];
            }
        }
    }
    else{
        //重连中
        SEL selector = @selector(bluetoothreReConnecting);
        for (id delegate in self.delegateArr) {
            if ([delegate respondsToSelector:selector]) {
                [delegate bluetoothreReConnecting];
            }
        }
    }
}

- (void)cancleTimer:(NSTimer *)timer timerType:(BlueTimerType)type {
    if(timer){
        [timer invalidate];
        timer = nil;
    }
    if (commndTimer && type == BlueTimerType_Commnd) {
        [commndTimer invalidate];
        commndTimer = nil;
    }
    if (reConnectTimer && type == BlueTimerType_ReConnect) {
        [reConnectTimer invalidate];
        reConnectTimer = nil;
    }
}


-(void)clearData{
    _onUUID = nil;
    [self.BlueNumberArr removeAllObjects];
    _BlueNumberArr = nil;
    
    [self.delegateArr removeAllObjects];
    _delegateArr = nil;
}

//执行回调
-(void)callBackSelector:(SEL)selector {
    
}

-(void)dealloc{
    [self clearData];
    if (commndTimer) {
        [commndTimer invalidate];
        commndTimer = nil;
    }
    self.onUUID = nil;
    
    self.reConnectObj = nil;
}

@end
