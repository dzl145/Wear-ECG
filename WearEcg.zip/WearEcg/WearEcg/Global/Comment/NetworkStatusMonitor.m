//
//  NetworkStatusMonitor.m
//  NetworkStatusDemo
//
//  Created by imac on 15/4/17.
//  Copyright (c) 2015年 Nickyxu. All rights reserved.
//

#import "NetworkStatusMonitor.h"

@implementation NetworkStatusMonitor

+(void)StartWithBlock{
    static  NetworkStatusMonitor *monitor;
    if (!monitor){
        monitor = [[NetworkStatusMonitor alloc]init];
    }
//    [[NSNotificationCenter defaultCenter]addObserver:monitor selector:@selector(applicationNetworkStatusChanged:) name:AFNetworkingReachabilityDidChangeNotification object:nil];
//    AFNetworkReachabilityManager *reachability = [AFNetworkReachabilityManager sharedManager];
//    [reachability startMonitoring];

    
}

//单例
+(void)StartWithBlock:(void (^)(NSInteger))block{
    
    static  NetworkStatusMonitor *monitor;
    if (!monitor){
        monitor = [[NetworkStatusMonitor alloc]init];
    }
    //给回调实例变量赋值 kReachabilityChangedNotification
    monitor.callBackBlock = block;
    [[NSNotificationCenter defaultCenter]addObserver:monitor selector:@selector(applicationNetworkStatusChanged:) name:AFNetworkingReachabilityDidChangeNotification object:nil];
    AFNetworkReachabilityManager *reachability = [AFNetworkReachabilityManager sharedManager];
    [reachability startMonitoring];
}

-(void)applicationNetworkStatusChanged:(NSNotification*)userinfo{
    NSInteger status = [[[userinfo userInfo]objectForKey:@"AFNetworkingReachabilityNotificationStatusItem"] integerValue];
    switch (status) {
        case AFNetworkReachabilityStatusNotReachable:
            [self withoutNetwork];
            break;
        case AFNetworkReachabilityStatusReachableViaWWAN:
            [self wwanNetwork];
            break;
        case AFNetworkReachabilityStatusReachableViaWiFi:
            [self wifiNetwork];
            break;
        case AFNetworkReachabilityStatusUnknown:
        default:
            [self unknowNetwork];
            break;
    }
    //如果一直实时监测 网络状态 则不需要删除通知
    //[[NSNotificationCenter defaultCenter] removeObserver:self];
}

//流量
-(void)wwanNetwork{
    CTTelephonyNetworkInfo *networkStatus = [[CTTelephonyNetworkInfo alloc]init];
    NSString *currentStatus  = networkStatus.currentRadioAccessTechnology;
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyGPRS"]){
        //执行回调
        if (self.callBackBlock) {
            self.callBackBlock (GPRS);
        }
        [self setNetWorkStateForLocal:GPRS];
        //GPRS网络
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyEdge"]){
        if (self.callBackBlock) {
            self.callBackBlock (Edge);
        }
        [self setNetWorkStateForLocal:Edge];
        //2.75G的EDGE网络
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyWCDMA"]){
        if (self.callBackBlock) {
            self.callBackBlock (WCDMA);
        }
        [self setNetWorkStateForLocal:WCDMA];
        //3G WCDMA网络
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyHSDPA"]){
        if (self.callBackBlock) {
            self.callBackBlock (HSDPA);
        }
        [self setNetWorkStateForLocal:HSDPA];
        //3.5G网络
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyHSUPA"]){
        if (self.callBackBlock) {
            self.callBackBlock (HSUPA);
        }
        [self setNetWorkStateForLocal:HSUPA];
        //3.5G网络
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMA1x"]){
        if (self.callBackBlock) {
            self.callBackBlock (CDMA1xNetwork);
        }
        [self setNetWorkStateForLocal:CDMA1xNetwork];
        //CDMA2G网络
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORev0"]){
        if (self.callBackBlock) {
            self.callBackBlock (CDMAEVDORev0);
        }
        [self setNetWorkStateForLocal:CDMAEVDORev0];
        //CDMA的EVDORev0(应该算3G吧?)
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevA"]){
        if (self.callBackBlock) {
            self.callBackBlock (CDMAEVDORevA);
        }
        [self setNetWorkStateForLocal:CDMAEVDORevA];
        //CDMA的EVDORevA(应该也算3G吧?)
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevB"]){
        if (self.callBackBlock) {
            self.callBackBlock (CDMAEVDORevB);
        }
        [self setNetWorkStateForLocal:CDMAEVDORevB];
        //CDMA的CDMAEVDORevB(应该还是算3G吧?)
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyeHRPD"]){
        if (self.callBackBlock) {
            self.callBackBlock (HRPD);
        }
        [self setNetWorkStateForLocal:HRPD];
        //HRPD网络
        return;
    }
    if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyLTE"]){
        if (self.callBackBlock) {
            self.callBackBlock (LTE);
        }
        [self setNetWorkStateForLocal:LTE];
        //LTE4G网络
        return;
    }
    
    /*==
    取运营商名字  Objective.subscriberCellularProvider.carrierName
     */
}

//无网
-(void)withoutNetwork{
    //执行回调
    if (self.callBackBlock) {
        self.callBackBlock (WithoutNetwork);
    }
    [self setNetWorkStateForLocal:WithoutNetwork];
}

//wifi网络
-(void)wifiNetwork{
    if (self.callBackBlock) {
        self.callBackBlock (WifiNetwork);
    }
    [self setNetWorkStateForLocal:WifiNetwork];
}

//不知名网络
-(void)unknowNetwork{
    if (self.callBackBlock) {
        self.callBackBlock (UnknowNetwork);
    }
    [self setNetWorkStateForLocal:UnknowNetwork];
}

-(void)setNetWorkStateForLocal : (NetworkStatus)status{
    [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithInteger:status] forKey:NetWorkState];
    [NSUserDefaults resetStandardUserDefaults];
    NSDictionary * dict = @{@"wifitype": [NSNumber numberWithInteger:status]};
    SendNotify(NofifyWifiState, dict);
}

@end
