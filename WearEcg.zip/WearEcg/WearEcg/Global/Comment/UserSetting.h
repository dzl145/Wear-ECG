//
//  UserSetting.h
//  WearEcg
//
//  Created by lxl on 16/1/19.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserSetting : NSObject

/**
 *  获取wifi设置   默认是仅在wifi下上传
 *  @return BooL YES:仅在wifi状态下上传  NO:则都可以上传
 */
+ (BOOL)getWifiSetup;

/**
 *  设置 是否仅wifi上传
 */
+ (void)setWifiSetup:(BOOL)isWiFi;


/**
 *  不备份到Cloud
 *
 *  @param filePath 不备份路径
 */
+ (BOOL)setNotBackUp:(NSString *)filePath;


/**
 *  是否第一次运行程序
 */
+ (BOOL)isFirstTimeInstallApplication;


/**
 *  获取当前app版本号
 */
+ (NSString *)getCurAppVesion;


/**
 *  设置记录最新版本号 (未更新的版本号)
 */
+ (void)setNewestAppVesion : (NSString *)version;

/**
 *  获取记录最新的版本号
 */
+ (NSString *)getNewestAppVesion;

/**
 *  获取系统的版本号
 */
+ (NSString *)getSystemVesion;

/**
 *  设置关联设备音量提醒状态
 */
+ (void)setDeviceTipsState : (BOOL)isOn;


/**
 *  获取保存关联设备音量提醒状态
 */
+ (BOOL)getDeviceTipsState;

/**
 *  高级设置/获取 设置mv校准是否显示
 */
+ (void)setMvCorrectState : (BOOL)isOn;
+ (BOOL)getMvCorrectState;

/**
 *  高级设置/获取 设置丢包率是否显示
 */
+ (void)setPacketLossState : (BOOL)isOn;
+ (BOOL)getPacketLossState;

/**
 *  记录上次测量的 方式
 */
+ (void)setLastMeasurementWay : (NSInteger)way;
+ (NSInteger)getLastMeasurementWay;


/**
 *  记录主页面菜单选项
 */
+ (void)setHomeMenuList : (NSArray *)menuArr;
+ (NSArray *)getHomeMenuList;

/**
 *  获取当前网络的状态
 */
+ (NSInteger)getCurNetWorkState;




@end
