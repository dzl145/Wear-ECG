//
//  CardIdVerification.h
//  StudyTourLeaderSide
//
//  Created by use on 16/3/9.
//  Copyright © 2016年 wjp. All rights reserved.
//

#import <Foundation/Foundation.h>

//正则验证类
@interface RegexpVerification : NSObject

//身份证验证
+ (BOOL)cardIdVerification:(NSString *)cardId;

//手机号码验证 是否合法
+ (BOOL)phoneNumVerification:(NSString *)phoneNum;

//邮箱验证
+ (BOOL)mailAddVerification:(NSString *)mailAdd;


@end
