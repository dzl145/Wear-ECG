//
//  DeviceStorage.h
//  WearEcg
//
//  Created by HeartDoc on 16/5/18.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import <Foundation/Foundation.h>

//设备存储容量类

@interface DeviceStorage : NSObject
/*
 * 获取设备总内存
 * retrun MB
 */
+(CGFloat)getTotalMemory;


/*
 * 获取当前设备可用内存
 * retrun MB
 */
+(CGFloat)getDeviceMemory;

/*
 * 获取当前应用所占用的内存
 * retrun MB
 */
+ (CGFloat)getUsedMemory;


/*
 * 获取当前设备磁盘的总容量
 * retrun MB
 */
+(CGFloat)getTotalDiskStorage;

/*
 * 获取当前设备磁盘的可用容量
 * retrun MB
 */
+(CGFloat)getFreeDiskStorage;


@end
