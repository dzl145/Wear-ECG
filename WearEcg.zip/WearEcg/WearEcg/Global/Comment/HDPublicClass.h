////
////  HDPublicClsass.h
////  WearEcg
////
////  Created by lxl on 15/12/11.
////  Copyright © 2015年 lxl. All rights reserved.
////
//
//#import <Foundation/Foundation.h>
//
////typedef NS_ENUM(NSUInteger, HeartValueType) {
////    HeartValueType_Avg = 1,          //平均值
////    HeartValueType_Max,              //最大
////    HeartValueType_Min,              //最小
////};
//
////@interface HDPublicClass : NSObject
//
////单例
//+(id)shareInstance;
//
//
///**
// *  获取文件大小 (60s波形文件 和 已经上传的连续测量截取波形文件)
// *
// *  @return 文件总大小
// */
//-(CGFloat)getDBFileSizesForWaveInSixtyAndUpload;
//
///**
// *  获取文件 (60s波形文件 和 已经上传的连续测量截取波形文件)
// *
// *  @returns 文件的路径
// */
//-(NSArray *)getDBFilesForWaveInSixtyAndUpload;
//
///**
// *  获取所有文件 (60s波形文件 和 连续测量截取波形文件 (无论是否上传))
// *
// *  @returns 所有文件的路径
// */
//-(NSArray *)getDBAllFileForWaveInSixtyAndContinue;
//
///**
// *  获取磁盘上指定路径下 所有的txt文件
// *
// *  @returns 所有文件的路径
// */
//-(NSArray *)getDiskAllTxtFileForPath : (NSString *)path;
//
///**
// *  更新每次连接的蓝牙UUID
// */
//- (void)updateBlueConnectUuid : (NSString *)uuid;
//
///**
// *  获取最近更新连接的蓝牙uuid
// */
//- (NSString *)getBlueConnectUuid;
//
///**
// *  获取心率比例
// */
//-(NSArray *)getHeartScale : (NSArray *)heartArr;
//
//
///**
// *  显示心率值
// */
//-(NSString *)getHeartValue : (NSArray *)heartArr valueType : (HeartValueType)type;
//
///**
// *  获取健康值
// */
//-(NSInteger)getHealthValue : (NSArray *)heartArr;
//
///**
// *  获取健康文本
// */
//-(NSString *)getHealthState : (NSInteger)value;
//
///**
// *  获取当前本地时间戳(一般默认的都是标准时间来计算,格式化后显示还是本地时间)
// *
// *  @return 返回时间的字符串
// */
//-(NSString *)getCurrentTime;
//
//
//@end
