//
//  FileUtility.h
//  FxCore
//
//  Created by hejinbo on 12-2-22.
//  Copyright (c) 2012年 Hejinbo. All rights reserved.
//

@interface FileUtility : NSObject {

}

/**
 *功能: 判断文件或文件夹是否已存在
 *参数:  
 filePath: 文件或文件夹的全路径
 *返回:
 TRUE : 已经存在
 FALSE: 不存在
 **/
+ (BOOL)isFileExist:(NSString *)filePath;

/**
 *功能: 创建文件夹目录
 *参数:  
 filePath: 文件夹的全路径；不存在就自动创建
 *返回:
 TRUE : 已经存在或不存在就创建
 FALSE: 创建失败
 **/
+ (BOOL)createDirectoryPath:(NSString *)DirectoryPath;

/**
 *功能: 创建文件(默认空文件 无内容)
 *参数:
 filePath: 文件的全路径，不存在就自动创建
 *返回:
 TRUE : 已经存在或不存在就创建
 FALSE: 创建失败
 **/
+ (BOOL)createFilePath:(NSString *)filePath;

/**
 * 功能: 创建文件 带有文本内容
 * 参数:
 * filePath: 文件的全路径，不存在就自动创建
 * fileContent : 文本内容
 * 返回:
 * TRUE : 已经存在或不存在就创建
 * FALSE: 创建失败
 **/
+ (BOOL)createFilePath:(NSString *)filePath contentStr : (NSString *)fileContent;

/**
 * 功能: 写入数据字符串
 * 参数:
 * fileContent :写入字符串内容
 * filePath: 文件的全路径,不存在就自动创建
 * 返回:
 *  TRUE : 写入成功
 *  FALSE: 写入失败
 **/
+ (BOOL)writeFileString:(NSString *)fileContent filePath:(NSString *)filePath;

/**
 * 功能: 追加 数据字符串(追加到文件的末尾)
 * 参数:
 * content :字符串内容
 * filePath: 文件的全路径,不存在就自动创建
 * 返回:
 *  TRUE : 写入成功
 *  FALSE: 写入失败
 **/
+ (BOOL)addItionalFileString:(NSString *)content filePath:(NSString *)filePath divider : (NSString *)divider;

/**
 * 功能: 写入NSData二进制数据
 * 参数:
 * data :写入二进制数据
 * filePath: 文件的全路径,不存在就自动创建
 * 返回:
 *  TRUE : 写入成功
 *  FALSE: 写入失败
 **/
+ (BOOL)writeFileData:(NSData *)data filePath:(NSString *)filePath;


/**
 * 功能: 写入字典数据
 * 参数:
 * dictionary :写入字典数据
 * filePath : 文件的全路径,不存在就自动创建
 * 返回:
 *  TRUE : 写入成功
 *  FALSE: 写入失败
 **/
+ (BOOL)writeFileDictionary:(NSDictionary *)dictionary filePath:(NSString *)filePath;

/**
 *功能: 读取文件数据
 *参数:
 filePath: 文件的全路径；不存在就自动创建
 *返回:
NSString : 读取返回的是字符串
 **/
+ (NSString *)readFilePathForString:(NSString *)filePath;

/**
 *功能: 读取文件数据
 *参数:
 filePath: 文件的全路径；不存在就自动创建
 *返回:
 NSString : 读取返回的Data二进制数据
 **/
+ (NSData *)readFilePathForData:(NSString *)filePath;


/**
 *功能: 读取文件数据 仅限于读取plist文件
 *参数:
 filePath: 文件的全路径；不存在就自动创建
 *返回:
 NSString : 读取返回的的是个字典
 **/
+ (NSDictionary *)readFilePathForDictionary:(NSString *)filePath;

/**
 *功能: 重命名文件
 TRUE : 成功
 FALSE: 创建失败
 **/
+ (BOOL)renameFile:(NSString *)filePath toFile:(NSString *)toPath;

/**
 *功能: 删除文件或文件夹
 *参数:  
 filePath: 文件或文件夹的全路径
 *返回:
 TRUE : 成功
 FALSE: 失败
 **/
+ (BOOL)deleteFile:(NSString *)filePath;

/**
 *功能: 将文件或文件夹从一个目录拷贝到另一个目录
 *参数:  
 fromPath   : 原始目录,如/Library/11
 toPath     : 目标目录,如/Documents/11
 isReplace  : 如果已经存在,是否替换
 *返回:
 TRUE : 成功
 FALSE: 失败
 **/
+ (BOOL)copyFromPath:(NSString *)fromPath
              toPath:(NSString *)toPath 
           isReplace:(BOOL)isReplace;

/**
 *功能: 将文件夹中的内容拷贝到另一个目录中,
 *参数:  
 fromPath   : 原始目录,如/Library/11,其中有1.jpg
 toPath     : 目标目录,如/Documents/,执行成功后,/Documents/1.jpg
 isReplace  : 如果已经存在,是否替换
 *返回:
 TRUE : 成功
 FALSE: 失败
 **/
+ (BOOL)copyContentsFromPath:(NSString *)fromPath
              toPath:(NSString *)toPath 
           isReplace:(BOOL)isReplace;


/**
 *功能: 将文件或文件夹从一个目录移动到另一个目录
 *参数:  
 fromPath   : 原始目录,如/Library/11
 toPath     : 目标目录,如/Documents/11
 isReplace  : 如果已经存在,是否替换
 *返回:
 TRUE : 成功
 FALSE: 失败
 **/
+ (BOOL)moveFromPath:(NSString *)fromPath
              toPath:(NSString *)toPath 
           isReplace:(BOOL)isReplace;

/**
 *功能: 将文件夹中的内容移动到另一个目录中,
 *参数:  
 fromPath   : 原始目录,如/Library/11,其中有1.jpg
 toPath     : 目标目录,如/Documents/,执行成功后,/Documents/1.jpg
 isReplace  : 如果已经存在,是否替换
 *返回:
 TRUE : 成功
 FALSE: 失败
 **/
+ (BOOL)moveContentsFromPath:(NSString *)fromPath
                      toPath:(NSString *)toPath 
                   isReplace:(BOOL)isReplace;

/**
 *功能: 计算一个文件或文件夹大小,(当前文件夹下文件)
 *参数:  
 filePath   : 文件或文件夹路径
 *返回: 文件或文件夹所占字节数
 **/
+ (double)calculteFileSzie:(NSString *)filePath;


/**
 * 功能: 计算一个文件夹大小,(该方法效率更高 精准)
 * 参数:
 * filePath  : 文件夹路径
 * isCatalog : 是否遍历所有子目录 YES:文件夹下所有文件  NO:当前文件夹下文件
 * 返回: 文件或文件夹所占字节数
 **/
+ (double)calculteFolderSize:(NSString *)folderPath catalog: (BOOL)isCatalog;


/**
 * 功能: 计算一个文件夹下 指定文件大小 (该方法效率更高 精准)
 * 参数:
 * filePath  : 文件夹路径
 * extenType : 文件后缀类型 (不带'.')
 * isCatalog : 是否遍历所有子目录 YES:文件夹下所有文件  NO:当前文件夹下文件
 * 返回: 文件或文件夹所占字节数
 **/
+(double)calculteFileSizeInFolder : (NSString *)folderPath extension : (NSString *)extenType catalog: (BOOL)isCatalog;


/**
 * 功能：递归删除某个目录下的指定文件
 *
 * 参数:
 * fileNames : 文件名 数组
 * path: 文件或文件夹路径
 **/
+ (void)deleteFiles:(NSArray *)fileNames inPath:(NSString *)path;






/**
 *  获取一级目录中文件  在指定的文件夹中
 *  
 *  @param folderPath  文件夹路径
 *  @param extenStr    文件后缀指定格式(不带'.')的文件
 *
 *  @return  文件名数组
 */
+ (NSArray *)getFirstCatalogFileNameInFolder : (NSString *)folderPath extension: (NSString *)extenStr;


/**
 *  获取目录中所有文件 在指定的文件夹中
 *
 *  @param folderPath  文件夹路径
 *  @param extenStr    文件后缀指定格式(不带'.')的文件
 */
+ (NSArray *)getAllFileNameInFolder : (NSString *)folderPath extension: (NSString *)extenStr;


/**
 *  获取单个文件的属性
 *
 *  @param filePath  文件路径
 *  @return 属性字典
 */
+ (NSDictionary * )getFileAttribute : (NSString*)filePath;


/**
 *  获取文件夹下文件的属性
 *
 *  @param folderPath  文件夹路径
 *  @param extenStr    文件后缀指定格式(不带'.')的文件
 *
 *  @return 文件属性 数组
 */
+ (NSArray * )getFilesAttributeInfolder : (NSString*)folderPath extension : (NSString *)extenStr;




@end
