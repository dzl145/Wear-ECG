//
//  FileUtility.m
//  FxCore
//
//  Created by hejinbo on 12-2-22.
//  Copyright (c) 2012年 Hejinbo. All rights reserved.
//

#import "FileUtility.h"
#import <sys/stat.h>
#import <dirent.h>
#import <string.h>

 
@implementation FileUtility

+ (BOOL)isFileExist:(NSString *)filePath
{
    //文件管理器 判断是否存在该路径
    NSFileManager *fm = [NSFileManager defaultManager];
    return [fm fileExistsAtPath:filePath];
}

+ (BOOL)createDirectoryPath:(NSString *)DirectoryPath
{
    if ([FileUtility isFileExist:DirectoryPath]) {
        return YES;
    }
    
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;
    
    [fm createDirectoryAtPath:DirectoryPath withIntermediateDirectories:YES attributes:nil error:&error];
    if (error != nil) {
        NSLog(@"createDirectoryPath error : %@",[error localizedDescription]);
        return NO;
    }
    
    return YES;
}

+ (BOOL)createFilePath:(NSString *)filePath
{
    return [FileUtility createFilePath : filePath contentStr : nil];
}


+ (BOOL)createFilePath:(NSString *)filePath contentStr : (NSString *)fileContent
{
    //获取文件所在 文件夹的路径
    NSString *directoryPath = [filePath stringByDeletingLastPathComponent];
    if (![FileUtility isFileExist:directoryPath]) {
        BOOL iscreate = [FileUtility createDirectoryPath:directoryPath];
        if (!iscreate) {
            return NO;
        }
    }
    if ([FileUtility isFileExist:filePath]) {
        return YES;
    }
    BOOL sucess = NO;
    NSFileManager *fm = [NSFileManager defaultManager];
    if (fileContent == nil) {
        sucess = [fm createFileAtPath:filePath contents:nil attributes:nil];
    }
    else{
        NSData *data = [fileContent dataUsingEncoding: NSUTF8StringEncoding];
        sucess = [fm createFileAtPath:filePath contents:data attributes:nil];
    }
    
    if (!sucess) {
        NSLog(@"createFilePath error : 文件创建失败");
        return NO;
    }
    return YES;
}


+ (BOOL)writeFileString:(NSString *)fileContent filePath:(NSString *)filePath
{
    if (![FileUtility isFileExist:filePath]) {
        [FileUtility createFilePath:filePath];
    }
    NSError *error = nil;
    //atomically 是否保持文件的原子性  YES会先创建一个临时文件,直到文件内容写入成功再导入到目标文件里.
    //如果为NO,则直接写入目标文件里.
    BOOL sucess = [fileContent writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (error!=nil) {
        NSLog(@"writeFileString error : %@",[error localizedDescription]);
        return NO;
    }
    if (sucess) {
        return YES;
    }
    return NO;
}

+ (BOOL)addItionalFileString:(NSString *)content filePath:(NSString *)filePath divider : (NSString *)divider{
    
    if (![FileUtility isFileExist:filePath]) {
        [FileUtility createFilePath:filePath];
    }
    
    NSFileHandle  *outFile;
    NSData *buffer;
    
    outFile = [NSFileHandle fileHandleForWritingAtPath:filePath];
    if(outFile == nil)
    {
        NSLog(@"Open of file for writing failed");
        return NO;
    }
    //找到并定位到outFile的末尾位置(在此后追加文件)
    unsigned long long pos = [outFile seekToEndOfFile];
    if (pos > 0 && divider != nil && ![divider isEqual :@""]) {
        //读取inFile并且将其内容写到outFile中
        NSString *strCon = [NSString stringWithFormat:@"%@%@",divider,content];
        buffer = [strCon dataUsingEncoding:NSUTF8StringEncoding];
    }
    else{
        buffer = [content dataUsingEncoding:NSUTF8StringEncoding];
    }
    [outFile writeData:buffer];
    //关闭读写文件
    [outFile closeFile];
    return YES;
}

+ (BOOL)writeFileData:(NSData *)data filePath:(NSString *)filePath
{
    if (![FileUtility isFileExist:filePath]) {
        [FileUtility createFilePath:filePath];
    }
    BOOL sucess = [data writeToFile:filePath atomically:YES];
    
    if (sucess) {
        return YES;
    }
    return NO;
}

+ (BOOL)writeFileDictionary:(NSDictionary *)dictionary filePath:(NSString *)filePath
{
    if (![FileUtility isFileExist:filePath]) {
        [FileUtility createFilePath:filePath];
    }
    BOOL sucess = [dictionary writeToFile:filePath atomically:YES];
    if (sucess) {
        return YES;
    }
    return NO;
}

+ (NSString *)readFilePathForString:(NSString *)filePath
{
    if (![FileUtility isFileExist:filePath]) {
        return @"";
    }
    NSError *error = nil;
    NSString *content = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    if (error!=nil) {
       NSLog(@"readFilePathForString  error : %@",[error localizedDescription]);
        return @"";
    }
    return content;
    

//     NSFileManager *fm = [NSFileManager defaultManager];
//     NSData * data = [fm contentsAtPath:filePath];
    
//     NSData->String
//     NSString *aString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
//     return aString;
    
//     String->NSData
//     NSData *aData = [aString dataUsingEncoding: NSUTF8StringEncoding];
//     NSData *data = [NSData dataWithContentsOfFile:filePath];
}

+ (NSData *)readFilePathForData:(NSString *)filePath
{
    if (![FileUtility isFileExist:filePath]) {
        return nil;
    }
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    return data;
    //注意:+ (nullable instancetype)dataWithContentsOfFile:(NSString *)path options:(NSDataReadingOptions)readOptionsMask error:(NSError **)errorPtr;
    //这个方法可以映射控件地址 不占用内存(待确定)
}

+ (NSDictionary *)readFilePathForDictionary:(NSString *)filePath
{
    if (![FileUtility isFileExist:filePath]) {
        return nil;
    }
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    return dic;
}


+ (BOOL)renameFile:(NSString *)filePath toFile:(NSString *)toPath
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;
    if ([FileUtility isFileExist:toPath]) {
        [fm removeItemAtPath:filePath error:&error];
        if (error!=nil) {
             NSLog(@"renameFile  error : %@",[error localizedDescription]);
        }
    }
    
    [fm moveItemAtPath:filePath toPath:toPath error:&error];
    if (error != nil) {
        NSLog(@"moveItemAtPath  error : %@",[error localizedDescription]);
        return NO;
    }
    
    return YES;
}

+ (BOOL)deleteFile:(NSString *)filePath
{
    if (![FileUtility isFileExist:filePath]) {
        return YES;
    }
    
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;
    
    [fm removeItemAtPath:filePath error:&error];
    if (error!=nil) {
        NSLog(@"deleteFile  error : %@",[error localizedDescription]);
        return NO;
    }
    
    return YES;
}
 
+ (BOOL)copyFromPath:(NSString *)fromPath
              toPath:(NSString *)toPath 
           isReplace:(BOOL)isReplace
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;
    
    if ([FileUtility isFileExist:toPath] && isReplace) {
        [FileUtility deleteFile:toPath];
    }
    
    [fm copyItemAtPath:fromPath toPath:toPath error:&error];
    if (error!=nil) {
        NSLog(@"copyFromPath  error : %@",[error localizedDescription]);
        return NO;
    }
    
    return YES;
}

+ (BOOL)copyContentsFromPath:(NSString *)fromPath
                      toPath:(NSString *)toPath 
                   isReplace:(BOOL)isReplace
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;

    NSArray *contents = [fm contentsOfDirectoryAtPath:fromPath error:&error];
    if (error != nil) {
        NSLog(@"copyContentsFromPath  error : %@",[error localizedDescription]);
    }
    
    NSString *toFilePath = nil, *fromFilePath = nil;
    for (NSString *path in contents) {
        
        toFilePath = [toPath stringByAppendingPathComponent:path];
        fromFilePath = [fromPath stringByAppendingPathComponent:path];
        
        if ([FileUtility isFileExist:toFilePath] && isReplace) {
            [FileUtility deleteFile:toFilePath];
        }
        
        [fm copyItemAtPath:fromFilePath toPath:toFilePath error:&error];
        if (error != nil) {
            NSLog(@"copyItemAtPath  error : %@",[error localizedDescription]);
        }
    }
    
    return YES;
}

+ (BOOL)moveFromPath:(NSString *)fromPath
              toPath:(NSString *)toPath 
           isReplace:(BOOL)isReplace
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;
    
    if ([FileUtility isFileExist:toPath] && isReplace) {
        [FileUtility deleteFile:toPath];
    }
    
    [fm moveItemAtPath:fromPath toPath:toPath error:&error];
    if (error!=nil) {
         NSLog(@"moveFromPath  error : %@",[error localizedDescription]);
        return NO;
    }
    
    return YES;
}


+ (BOOL)moveContentsFromPath:(NSString *)fromPath
                      toPath:(NSString *)toPath 
                   isReplace:(BOOL)isReplace
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;
    
    NSArray *contents = [fm contentsOfDirectoryAtPath:fromPath error:&error];
    if (error != nil) {
        NSLog(@"moveContentsFromPath  error : %@",[error localizedDescription]);
    }
    
    NSString *toFilePath = nil, *fromFilePath = nil;
    for (NSString *path in contents) {
        
        toFilePath = [toPath stringByAppendingPathComponent:path];
        fromFilePath = [fromPath stringByAppendingPathComponent:path];
        
        if ([FileUtility isFileExist:toFilePath] && isReplace) {
            [FileUtility deleteFile:toFilePath];
        }
        
        [fm moveItemAtPath:fromFilePath toPath:toFilePath error:&error];
        if (error != nil) {
            NSLog(@"moveItemAtPath  error : %@",[error localizedDescription]);
        }
    }
    
    return YES;
}

+ (double)calculteFileSzie:(NSString *)filePath
{
    double fSize = 0.0f;
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *dirContents = [fm contentsOfDirectoryAtPath:filePath error:nil];
    
    if (dirContents == nil) {//文件夹为空时,dirContents不为nil但数目count为0, path为文件时,dirContents = nil
        NSDictionary* dirAttr = [fm attributesOfItemAtPath:filePath error: nil];
        fSize += [[dirAttr objectForKey:NSFileSize] floatValue];
    }
    else {
        for (NSString *dirName in dirContents) {
            fSize +=  [FileUtility calculteFileSzie:[filePath stringByAppendingPathComponent:dirName]] ;
        }
    }
    
    return fSize;
}

//遍历目录文件 isRecursive 是否递归子目录
+ (double)calculteFileSizeAtPath:(const char*)folderPath recursive: (BOOL)isRecursive extension : (const char *)extenType
{
    double folderSize = 0;
    DIR* dir = opendir(folderPath);
    
    if (dir != NULL) { 
        struct dirent* child;
        struct stat st;
        NSInteger folderPathLength = 0;
        char childPath[1024] = {0};
        
        while ((child = readdir(dir))!=NULL) {
            // 忽略目录 .
            if (child->d_type == DT_DIR && (child->d_name[0] == '.' && child->d_name[1] == 0)) { 
                continue;
            }
            
            // 忽略目录 ..
            if (child->d_type == DT_DIR && (child->d_name[0] == '.' && child->d_name[1] == '.' && child->d_name[2] == 0)) 
                continue;
            
            folderPathLength = strlen(folderPath);
            stpcpy(childPath, folderPath);
            
            if (folderPath[folderPathLength-1] != '/'){
                childPath[folderPathLength] = '/';
                folderPathLength++;
            }
            
            stpcpy(childPath+folderPathLength, child->d_name);
            childPath[folderPathLength + child->d_namlen] = 0;
            
            // 递归计算子目录
            if (isRecursive) {
                if (child->d_type == DT_DIR) {
                    folderSize += [FileUtility calculteFileSizeAtPath:childPath recursive : YES extension : NULL];
                    // 把目录本身所占的空间也加上
                    if(lstat(childPath, &st) == 0)
                        folderSize += st.st_size;
                    continue;
                }
            }
            if (child->d_type == DT_REG || child->d_type == DT_LNK){ // file or link 最下边注释
                if (extenType != NULL) {
                    if (strstr(child->d_name,extenType) != NULL) {
                        if(lstat(childPath, &st) == 0) {
                            folderSize += st.st_size;
                        }
                    }
                }
                else{
                    if(lstat(childPath, &st) == 0) {
                        folderSize += st.st_size;
                    }
                }
            }
        }
    }
    closedir(dir);
    return folderSize;
}




+ (double)calculteFolderSize:(NSString *)folderPath catalog: (BOOL)isCatalog
{
    if (![FileUtility isFileExist:folderPath]) {
        return 0.0f;
    }
    const char * folderPathStr = [folderPath cStringUsingEncoding:NSUTF8StringEncoding];
    return [FileUtility calculteFileSizeAtPath : folderPathStr recursive : isCatalog extension : NULL];
}


+(double)calculteFileSizeInFolder : (NSString *)folderPath extension : (NSString *)extenType catalog: (BOOL)isCatalog
{
    if (![FileUtility isFileExist:folderPath]) {
        return 0.0f;
    }
    const char * folderPathStr = [folderPath cStringUsingEncoding:NSUTF8StringEncoding];
    const char * extensionStr = [extenType cStringUsingEncoding:NSUTF8StringEncoding];
    return [FileUtility calculteFileSizeAtPath : folderPathStr recursive : isCatalog extension : extensionStr];
    return 0;
}


+ (void)deleteFiles:(NSArray *)fileNames inPath:(NSString *)path
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *dirContents = [fm contentsOfDirectoryAtPath:path error:nil];
    
    if (dirContents == nil) {//文件夹为空时,dirContents不为nil但数目count为0,path为文件时,dirContents=nil
        if ([fileNames containsObject:[path lastPathComponent]]) {
            [FileUtility deleteFile:path];
        }
    }
    else {
        for (NSString *dirName in dirContents) {
            if ([fileNames containsObject:dirName]) {
                [FileUtility deleteFile:[path stringByAppendingPathComponent:dirName]];
            }
            else {
                [FileUtility deleteFiles:fileNames inPath: [path stringByAppendingPathComponent:dirName]];
            }
        }
    }
}


+ (NSArray *)getFirstCatalogFileNameInFolder : (NSString *)folderPath extension: (NSString *)extenStr{
    
    NSArray * listArr = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:folderPath error:nil];
    if (extenStr == nil || [extenStr isEqual: @""]) {
        return listArr;
    }
    else{
        NSMutableArray * mutableArr = [[NSMutableArray alloc]init];
        NSEnumerator *e = [listArr objectEnumerator];
        NSString *filename;
        while ((filename = [e nextObject])) {
            if ([[filename pathExtension] isEqualToString:extenStr]) {
                [mutableArr addObject: filename];
            }
        }
        return mutableArr;
    }
}


+ (NSArray *)getAllFileNameInFolder : (NSString *)folderPath extension: (NSString *)extenStr{
    
    NSArray * listArr = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:folderPath error:nil];
    if (extenStr == nil || [extenStr isEqual: @""]) {
        return listArr;
    }
    else{
        NSEnumerator *e = [listArr objectEnumerator];
        NSMutableArray * mutableArr = [[NSMutableArray alloc]init];
        NSString *filename;
        while ((filename = [e nextObject])) {
            if ([[filename pathExtension] isEqualToString:extenStr]) {
                [mutableArr addObject: filename];
            }
        }
        return mutableArr;
    }
}


+ (NSDictionary * )getFileAttribute : (NSString*)filePath
{
    if (filePath == nil || [filePath isEqualToString:@""]) {
        return nil;
    }
    NSMutableDictionary * fileAttributes = [[NSMutableDictionary alloc]init];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error = nil;
    NSDictionary *attributesDic = [fileManager attributesOfItemAtPath:filePath error:&error];
    if (attributesDic != nil) {
        [fileAttributes setDictionary:attributesDic];
        [fileAttributes setObject:filePath forKey:@"NSFilePath"];
        [fileAttributes setObject:[filePath lastPathComponent] forKey:@"NSFileName"];
    }
    else {
        NSLog(@"Path (%@) is invalid.", filePath);
    }
    
    return fileAttributes;
}

+ (NSArray * )getFilesAttributeInfolder : (NSString*)folderPath
{
    NSMutableArray * attributeArr = [[NSMutableArray alloc]init];
    NSArray * fileArr = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:folderPath error:nil];
    NSEnumerator *e = [fileArr objectEnumerator];
    NSString *filename;
    while ((filename = [e nextObject])) {
        
        NSString * filePath = [folderPath stringByAppendingPathComponent:filename];
        NSDictionary * attriDic = [self getFileAttribute : filePath];
        [attributeArr addObject:attriDic];
    }
    return attributeArr;
}

+ (NSArray * )getFilesAttributeInfolder : (NSString*)folderPath extension : (NSString *)extenStr
{
    if (folderPath == nil || [folderPath isEqual:@""]) {
        return nil;
    }
    if (extenStr == nil  || [extenStr isEqual: @""]) {
        return [self getFilesAttributeInfolder : folderPath];
    }
    else{
        NSMutableArray * attributeArr = [[NSMutableArray alloc]init];
        NSArray *fileAttriArr = [self getFilesAttributeInfolder:folderPath];
        NSEnumerator *e = [fileAttriArr objectEnumerator];
        NSDictionary * attDic;
        while ((attDic = [e nextObject])) {
            if ([[attDic[@"NSFileName"] pathExtension] isEqualToString:extenStr]) {
                [attributeArr addObject:attDic];
            }
        }
        return attributeArr;
    }
}


@end


//注释：

/*
 dirent结构体中的d_tpye的值可以为以下枚举成员：
enum
{
    DT_UNKNOWN = 0,     //未知类型
    # define DT_UNKNOWN DT_UNKNOWN
 
    DT_FIFO = 1,        //管道
    # define DT_FIFO DT_FIFO
 
    DT_CHR = 2,         //字符设备文件
    # define DT_CHR  DT_CHR
 
    DT_DIR = 4,         //目录
    # define DT_DIR  DT_DIR
 
    DT_BLK = 6,         //块设备文件
    # define DT_BLK  DT_BLK
 
    DT_REG = 8,         //普通文件
    # define DT_REG  DT_REG
 
    DT_LNK = 10,        //连接文件
    # define DT_LNK  DT_LNK
 
    DT_SOCK = 12,       //套接字类型
    # define DT_SOCK DT_SOCK
 
    DT_WHT = 14         //
    # define DT_WHT  DT_WHT
}; 
 */