//
//  Loading.h
//  WearEcg
//
//  Created by HeartDoc on 16/6/7.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Loading : NSObject


@property (nonatomic,strong) MBProgressHUD *hud;


+ (Loading *)ShareLoading;


+ (void)showHud : (NSString *)tipStr;

+ (void)hideHud;

+ (void)showTips:(NSString *)str;

+ (void)showHud : (NSString *)tipStr showtime : (CGFloat)time;

@end
