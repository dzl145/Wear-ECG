//
//  BluetoothManager.h
//  EcgWear
//
//  Created by HeartDoc on 16/8/4.
//  Copyright © 2016年 owen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HeartCloud_SDK.h"
#import <CoreLocation/CoreLocation.h>

typedef NS_ENUM(NSInteger, BlueTimerType) {
    //命令
    BlueTimerType_Commnd = 1,
    //重连
    BlueTimerType_ReConnect
};

// 蓝牙搜索协议代理
@protocol BluetoothManagerDelegate <NSObject>

@optional

//搜到到蓝牙回调 (没扫描一次 调用一次)
- (void)bluetoothFindCallback:(NSString *)uuid withRSSI:(NSNumber *)RSSI;

//搜到到蓝牙 并加入到蓝牙数组中 回调(扫描 只有加入数组时才会调用)
- (void)bluetoothFindForArrayCallback : (NSString *)uuid;

//连接初始化蓝牙回调
-(void)bluetoothConnectInitCallback : (NSString *)uuid;

//连接蓝牙成功回调
-(void)bluetoothConnectSucessCallback:(NSString *)uuid withDeviceName:(NSString *)deviceName;

//断开连接回调
-(void)bluetoothDisconnectCallback:(NSString *)uuid withDeviceName:(NSString *)deviceName;

//收到回复数据回调
-(void)bluetoothReceiveDataCallback:(NSString *)value;

//重连蓝牙成功回调
- (void)bluetoothReconnectSucessCallback:(NSString *)uuid;

//蓝牙重连中 每秒调用一次
-(void)bluetoothreReConnecting;

//蓝牙重连失败
-(void)bluetoothreReConnectFail;

@end


@interface BluetoothManager : NSObject<HeartCloud_SDK_Delegate>
{
    //commnd命令计时器
    NSTimer* commndTimer;
    
    //重连计时器
    NSTimer* reConnectTimer;
     //是否为上位机(手机)主动断开
    BOOL isInitiativeDis;
    //是否重新连接
    BOOL reconnection;
}

//单例
+ (BluetoothManager *)ShareBluetooth;

//多代理实现数组 (代理对象消失时 获取使用完蓝牙功能 及时删除，以免对象不能释放)
@property (strong, nonatomic) NSMutableArray<BluetoothManagerDelegate> *delegateArr;

//重连对象
@property (weak, nonatomic) id<BluetoothManagerDelegate> reConnectObj;

//蓝牙连接SDK
@property (strong, nonatomic) HeartCloud_SDK * BlueSdk;

//蓝牙搜索数据
@property (strong, nonatomic) NSMutableArray *BlueNumberArr;

//连接的UUID编号(在线的 在连接状态的)
@property (strong, nonatomic) NSString * onUUID;

//发送蓝牙命令状态
@property (nonatomic, assign) BOOL commndState;

@property (nonatomic, assign)id<BluetoothManagerDelegate> delegate;

// 添加代理
- (void)addDelegateForBlueArr:(id<BluetoothManagerDelegate>)delegate;
// 删除代理
- (void)removeDelegateFromBlueArr:(id<BluetoothManagerDelegate>)delegate;

// 扫描BLE设备
- (AU_RESULT_START_ADDING_MODE)startAddingMode:(BOOL)isReConnect;

// 停止扫描BLE设备
- (void)stopAddingMode;

// 连接设备
- (void)connectNewFoundDevice:(NSString *)uuid withPeripheral:(CBPeripheral *)peripheral;

// 重新连接设备
- (void)reConnectKnownDevice;

// 断开连接
- (void)disconnectDevice;

// 手机蓝牙是否已经连接
- (BOOL)isConnected;

// 发送命令
-(BOOL)sendCommndStrToBluetooth: (NSString *)commndStr isReply : (BOOL)reply;

// 设置连接间隔 默认值(30ms) 有效值:0x02〜0x20
- (AU_RESULT_CONFIG_DEVICE)configDevice:(NSString *)uuid connectionInterval:(AU_CONNECTION_INTERVAL)value;

// 设置 是否主动断开 状态
-(void)isInitiativeDisconnectState : (BOOL)isInitiative;

// 蓝牙 是否主动断开 状态
-(BOOL)isInitiativeDisconnect;

-(void)clearData;

@end






