//
//  UserInfo.h
//  WearEcg
//
//  Created by lxl on 16/3/21.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserModel.h"

@interface UserInfo : NSObject

@property(strong,nonatomic)UserModel * userModel;

/**
 *  @author lxl, 16-03-21 17:03:23
 *
 *  获取Userid
 */
+ (NSString *)getLoggedUserId;


/*
 *  用户单例
 *  @return
 */
+ (UserInfo *)ShareUserInfo;


/*
 *  保存用户信息
 */
-(void)saveUserData;


/*
 *  检测本地是否有图片
 *  @return YES/NO
 */
- (BOOL)isHasInLocalPhoto;

/*
 *  检测本地是否有图片
 *  @return NSString
 */
- (NSString *)getUserPhotoPath;


/*
 *  设置当前用户
 *  @return NSString
 */
-(void)setCurLoginUserId : (NSString *)userId;


/*
 *  获取当前登录的账户
 *  @return NSString
 */
-(NSString *)getCurLoginUserId;

/*
 *  加载用户头像
 *  @return NSString
 */
-(void)loadUserPhoto : (UIButton *)imageBtn;

/*
 *  获取用户测量文件存放路径 type:截取文件的类型
 *  @return NSString 
 */
-(NSString *)getUserSaveFilePath:(NSInteger)type;

@end
