//
//  HDPublicClsass.m
//  WearEcg
//
//  Created by lxl on 15/12/11.
//  Copyright © 2015年 lxl. All rights reserved.
//

#import "HDPublicClass.h"
//#import "RecordModel.h"

static HDPublicClass* public = nil;
@implementation HDPublicClass

+(id)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (public == nil){
            public = [[HDPublicClass alloc] init];
        }
    });
    return public;
}

+ (id)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        public = [super allocWithZone:zone];
    });
    return public;
}

- (id)copyWithZone:(NSZone *)zone
{
    return public;
}

-(CGFloat)getDBFileSizesForWaveInSixtyAndUpload{
    //算出所有文件的大小
    NSArray * arr = [self getDBFilesForWaveInSixtyAndUpload];
    CGFloat sizes = 0;
//    for (RecordModel *model in arr) {
//        NSString * path = [RootPath stringByAppendingPathComponent:model.filepath];
//        sizes += [FileUtility calculteFileSzie : path];
//    }
    return sizes;
}

-(NSArray *)getDBFilesForWaveInSixtyAndUpload{
    //查询数数据库中所有的数据记录  只查询出已经上传的 (60s文件也需要上传)
//    NSPredicate * predicate = [NSPredicate predicateWithFormat:@"isupload == %@ AND usermark == %@", [NSNumber numberWithBool:YES],[UserInfo ShareUserInfo].userModel.num];
//    NSArray * dataArr = [RecordModel modelWithOperateByPredicate:predicate];
//    return dataArr;
    return [NSArray array];
}

-(NSArray *)getDBAllFileForWaveInSixtyAndContinue{
//    NSPredicate * predicate = [NSPredicate predicateWithFormat:@"usermark == %@",[UserInfo ShareUserInfo].userModel.num];
//    NSArray * dataArr = [RecordModel modelWithOperateByPredicate:predicate];
//    return dataArr;
    return [NSArray array];
}

-(NSArray *)getDiskAllTxtFileForPath : (NSString *)path{
    NSArray * txtNameArr = [FileUtility getFirstCatalogFileNameInFolder:path extension:@"txt"];
    NSMutableArray * pathArr = [[NSMutableArray alloc]init];
    for (NSString *filename in txtNameArr) {
        [pathArr addObject:[path stringByAppendingPathComponent : filename]];
    }
    return pathArr;
}

- (void)updateBlueConnectUuid : (NSString *)uuid{
    [[NSUserDefaults standardUserDefaults] setObject:uuid forKey:NewestUuid];
    [NSUserDefaults resetStandardUserDefaults];
}

- (NSString *)getBlueConnectUuid{
    NSString * uuid = [[NSUserDefaults standardUserDefaults] valueForKey :NewestUuid];
    if (uuid == nil || [uuid isEqualToString:@""]) {
        return nil;
    }
    return uuid;
}

//获取心率比例
-(NSArray *)getHeartScale : (NSArray *)heartArr{
    if (!heartArr) return nil;

    NSMutableArray * sacleArr = [[NSMutableArray alloc]init];
    NSInteger heartCount = heartArr.count;
    NSString *match0 = @"[1-9][2-9][0-9]";
    NSPredicate *predicate0 = [NSPredicate predicateWithFormat:@"SELF matches %@", match0];
    NSInteger toofast = [heartArr filteredArrayUsingPredicate:predicate0].count;
    [sacleArr addObject:[NSString stringWithFormat:@"%lf",(CGFloat)toofast/heartCount]];
    
    NSString *match1 = @"1[0-1][0-9]";
    NSPredicate *predicate1 = [NSPredicate predicateWithFormat:@"SELF matches %@", match1];
    NSInteger fast = [heartArr filteredArrayUsingPredicate:predicate1].count;
    [sacleArr addObject:[NSString stringWithFormat:@"%lf",(CGFloat)fast/heartCount]];
    
    NSString *match2 = @"[6-9][0-9]";
    NSPredicate *predicate2 = [NSPredicate predicateWithFormat:@"SELF matches %@", match2];
    NSInteger normal = [heartArr filteredArrayUsingPredicate:predicate2].count;
    [sacleArr addObject:[NSString stringWithFormat:@"%lf",(CGFloat)normal/heartCount]];
    
    NSString *match3 = @"5[0-9]";
    NSPredicate *predicate3 = [NSPredicate predicateWithFormat:@"SELF matches %@", match3];
    NSInteger slow = [heartArr filteredArrayUsingPredicate:predicate3].count;
    [sacleArr addObject:[NSString stringWithFormat:@"%lf",(CGFloat)slow/heartCount]];
    
    NSString *match4 = @"[0-4][0-9]";
    NSPredicate *predicate4 = [NSPredicate predicateWithFormat:@"SELF matches %@", match4];
    NSInteger tooslow = [heartArr filteredArrayUsingPredicate:predicate4].count;
    [sacleArr addObject:[NSString stringWithFormat:@"%lf",(CGFloat)tooslow/heartCount]];
    return sacleArr;
}

//显示心率详细
-(NSString *)getHeartValue : (NSArray *)heartArr valueType : (HeartValueType)type{
    //显示心率情况
    NSNumber *number = nil;
    if (type == HeartValueType_Avg) {
        number = [heartArr valueForKeyPath:@"@avg.floatValue"];
    }
    else if (type == HeartValueType_Max) {
        number = [heartArr valueForKeyPath:@"@max.floatValue"];
    }
    else if (type == HeartValueType_Min) {
        number = [heartArr valueForKeyPath:@"@min.floatValue"];
    }
    return [NSString stringWithFormat:@"%ld",(long)[number floatValue]];
}

//获取健康值
-(NSInteger)getHealthValue : (NSArray *)heartArr{
    NSString *match = @"[6-9][0-9]";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF matches %@", match];
    NSInteger normalCount = [heartArr filteredArrayUsingPredicate:predicate].count;
    
    CGFloat ratio = (CGFloat)normalCount/heartArr.count;
    return (NSInteger)ratio * 100;
}

-(NSString *)getHealthState : (NSInteger)value{
    NSString * strState = nil;
    if (value <= 100 && value >= 90) {
        strState = @"良好";
    }
    else if (value <= 89 && value >= 70){
        strState = @"亚健康";
    }
    else{
        strState = @"不良";
    }
    return strState;
}

- (NSString *)getCurrentTime{
    //获得当前应用程序默认的时区
    NSTimeZone *zone = [NSTimeZone defaultTimeZone];
    //以秒为单位返回当前应用程序与世界标准时间（格林威尼时间）的时差
    NSInteger interval = [zone secondsFromGMTForDate:[NSDate date]];
    NSDate *localeDate = [[NSDate date] dateByAddingTimeInterval:interval];
    NSString *stirngaaaa = [NSString stringWithFormat:@"%ld", (long)[localeDate timeIntervalSince1970]];
    return stirngaaaa;
}


@end
