//
//  UserInfo.m
//  WearEcg
//
//  Created by lxl on 16/3/21.
//  Copyright © 2016年 lxl. All rights reserved.
//

#import "UserInfo.h"


static UserInfo * _userInfo;

@implementation UserInfo
+ (NSString *)getLoggedUserId{
    
    NSString * cardId = [[NSUserDefaults standardUserDefaults] valueForKey :CurLogigKey];
    if (cardId == nil || [cardId isEqualToString:@""]) {
        return nil;
    }
    return cardId;
}

//单例
+ (UserInfo *)ShareUserInfo{
    
    if (_userInfo != nil) {
        return _userInfo;
    }
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _userInfo = [[UserInfo alloc]init];
    });
    
    return _userInfo;
}

+ (id)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _userInfo = [super allocWithZone:zone];
    });
    return _userInfo;
}

- (id)copyWithZone:(NSZone *)zone
{
    return _userInfo;
}


-(UserModel *)userModel{
    if (_userModel == nil) {
        _userModel = [UserModel modelWithDict:[self getCurUserDataFromDictionary]];
    }
    return _userModel;
}

-(void)saveUserData{
    //保存当前用户信息
//    NSDictionary *userdata = [_userModel dictWithModel];
   //NSLog(@"****** %@",userdata);

    //更新到数据库
//    [UserOperate updateDataToDBUserID:userdata[@"num"] UserDic : userdata];
    
    //保存当前登录的用户账号表示
//    [self setCurLoginUserId : userdata[@"num"]];
}

//设置当前用户的ID
-(void)setCurLoginUserId : (NSString *)userId
{
    [[NSUserDefaults standardUserDefaults] setObject:userId forKey:CurLogigKey];
    [NSUserDefaults resetStandardUserDefaults];
}

//获取当前用户数据
-(NSDictionary *)getCurUserDataFromDictionary
{
    //测试 读取全部数据 3084018157
//    NSArray * arr = [UserModel modelWithOperateAll];
//    NSLog(@"%@",arr);
    
    
//    NSString * userId = [self getCurLoginUserId];
//    if (userId == nil) {
//        return nil;
//    }
//    
//    //读取数据库
//    NSDictionary * userDic = [UserOperate readDataFromDBUserID:userId];
//    return userDic;
    
    return nil;
}

//获取当前用户的id
-(NSString *)getCurLoginUserId
{
    NSString * userId = [[NSUserDefaults standardUserDefaults] valueForKey :CurLogigKey];
    if (userId == nil || [userId isEqualToString:@""]) {
        return nil;
//        return @"3084018157";
    }
    return userId;
}

#pragma mark -- 头像存放路径
//获取当前用户的头像全路径
-(NSString *)getUserPhotoPath{
    NSString * photoPath = [RootPath stringByAppendingPathComponent :[NSString stringWithFormat:@"%@%@",_userModel.num,UserPhoto]];
    if ([FileUtility createDirectoryPath:photoPath]) {
        NSString * photoname = [NSString stringWithFormat:@"%@.png",_userModel.num];
        NSString * photopath =  [photoPath stringByAppendingPathComponent:photoname];
        return photopath;
    }
    return @"";
}

//检测本地是否有图片
-(BOOL)isHasInLocalPhoto{

    NSString * photoPath = [self getUserPhotoPath];
    if ([FileUtility isFileExist:photoPath]) {
        return YES;
    }
    return NO;
}


-(void)loadUserPhoto : (UIButton *)imageBtn{
    if ([self isHasInLocalPhoto]) {
        UIImage *image = [UIImage imageWithContentsOfFile:[self getUserPhotoPath]];
        [imageBtn setBackgroundImage:image forState:UIControlStateNormal];
    }
    else{
        //显示默认
        if(_userModel.sex == nil || [_userModel.sex isEqualToString:@"1"] || [_userModel.sex isEqualToString:@""]){
            [imageBtn setBackgroundImage:[UIImage imageNamed:@"photo_Man"] forState:UIControlStateNormal];
        }
        else{
            [imageBtn setBackgroundImage:[UIImage imageNamed:@"photo_Women"] forState:UIControlStateNormal];
        }
        //请求网路加载
        if (_userModel.logo != nil && ![_userModel.logo isEqualToString:@""]) {
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                
                NSData *resultData = [NSData dataWithContentsOfURL:[NSURL URLWithString:_userModel.logo]];
                UIImage *img = [UIImage imageWithData:resultData];
                
                dispatch_sync(dispatch_get_main_queue(), ^{
                    [imageBtn setBackgroundImage:img forState:UIControlStateNormal];
                    
                    //保存本地
                    NSString * imagepath = [[UserInfo ShareUserInfo] getUserPhotoPath];
                    [UIImagePNGRepresentation(img) writeToFile:imagepath atomically:YES];
                });
            });
        }
    }
}


-(NSString *)getUserSaveFilePath : (NSInteger)type{
    NSString * pathStr = nil;
    if (type == BlueDataInterceptType_Starting) {
        pathStr =[NSString stringWithFormat:@"%@%@",_userModel.num,StartPath];
    }
    else if(type == BlueDataInterceptType_Timer){
        pathStr =[NSString stringWithFormat:@"%@%@",_userModel.num,TimerPath];
    }
    else if(type == BlueDataInterceptType_Mark){
        pathStr =[NSString stringWithFormat:@"%@%@",_userModel.num,MarkPath];
    }
    else if(type == BlueDataInterceptType_Exception){
        pathStr =[NSString stringWithFormat:@"%@%@",_userModel.num,ExcepPath];
    }
    else if (type == BlueDataInterceptType_Sixty){
        pathStr =[NSString stringWithFormat:@"%@%@",_userModel.num,UserFile60s];
    }
    else if(type == BlueDataInterceptType_Continue){
        pathStr =[NSString stringWithFormat:@"%@%@",_userModel.num,heartPath];
    }
    if (pathStr != nil) {
        return pathStr;
    }
    return @"";
}

@end
